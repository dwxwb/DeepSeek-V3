"use client"

import { CardContent } from "@/components/ui/card"

import { Card } from "@/components/ui/card"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import Dashboard from "@/components/dashboard"
import Ledger from "@/components/ledger"
import TransactionManager from "@/components/transaction-manager"
import Reports from "@/components/reports"
import Settings from "@/components/settings"
import CalendarView from "@/components/calendar-view"
import RecurringTransactions from "@/components/recurring-transactions"
import Calculator from "@/components/calculator"
import ThemeSwitcher from "@/components/theme-switcher"
import AdBanner from "@/components/ad-banner"
import AdminPanel from "@/components/admin-panel"
import CategoryMenu from "@/components/category-menu"
import SignupForm from "@/components/auth/signup-form"
import OCRScanner from "@/components/ocr-scanner"
import AccountSync from "@/components/account-sync"
import AIInsights from "@/components/ai-insights"
import SubscriptionPlans from "@/components/subscription-plans"
import { CalculatorIcon, UserPlus, Crown } from "lucide-react"

export default function Home() {
  const [calculatorOpen, setCalculatorOpen] = useState(false)
  const [signupOpen, setSignupOpen] = useState(false)
  const [subscriptionOpen, setSubscriptionOpen] = useState(false)

  return (
    <main className="container mx-auto py-6 px-4">
      <AdBanner />

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">통합 재무 관리 시스템</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setSubscriptionOpen(true)}>
            <Crown className="mr-2 h-4 w-4" />
            프리미엄
          </Button>
          <Button variant="outline" onClick={() => setSignupOpen(true)}>
            <UserPlus className="mr-2 h-4 w-4" />
            회원가입/로그인
          </Button>
          <Button variant="outline" onClick={() => setCalculatorOpen(true)}>
            <CalculatorIcon className="mr-2 h-4 w-4" />
            계산기
          </Button>
          <ThemeSwitcher />
        </div>
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-12">
          <TabsTrigger value="dashboard">대시보드</TabsTrigger>
          <TabsTrigger value="ledger">가계부</TabsTrigger>
          <TabsTrigger value="transactions">매입/매출</TabsTrigger>
          <TabsTrigger value="recurring">정기 거래</TabsTrigger>
          <TabsTrigger value="calendar">캘린더</TabsTrigger>
          <TabsTrigger value="category">카테고리</TabsTrigger>
          <TabsTrigger value="ocr">영수증 스캔</TabsTrigger>
          <TabsTrigger value="account-sync">계좌 연동</TabsTrigger>
          <TabsTrigger value="ai-insights">AI 인사이트</TabsTrigger>
          <TabsTrigger value="reports">보고서</TabsTrigger>
          <TabsTrigger value="admin">관리자</TabsTrigger>
          <TabsTrigger value="settings">설정</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <Dashboard />
        </TabsContent>

        <TabsContent value="ledger">
          <Ledger />
        </TabsContent>

        <TabsContent value="transactions">
          <TransactionManager />
        </TabsContent>

        <TabsContent value="recurring">
          <RecurringTransactions />
        </TabsContent>

        <TabsContent value="calendar">
          <CalendarView />
        </TabsContent>

        <TabsContent value="category">
          <CategoryMenu />
        </TabsContent>

        <TabsContent value="ocr">
          <OCRScanner />
        </TabsContent>

        <TabsContent value="account-sync">
          <AccountSync />
        </TabsContent>

        <TabsContent value="ai-insights">
          <AIInsights />
        </TabsContent>

        <TabsContent value="reports">
          <Reports />
        </TabsContent>

        <TabsContent value="admin">
          <AdminPanel />
        </TabsContent>

        <TabsContent value="settings">
          <Settings />
        </TabsContent>
      </Tabs>

      <Dialog open={calculatorOpen} onOpenChange={setCalculatorOpen}>
        <DialogContent className="sm:max-w-md p-0 bg-transparent border-none shadow-none">
          <Calculator onClose={() => setCalculatorOpen(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={signupOpen} onOpenChange={setSignupOpen}>
        <DialogContent className="sm:max-w-md p-0 bg-transparent border-none shadow-none">
          <SignupForm onClose={() => setSignupOpen(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={subscriptionOpen} onOpenChange={setSubscriptionOpen}>
        <DialogContent className="sm:max-w-4xl p-0 bg-transparent border-none shadow-none">
          <Card className="w-full">
            <CardContent className="p-0">
              <SubscriptionPlans />
            </CardContent>
          </Card>
        </DialogContent>
      </Dialog>
    </main>
  )
}

