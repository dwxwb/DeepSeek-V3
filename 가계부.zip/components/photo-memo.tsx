"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Camera,
  Upload,
  CalendarIcon,
  Search,
  Plus,
  Edit,
  Trash2,
  Star,
  StarOff,
  Download,
  MoreHorizontal,
  X,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { format, parseISO, isToday, isYesterday, isSameYear } from "date-fns"
import { ko } from "date-fns/locale"
import { Spinner } from "@/components/ui/spinner"

// 메모 타입 정의
interface Memo {
  id: number
  date: string
  title: string
  content: string
  imageUrl?: string
  tags: string[]
  important: boolean
  createdAt: string
  updatedAt: string
}

// 가상의 메모 데이터
const initialMemos: Memo[] = [
  {
    id: 1,
    date: "2024-04-15",
    title: "중요한 회의 내용",
    content:
      "오늘 진행된 프로젝트 회의에서 다음 단계 계획을 논의했습니다. 주요 결정사항:\n1. 다음 주까지 기획안 완성\n2. 5월 초 베타 테스트 진행\n3. 6월 말 정식 출시",
    tags: ["회의", "프로젝트"],
    important: true,
    createdAt: "2024-04-15T14:30:00",
    updatedAt: "2024-04-15T14:30:00",
  },
  {
    id: 2,
    date: "2024-04-14",
    title: "아이디어 메모",
    content:
      "새로운 기능 아이디어: 사용자가 직접 테마를 커스터마이징할 수 있는 기능 추가. 색상, 폰트, 아이콘 등을 선택할 수 있게 하면 좋을 것 같음.",
    tags: ["아이디어", "기능개선"],
    important: false,
    createdAt: "2024-04-14T10:15:00",
    updatedAt: "2024-04-14T10:15:00",
  },
  {
    id: 3,
    date: "2024-04-13",
    title: "거래처 미팅 준비",
    content: "내일 A기업 미팅 준비사항:\n- 제안서 최종 검토\n- 데모 시연 준비\n- 가격 협상 전략 수립",
    imageUrl: "/placeholder.svg?height=300&width=400",
    tags: ["미팅", "준비"],
    important: true,
    createdAt: "2024-04-13T16:45:00",
    updatedAt: "2024-04-13T16:45:00",
  },
  {
    id: 4,
    date: "2024-04-10",
    title: "월간 목표 설정",
    content: "4월 목표:\n1. 신규 고객 5개사 확보\n2. 기존 고객 만족도 조사 실시\n3. 신규 서비스 기획안 완성",
    tags: ["목표", "계획"],
    important: false,
    createdAt: "2024-04-10T09:00:00",
    updatedAt: "2024-04-10T09:00:00",
  },
  {
    id: 5,
    date: "2024-04-05",
    title: "도서 추천 목록",
    content:
      "읽을 책 목록:\n- 아웃라이어 (말콤 글래드웰)\n- 사피엔스 (유발 하라리)\n- 원칙 (레이 달리오)\n- 이기적 유전자 (리처드 도킨스)",
    tags: ["도서", "자기계발"],
    important: false,
    createdAt: "2024-04-05T20:30:00",
    updatedAt: "2024-04-05T20:30:00",
  },
]

// 태그 목록
const availableTags = [
  "회의",
  "프로젝트",
  "아이디어",
  "기능개선",
  "미팅",
  "준비",
  "목표",
  "계획",
  "도서",
  "자기계발",
  "할일",
  "중요",
  "개인",
  "업무",
]

export default function PhotoMemo() {
  const [memos, setMemos] = useState<Memo[]>(initialMemos)
  const [activeTab, setActiveTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterTag, setFilterTag] = useState<string | null>(null)
  const [filterImportant, setFilterImportant] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedMemo, setSelectedMemo] = useState<Memo | null>(null)
  const [isEditing, setIsEditing] = useState(false)

  // 새 메모 상태
  const [newTitle, setNewTitle] = useState("")
  const [newContent, setNewContent] = useState("")
  const [newTags, setNewTags] = useState<string[]>([])
  const [newImportant, setNewImportant] = useState(false)
  const [newImage, setNewImage] = useState<string | null>(null)
  const [isCapturing, setIsCapturing] = useState(false)
  const [isCameraActive, setIsCameraActive] = useState(false)

  // 파일 업로드 및 카메라 관련 ref
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // 브라우저 환경 확인
  const isBrowser = typeof window !== "undefined"
  const [isCameraAvailable, setIsCameraAvailable] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)

  // 카메라 지원 여부 확인
  useEffect(() => {
    if (!isBrowser) return

    const checkCameraAvailability = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setCameraError("이 브라우저는 카메라 접근을 지원하지 않습니다.")
          return
        }

        // 카메라 사용 가능 여부 확인
        const stream = await navigator.mediaDevices.getUserMedia({ video: true })
        stream.getTracks().forEach((track) => track.stop())
        setIsCameraAvailable(true)
      } catch (error) {
        console.error("카메라 확인 중 오류:", error)
        setCameraError("카메라에 접근할 수 없습니다. 권한을 확인해주세요.")
      }
    }

    checkCameraAvailability()
  }, [isBrowser])

  // 카메라 시작
  const startCamera = async () => {
    if (!isBrowser || !isCameraAvailable) return

    try {
      // 이미 실행 중인 스트림이 있으면 중지
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }

      // 새 스트림 시작
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      streamRef.current = stream

      // videoRef가 유효한지 확인 후 srcObject 설정
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsCameraActive(true)
      } else {
        console.warn("비디오 요소가 아직 준비되지 않았습니다.")
        // 스트림 정리
        stream.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }
    } catch (error) {
      console.error("카메라 접근 오류:", error)
      setCameraError("카메라에 접근할 수 없습니다. 권한을 확인해주세요.")
      setIsCameraAvailable(false)
    }
  }

  // 카메라 중지
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setIsCameraActive(false)
  }

  // 사진 촬영
  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return

    setIsCapturing(true)

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (context && video.videoWidth && video.videoHeight) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      context.drawImage(video, 0, 0, canvas.width, canvas.height)

      // 캡처한 이미지를 데이터 URL로 변환
      const imageDataUrl = canvas.toDataURL("image/jpeg")
      setNewImage(imageDataUrl)

      // 카메라 중지
      stopCamera()
    }

    setIsCapturing(false)
  }

  // 파일 업로드 처리
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (evt) => {
      setNewImage(evt.target?.result as string)
    }
    reader.readAsDataURL(file)
  }

  // 필터링된 메모 가져오기
  const getFilteredMemos = () => {
    return memos.filter((memo) => {
      // 탭 필터링
      if (activeTab === "today" && !isToday(parseISO(memo.date))) return false
      if (activeTab === "important" && !memo.important) return false

      // 검색어 필터링
      const matchesSearch =
        searchTerm === "" ||
        memo.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        memo.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        memo.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

      // 태그 필터링
      const matchesTag = filterTag === null || memo.tags.includes(filterTag)

      // 중요 표시 필터링
      const matchesImportant = !filterImportant || memo.important

      return matchesSearch && matchesTag && matchesImportant
    })
  }

  // 메모 추가
  const handleAddMemo = () => {
    if (!newTitle || !newContent || !selectedDate) {
      alert("제목과 내용을 입력해주세요.")
      return
    }

    const now = new Date().toISOString()
    const newMemo: Memo = {
      id: memos.length > 0 ? Math.max(...memos.map((memo) => memo.id)) + 1 : 1,
      date: format(selectedDate, "yyyy-MM-dd"),
      title: newTitle,
      content: newContent,
      imageUrl: newImage || undefined,
      tags: newTags,
      important: newImportant,
      createdAt: now,
      updatedAt: now,
    }

    setMemos([newMemo, ...memos])
    resetForm()
    setIsAddDialogOpen(false)
  }

  // 메모 수정
  const handleUpdateMemo = () => {
    if (!selectedMemo || !newTitle || !newContent) {
      alert("제목과 내용을 입력해주세요.")
      return
    }

    const updatedMemos = memos.map((memo) => {
      if (memo.id === selectedMemo.id) {
        return {
          ...memo,
          title: newTitle,
          content: newContent,
          imageUrl: newImage || memo.imageUrl,
          tags: newTags,
          important: newImportant,
          updatedAt: new Date().toISOString(),
        }
      }
      return memo
    })

    setMemos(updatedMemos)
    setSelectedMemo(null)
    resetForm()
    setIsEditing(false)
    setIsViewDialogOpen(false)
  }

  // 메모 삭제
  const handleDeleteMemo = () => {
    if (!selectedMemo) return

    setMemos(memos.filter((memo) => memo.id !== selectedMemo.id))
    setSelectedMemo(null)
    setIsDeleteDialogOpen(false)
    setIsViewDialogOpen(false)
  }

  // 중요 표시 토글
  const toggleImportant = (id: number) => {
    setMemos(memos.map((memo) => (memo.id === id ? { ...memo, important: !memo.important } : memo)))
  }

  // 메모 보기
  const handleViewMemo = (memo: Memo) => {
    setSelectedMemo(memo)
    setNewTitle(memo.title)
    setNewContent(memo.content)
    setNewTags(memo.tags)
    setNewImportant(memo.important)
    setNewImage(memo.imageUrl || null)
    setIsViewDialogOpen(true)
  }

  // 메모 편집 시작
  const startEditing = () => {
    setIsEditing(true)
  }

  // 폼 초기화
  const resetForm = () => {
    setNewTitle("")
    setNewContent("")
    setNewTags([])
    setNewImportant(false)
    setNewImage(null)
    setIsEditing(false)
    stopCamera()
  }

  // 날짜 포맷팅
  const formatDate = (dateString: string) => {
    const date = parseISO(dateString)
    if (isToday(date)) return "오늘"
    if (isYesterday(date)) return "어제"

    if (isSameYear(date, new Date())) {
      return format(date, "M월 d일", { locale: ko })
    }

    return format(date, "yyyy년 M월 d일", { locale: ko })
  }

  // 시간 포맷팅
  const formatTime = (dateTimeString: string) => {
    const date = parseISO(dateTimeString)
    return format(date, "a h:mm", { locale: ko })
  }

  // 태그 추가
  const addTag = (tag: string) => {
    if (!newTags.includes(tag)) {
      setNewTags([...newTags, tag])
    }
  }

  // 태그 제거
  const removeTag = (tag: string) => {
    setNewTags(newTags.filter((t) => t !== tag))
  }

  // 컴포넌트 언마운트 시 카메라 정리
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  const filteredMemos = getFilteredMemos()

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">메모 & 사진</h2>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              resetForm()
              setSelectedDate(new Date())
              setIsAddDialogOpen(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />새 메모
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-3/4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>메모 목록</CardTitle>
                  <CardDescription>중요한 메모와 사진을 관리하세요</CardDescription>
                </div>
                <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="검색..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  <Select
                    value={filterTag || "all"}
                    onValueChange={(value) => setFilterTag(value === "all" ? null : value)}
                  >
                    <SelectTrigger className="w-full md:w-[150px]">
                      <SelectValue placeholder="태그 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">모든 태그</SelectItem>
                      {availableTags.map((tag) => (
                        <SelectItem key={tag} value={tag}>
                          {tag}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="important-only" className="text-sm whitespace-nowrap">
                      중요 메모만
                    </Label>
                    <input
                      id="important-only"
                      type="checkbox"
                      className="h-4 w-4"
                      checked={filterImportant}
                      onChange={(e) => setFilterImportant(e.target.checked)}
                    />
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="all">전체</TabsTrigger>
                  <TabsTrigger value="today">오늘</TabsTrigger>
                  <TabsTrigger value="important">중요</TabsTrigger>
                </TabsList>

                {filteredMemos.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">메모가 없습니다. 새 메모를 추가해보세요.</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredMemos.map((memo) => (
                      <Card
                        key={memo.id}
                        className={`cursor-pointer hover:shadow-md transition-shadow ${memo.important ? "border-yellow-300" : ""}`}
                        onClick={() => handleViewMemo(memo)}
                      >
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div className="font-medium truncate">{memo.title}</div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-yellow-500"
                              onClick={(e) => {
                                e.stopPropagation()
                                toggleImportant(memo.id)
                              }}
                            >
                              {memo.important ? <Star className="h-4 w-4" /> : <StarOff className="h-4 w-4" />}
                            </Button>
                          </div>

                          {memo.imageUrl && (
                            <div className="relative w-full h-32 mb-2 overflow-hidden rounded-md">
                              <img
                                src={memo.imageUrl || "/placeholder.svg"}
                                alt={memo.title}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}

                          <div className="text-sm text-muted-foreground mb-2 line-clamp-3 whitespace-pre-line">
                            {memo.content}
                          </div>

                          <div className="flex justify-between items-center mt-2">
                            <div className="text-xs text-muted-foreground">
                              {formatDate(memo.date)} {formatTime(memo.createdAt)}
                            </div>
                            <div className="flex flex-wrap gap-1 justify-end">
                              {memo.tags.slice(0, 2).map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                              {memo.tags.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{memo.tags.length - 2}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </Tabs>
            </CardContent>
            <CardFooter>
              <div className="text-sm text-muted-foreground">총 {filteredMemos.length}개의 메모</div>
            </CardFooter>
          </Card>
        </div>

        <div className="w-full md:w-1/4">
          <Card>
            <CardHeader>
              <CardTitle>캘린더</CardTitle>
              <CardDescription>날짜별 메모 확인</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
                locale={ko}
              />

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-2">선택한 날짜의 메모</h3>
                {selectedDate && (
                  <div className="space-y-2">
                    {memos
                      .filter((memo) => memo.date === format(selectedDate, "yyyy-MM-dd"))
                      .map((memo) => (
                        <div
                          key={memo.id}
                          className="p-2 border rounded-md cursor-pointer hover:bg-muted/50"
                          onClick={() => handleViewMemo(memo)}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium truncate">{memo.title}</span>
                            {memo.important && <Star className="h-3 w-3 text-yellow-500" />}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1 truncate">
                            {memo.content.substring(0, 50)}
                            {memo.content.length > 50 ? "..." : ""}
                          </div>
                        </div>
                      ))}
                    {memos.filter((memo) => memo.date === format(selectedDate, "yyyy-MM-dd")).length === 0 && (
                      <div className="text-sm text-muted-foreground text-center py-2">메모가 없습니다</div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                variant="outline"
                onClick={() => {
                  resetForm()
                  setIsAddDialogOpen(true)
                }}
              >
                <Plus className="mr-2 h-4 w-4" />새 메모 추가
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

      {/* 새 메모 추가 다이얼로그 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>새 메모 추가</DialogTitle>
            <DialogDescription>중요한 내용과 사진을 메모로 저장하세요</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">제목</Label>
              <Input
                id="title"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="메모 제목을 입력하세요"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="date">날짜</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP", { locale: ko }) : "날짜 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} initialFocus locale={ko} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="content">내용</Label>
              <Textarea
                id="content"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="메모 내용을 입력하세요"
                rows={5}
                required
              />
            </div>

            <div className="grid gap-2">
              <Label>이미지 추가</Label>
              <div className="flex flex-col gap-2">
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      if (isCameraAvailable) {
                        startCamera()
                      } else {
                        alert("카메라를 사용할 수 없습니다.")
                      }
                    }}
                  >
                    <Camera className="mr-2 h-4 w-4" />
                    카메라
                  </Button>
                  <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="mr-2 h-4 w-4" />
                    파일 업로드
                  </Button>
                  <Input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </div>

                {isCameraActive && (
                  <div className="relative aspect-video bg-muted rounded-md overflow-hidden">
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                    <canvas ref={canvasRef} className="hidden" />
                    <div className="absolute bottom-2 left-0 right-0 flex justify-center">
                      <Button type="button" onClick={captureImage} disabled={isCapturing}>
                        {isCapturing ? <Spinner size="sm" /> : "사진 촬영"}
                      </Button>
                    </div>
                  </div>
                )}

                {newImage && (
                  <div className="relative">
                    <img
                      src={newImage || "/placeholder.svg"}
                      alt="미리보기"
                      className="max-h-48 rounded-md object-contain mx-auto"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6 rounded-full"
                      onClick={() => setNewImage(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="tags">태그</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {newTags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 rounded-full"
                      onClick={() => removeTag(tag)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
              <Select onValueChange={addTag}>
                <SelectTrigger>
                  <SelectValue placeholder="태그 선택" />
                </SelectTrigger>
                <SelectContent>
                  {availableTags
                    .filter((tag) => !newTags.includes(tag))
                    .map((tag) => (
                      <SelectItem key={tag} value={tag}>
                        {tag}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <input
                id="important"
                type="checkbox"
                className="h-4 w-4"
                checked={newImportant}
                onChange={(e) => setNewImportant(e.target.checked)}
              />
              <Label htmlFor="important">중요 메모로 표시</Label>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                resetForm()
                setIsAddDialogOpen(false)
              }}
            >
              취소
            </Button>
            <Button type="button" onClick={handleAddMemo}>
              저장
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 메모 보기 다이얼로그 */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex justify-between items-center">
              {isEditing ? "메모 수정" : "메모 보기"}
              {!isEditing && selectedMemo && (
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-yellow-500"
                    onClick={() => {
                      if (selectedMemo) toggleImportant(selectedMemo.id)
                    }}
                  >
                    {selectedMemo.important ? <Star className="h-4 w-4" /> : <StarOff className="h-4 w-4" />}
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={startEditing}>
                        <Edit className="mr-2 h-4 w-4" />
                        수정
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setIsDeleteDialogOpen(true)}>
                        <Trash2 className="mr-2 h-4 w-4" />
                        삭제
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Download className="mr-2 h-4 w-4" />
                        내보내기
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </DialogTitle>
          </DialogHeader>

          {selectedMemo && (
            <>
              {isEditing ? (
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="edit-title">제목</Label>
                    <Input id="edit-title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} required />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="edit-content">내용</Label>
                    <Textarea
                      id="edit-content"
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      rows={8}
                      required
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label>이미지</Label>
                    <div className="flex flex-col gap-2">
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            if (isCameraAvailable) {
                              startCamera()
                            } else {
                              alert("카메라를 사용할 수 없습니다.")
                            }
                          }}
                        >
                          <Camera className="mr-2 h-4 w-4" />
                          카메라
                        </Button>
                        <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                          <Upload className="mr-2 h-4 w-4" />
                          파일 업로드
                        </Button>
                      </div>

                      {isCameraActive && (
                        <div className="relative aspect-video bg-muted rounded-md overflow-hidden">
                          <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                          <canvas ref={canvasRef} className="hidden" />
                          <div className="absolute bottom-2 left-0 right-0 flex justify-center">
                            <Button type="button" onClick={captureImage} disabled={isCapturing}>
                              {isCapturing ? <Spinner size="sm" /> : "사진 촬영"}
                            </Button>
                          </div>
                        </div>
                      )}

                      {newImage && (
                        <div className="relative">
                          <img
                            src={newImage || "/placeholder.svg"}
                            alt="미리보기"
                            className="max-h-48 rounded-md object-contain mx-auto"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-1 right-1 h-6 w-6 rounded-full"
                            onClick={() => setNewImage(null)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="edit-tags">태그</Label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {newTags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                          {tag}
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-4 w-4 rounded-full"
                            onClick={() => removeTag(tag)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </Badge>
                      ))}
                    </div>
                    <Select onValueChange={addTag}>
                      <SelectTrigger>
                        <SelectValue placeholder="태그 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTags
                          .filter((tag) => !newTags.includes(tag))
                          .map((tag) => (
                            <SelectItem key={tag} value={tag}>
                              {tag}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      id="edit-important"
                      type="checkbox"
                      className="h-4 w-4"
                      checked={newImportant}
                      onChange={(e) => setNewImportant(e.target.checked)}
                    />
                    <Label htmlFor="edit-important">중요 메모로 표시</Label>
                  </div>
                </div>
              ) : (
                <div className="py-4">
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-sm text-muted-foreground">
                      {formatDate(selectedMemo.date)} {formatTime(selectedMemo.createdAt)}
                    </div>
                    <div className="flex flex-wrap gap-1 justify-end">
                      {selectedMemo.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {selectedMemo.imageUrl && (
                    <div className="mb-4">
                      <img
                        src={selectedMemo.imageUrl || "/placeholder.svg"}
                        alt={selectedMemo.title}
                        className="max-h-64 rounded-md object-contain mx-auto"
                      />
                    </div>
                  )}

                  <div className="whitespace-pre-line mb-4">{selectedMemo.content}</div>

                  {selectedMemo.updatedAt !== selectedMemo.createdAt && (
                    <div className="text-xs text-muted-foreground mt-4">
                      마지막 수정: {formatDate(selectedMemo.updatedAt)} {formatTime(selectedMemo.updatedAt)}
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          <DialogFooter>
            {isEditing ? (
              <>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsEditing(false)
                    if (selectedMemo) {
                      setNewTitle(selectedMemo.title)
                      setNewContent(selectedMemo.content)
                      setNewTags(selectedMemo.tags)
                      setNewImportant(selectedMemo.important)
                      setNewImage(selectedMemo.imageUrl || null)
                    }
                  }}
                >
                  취소
                </Button>
                <Button type="button" onClick={handleUpdateMemo}>
                  저장
                </Button>
              </>
            ) : (
              <Button type="button" variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                닫기
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 메모 삭제 확인 다이얼로그 */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>메모 삭제</DialogTitle>
            <DialogDescription>이 메모를 정말 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button type="button" variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              취소
            </Button>
            <Button type="button" variant="destructive" onClick={handleDeleteMemo}>
              삭제
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

