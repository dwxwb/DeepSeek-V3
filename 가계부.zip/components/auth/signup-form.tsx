"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserPlus, LogIn, Mail, Phone, Home, User } from "lucide-react"

export default function SignupForm({ onClose }: { onClose?: () => void }) {
  const [activeTab, setActiveTab] = useState("signup")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [signupSuccess, setSignupSuccess] = useState(false)
  const [loginSuccess, setLoginSuccess] = useState(false)

  // 회원가입 처리
  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // 실제 구현에서는 여기에 API 호출 코드가 들어갈 것입니다.
    setTimeout(() => {
      setIsSubmitting(false)
      setSignupSuccess(true)

      // 성공 메시지 표시 후 로그인 탭으로 전환
      setTimeout(() => {
        setSignupSuccess(false)
        setActiveTab("login")
      }, 2000)
    }, 1000)
  }

  // 로그인 처리
  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // 실제 구현에서는 여기에 API 호출 코드가 들어갈 것입니다.
    setTimeout(() => {
      setIsSubmitting(false)
      setLoginSuccess(true)

      // 성공 메시지 표시 후 모달 닫기
      setTimeout(() => {
        setLoginSuccess(false)
        if (onClose) onClose()
      }, 2000)
    }, 1000)
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>
          {activeTab === "signup" ? (
            <div className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              회원가입
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <LogIn className="h-5 w-5" />
              로그인
            </div>
          )}
        </CardTitle>
        <CardDescription>
          {activeTab === "signup" ? "계정을 만들고 모든 기능을 이용하세요" : "계정에 로그인하여 서비스를 이용하세요"}
        </CardDescription>
      </CardHeader>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="signup">회원가입</TabsTrigger>
          <TabsTrigger value="login">로그인</TabsTrigger>
        </TabsList>

        <TabsContent value="signup">
          <CardContent>
            <form onSubmit={handleSignup} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="name" className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  성함
                </Label>
                <Input id="name" name="name" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="email" className="flex items-center gap-1">
                  <Mail className="h-4 w-4" />
                  이메일
                </Label>
                <Input id="email" name="email" type="email" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="phone" className="flex items-center gap-1">
                  <Phone className="h-4 w-4" />
                  연락처
                </Label>
                <Input id="phone" name="phone" placeholder="010-0000-0000" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="address" className="flex items-center gap-1">
                  <Home className="h-4 w-4" />
                  주소
                </Label>
                <Input id="address" name="address" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="password">비밀번호</Label>
                <Input id="password" name="password" type="password" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="password-confirm">비밀번호 확인</Label>
                <Input id="password-confirm" name="passwordConfirm" type="password" required />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="terms" required />
                <Label htmlFor="terms" className="text-sm">
                  이용약관 및 개인정보 처리방침에 동의합니다
                </Label>
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "처리 중..." : "회원가입"}
              </Button>

              {signupSuccess && (
                <div className="p-2 bg-green-50 text-green-600 rounded-md text-center">
                  회원가입이 완료되었습니다. 로그인 페이지로 이동합니다.
                </div>
              )}
            </form>
          </CardContent>
        </TabsContent>

        <TabsContent value="login">
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="login-email">이메일</Label>
                <Input id="login-email" name="email" type="email" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="login-password">비밀번호</Label>
                <Input id="login-password" name="password" type="password" required />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id="remember" />
                  <Label htmlFor="remember" className="text-sm">
                    로그인 상태 유지
                  </Label>
                </div>
                <Button variant="link" size="sm" className="px-0">
                  비밀번호 찾기
                </Button>
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "로그인 중..." : "로그인"}
              </Button>

              {loginSuccess && (
                <div className="p-2 bg-green-50 text-green-600 rounded-md text-center">로그인이 완료되었습니다.</div>
              )}
            </form>
          </CardContent>
        </TabsContent>
      </Tabs>
      <CardFooter className="flex justify-center border-t pt-4">
        <Button variant="link" onClick={() => setActiveTab(activeTab === "signup" ? "login" : "signup")}>
          {activeTab === "signup" ? "이미 계정이 있으신가요? 로그인" : "계정이 없으신가요? 회원가입"}
        </Button>
      </CardFooter>
    </Card>
  )
}

