"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { CreditCard, Building, RefreshCw, AlertTriangle, Link2OffIcon as LinkOff, Clock, Download } from "lucide-react"
import { getEmojiForCategoryName } from "@/lib/category-data"

// 가상의 은행 및 카드사 데이터
const banks = [
  { id: 1, name: "신한은행", logo: "/placeholder.svg?height=40&width=40", color: "#0046ff" },
  { id: 2, name: "국민은행", logo: "/placeholder.svg?height=40&width=40", color: "#ffd900" },
  { id: 3, name: "우리은행", logo: "/placeholder.svg?height=40&width=40", color: "#0067a3" },
  { id: 4, name: "하나은행", logo: "/placeholder.svg?height=40&width=40", color: "#00a37f" },
  { id: 5, name: "농협은행", logo: "/placeholder.svg?height=40&width=40", color: "#0091d0" },
]

const cards = [
  { id: 1, name: "신한카드", logo: "/placeholder.svg?height=40&width=40", color: "#0046ff" },
  { id: 2, name: "삼성카드", logo: "/placeholder.svg?height=40&width=40", color: "#0067a3" },
  { id: 3, name: "현대카드", logo: "/placeholder.svg?height=40&width=40", color: "#333333" },
  { id: 4, name: "KB국민카드", logo: "/placeholder.svg?height=40&width=40", color: "#ffd900" },
  { id: 5, name: "롯데카드", logo: "/placeholder.svg?height=40&width=40", color: "#da291c" },
]

// 가상의 연결된 계정 데이터
const initialConnectedAccounts = [
  {
    id: 1,
    type: "bank",
    name: "신한은행",
    accountNumber: "110-123-456789",
    balance: 1250000,
    lastSync: "2024-03-28 14:30",
    autoSync: true,
    color: "#0046ff",
  },
  {
    id: 2,
    type: "card",
    name: "삼성카드",
    accountNumber: "5412-XXXX-XXXX-1234",
    balance: -450000,
    lastSync: "2024-03-28 14:30",
    autoSync: true,
    color: "#0067a3",
  },
]

// 가상의 거래 내역 데이터
const transactionHistory = [
  {
    id: 1,
    date: "2024-03-28",
    time: "12:30",
    description: "스타벅스 강남점",
    amount: -5800,
    balance: 1244200,
    category: "식비",
    account: "신한은행",
    accountType: "bank",
  },
  {
    id: 2,
    date: "2024-03-28",
    time: "10:15",
    description: "교통비",
    amount: -1250,
    balance: 1250000,
    category: "교통비",
    account: "신한은행",
    accountType: "bank",
  },
  {
    id: 3,
    date: "2024-03-27",
    time: "19:45",
    description: "이마트 성수점",
    amount: -45600,
    balance: 1251250,
    category: "쇼핑",
    account: "삼성카드",
    accountType: "card",
  },
  {
    id: 4,
    date: "2024-03-27",
    time: "12:30",
    description: "월급",
    amount: 3000000,
    balance: 1296850,
    category: "급여",
    account: "신한은행",
    accountType: "bank",
  },
  {
    id: 5,
    date: "2024-03-26",
    time: "20:15",
    description: "넷플릭스",
    amount: -17000,
    balance: -1703150,
    category: "구독",
    account: "삼성카드",
    accountType: "card",
  },
]

export default function AccountSync() {
  const [activeTab, setActiveTab] = useState("accounts")
  const [connectedAccounts, setConnectedAccounts] = useState(initialConnectedAccounts)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isSyncing, setIsSyncing] = useState(false)
  const [openConnectBank, setOpenConnectBank] = useState(false)
  const [openConnectCard, setOpenConnectCard] = useState(false)
  const [selectedAccountType, setSelectedAccountType] = useState<"bank" | "card" | null>(null)
  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null)

  // 계정 연결 처리
  const handleConnect = (type: "bank" | "card", id: number) => {
    setIsConnecting(true)

    // 실제 구현에서는 여기에 은행/카드사 API 연동 코드가 들어갈 것입니다.
    setTimeout(() => {
      const newAccount =
        type === "bank"
          ? {
              id: connectedAccounts.length + 1,
              type: "bank",
              name: banks.find((b) => b.id === id)?.name || "",
              accountNumber: `110-${Math.floor(Math.random() * 1000)}-${Math.floor(Math.random() * 1000000)}`,
              balance: Math.floor(Math.random() * 10000000),
              lastSync: new Date().toLocaleString(),
              autoSync: true,
              color: banks.find((b) => b.id === id)?.color || "#000000",
            }
          : {
              id: connectedAccounts.length + 1,
              type: "card",
              name: cards.find((c) => c.id === id)?.name || "",
              accountNumber: `${Math.floor(Math.random() * 10000)}-XXXX-XXXX-${Math.floor(Math.random() * 10000)}`,
              balance: -Math.floor(Math.random() * 1000000),
              lastSync: new Date().toLocaleString(),
              autoSync: true,
              color: cards.find((c) => c.id === id)?.color || "#000000",
            }

      setConnectedAccounts([...connectedAccounts, newAccount])
      setIsConnecting(false)

      if (type === "bank") {
        setOpenConnectBank(false)
      } else {
        setOpenConnectCard(false)
      }
    }, 2000)
  }

  // 계정 연결 해제 처리
  const handleDisconnect = (id: number) => {
    setConnectedAccounts(connectedAccounts.filter((account) => account.id !== id))
  }

  // 자동 동기화 설정 변경
  const handleAutoSyncChange = (id: number, checked: boolean) => {
    setConnectedAccounts(
      connectedAccounts.map((account) => (account.id === id ? { ...account, autoSync: checked } : account)),
    )
  }

  // 수동 동기화 처리
  const handleManualSync = () => {
    setIsSyncing(true)

    // 실제 구현에서는 여기에 은행/카드사 API 동기화 코드가 들어갈 것입니다.
    setTimeout(() => {
      setConnectedAccounts(
        connectedAccounts.map((account) => ({
          ...account,
          lastSync: new Date().toLocaleString(),
        })),
      )
      setIsSyncing(false)
      alert("모든 계정이 성공적으로 동기화되었습니다!")
    }, 2000)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">계좌/카드 연동</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleManualSync} disabled={isSyncing || connectedAccounts.length === 0}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isSyncing ? "animate-spin" : ""}`} />
            {isSyncing ? "동기화 중..." : "수동 동기화"}
          </Button>
          <Dialog open={openConnectBank} onOpenChange={setOpenConnectBank}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Building className="mr-2 h-4 w-4" />
                은행 연결
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>은행 계좌 연결</DialogTitle>
                <DialogDescription>연결할 은행을 선택하세요</DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                {banks.map((bank) => (
                  <Button
                    key={bank.id}
                    variant="outline"
                    className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                    style={{ borderColor: bank.color }}
                    onClick={() => handleConnect("bank", bank.id)}
                    disabled={isConnecting}
                  >
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: bank.color }}
                    >
                      <Building className="h-5 w-5 text-white" />
                    </div>
                    <span>{bank.name}</span>
                  </Button>
                ))}
              </div>
              {isConnecting && (
                <div className="flex items-center justify-center p-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mr-2"></div>
                  <span>연결 중...</span>
                </div>
              )}
            </DialogContent>
          </Dialog>

          <Dialog open={openConnectCard} onOpenChange={setOpenConnectCard}>
            <DialogTrigger asChild>
              <Button>
                <CreditCard className="mr-2 h-4 w-4" />
                카드 연결
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>신용/체크카드 연결</DialogTitle>
                <DialogDescription>연결할 카드사를 선택하세요</DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                {cards.map((card) => (
                  <Button
                    key={card.id}
                    variant="outline"
                    className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                    style={{ borderColor: card.color }}
                    onClick={() => handleConnect("card", card.id)}
                    disabled={isConnecting}
                  >
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: card.color }}
                    >
                      <CreditCard className="h-5 w-5 text-white" />
                    </div>
                    <span>{card.name}</span>
                  </Button>
                ))}
              </div>
              {isConnecting && (
                <div className="flex items-center justify-center p-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mr-2"></div>
                  <span>연결 중...</span>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="accounts">연결된 계정</TabsTrigger>
          <TabsTrigger value="transactions">거래 내역</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts">
          <Card>
            <CardHeader>
              <CardTitle>연결된 계정</CardTitle>
              <CardDescription>연결된 은행 계좌 및 카드 목록</CardDescription>
            </CardHeader>
            <CardContent>
              {connectedAccounts.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 bg-muted rounded-md">
                  <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-center text-muted-foreground mb-4">연결된 계정이 없습니다.</p>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setOpenConnectBank(true)}>
                      <Building className="mr-2 h-4 w-4" />
                      은행 연결
                    </Button>
                    <Button onClick={() => setOpenConnectCard(true)}>
                      <CreditCard className="mr-2 h-4 w-4" />
                      카드 연결
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {connectedAccounts.map((account) => (
                      <div
                        key={account.id}
                        className="border rounded-lg p-4 relative"
                        style={{ borderColor: account.color }}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-10 h-10 rounded-full flex items-center justify-center"
                              style={{ backgroundColor: account.color }}
                            >
                              {account.type === "bank" ? (
                                <Building className="h-5 w-5 text-white" />
                              ) : (
                                <CreditCard className="h-5 w-5 text-white" />
                              )}
                            </div>
                            <div>
                              <h3 className="font-medium">{account.name}</h3>
                              <p className="text-sm text-muted-foreground">{account.accountNumber}</p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-muted-foreground hover:text-destructive"
                            onClick={() => handleDisconnect(account.id)}
                          >
                            <LinkOff className="h-4 w-4" />
                          </Button>
                        </div>

                        <div className="mt-4">
                          <p className="text-sm text-muted-foreground">잔액</p>
                          <p className={`text-xl font-bold ${account.balance < 0 ? "text-red-600" : ""}`}>
                            {account.balance.toLocaleString()}원
                          </p>
                        </div>

                        <div className="mt-4 flex items-center justify-between">
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span>마지막 동기화: {account.lastSync}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs">자동 동기화</span>
                            <Switch
                              checked={account.autoSync}
                              onCheckedChange={(checked) => handleAutoSyncChange(account.id, checked)}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <p className="text-sm text-muted-foreground">
                {connectedAccounts.length > 0
                  ? `총 ${connectedAccounts.length}개의 계정이 연결되어 있습니다.`
                  : "연결된 계정이 없습니다."}
              </p>
              {connectedAccounts.length > 0 && (
                <Button variant="outline" onClick={handleManualSync} disabled={isSyncing}>
                  <RefreshCw className={`mr-2 h-4 w-4 ${isSyncing ? "animate-spin" : ""}`} />
                  {isSyncing ? "동기화 중..." : "수동 동기화"}
                </Button>
              )}
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="transactions">
          <Card>
            <CardHeader>
              <CardTitle>거래 내역</CardTitle>
              <CardDescription>연결된 계정의 모든 거래 내역</CardDescription>
            </CardHeader>
            <CardContent>
              {connectedAccounts.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 bg-muted rounded-md">
                  <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-center text-muted-foreground mb-4">연결된 계정이 없습니다.</p>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setOpenConnectBank(true)}>
                      <Building className="mr-2 h-4 w-4" />
                      은행 연결
                    </Button>
                    <Button onClick={() => setOpenConnectCard(true)}>
                      <CreditCard className="mr-2 h-4 w-4" />
                      카드 연결
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                      <Select defaultValue="all">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="계정 선택" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">모든 계정</SelectItem>
                          {connectedAccounts.map((account) => (
                            <SelectItem key={account.id} value={account.id.toString()}>
                              {account.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select defaultValue="all">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="카테고리 선택" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">모든 카테고리</SelectItem>
                          <SelectItem value="식비">식비</SelectItem>
                          <SelectItem value="교통비">교통비</SelectItem>
                          <SelectItem value="쇼핑">쇼핑</SelectItem>
                          <SelectItem value="구독">구독</SelectItem>
                          <SelectItem value="급여">급여</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>날짜</TableHead>
                        <TableHead>내용</TableHead>
                        <TableHead>카테고리</TableHead>
                        <TableHead>계정</TableHead>
                        <TableHead className="text-right">금액</TableHead>
                        <TableHead className="text-right">잔액</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactionHistory.map((transaction) => (
                        <TableRow key={transaction.id}>
                          <TableCell>
                            <div>
                              <div>{transaction.date}</div>
                              <div className="text-xs text-muted-foreground">{transaction.time}</div>
                            </div>
                          </TableCell>
                          <TableCell>{transaction.description}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="flex items-center gap-1 w-fit">
                              <span role="img" aria-label={transaction.category}>
                                {getEmojiForCategoryName(transaction.category)}
                              </span>
                              {transaction.category}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              {transaction.accountType === "bank" ? (
                                <Building className="h-3 w-3 text-muted-foreground" />
                              ) : (
                                <CreditCard className="h-3 w-3 text-muted-foreground" />
                              )}
                              <span>{transaction.account}</span>
                            </div>
                          </TableCell>
                          <TableCell
                            className={`text-right font-medium ${transaction.amount < 0 ? "text-red-600" : "text-green-600"}`}
                          >
                            {transaction.amount.toLocaleString()}원
                          </TableCell>
                          <TableCell className="text-right">{transaction.balance.toLocaleString()}원</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <p className="text-sm text-muted-foreground">총 {transactionHistory.length}개의 거래 내역</p>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                내보내기
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

