"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

// 가상의 광고 데이터
const ads = [
  {
    id: 1,
    title: "프리미엄 회계 서비스 출시!",
    description: "더 빠르고 정확한 재무 관리를 위한 프리미엄 서비스를 지금 이용해보세요.",
    bgColor: "bg-blue-50",
    textColor: "text-blue-800",
    buttonColor: "bg-blue-600 hover:bg-blue-700",
    buttonText: "자세히 보기",
    link: "#premium-service",
  },
  {
    id: 2,
    title: "세금 신고 시즌 할인 이벤트",
    description: "연말정산 시즌을 맞아 모든 서비스 20% 할인 중입니다.",
    bgColor: "bg-green-50",
    textColor: "text-green-800",
    buttonColor: "bg-green-600 hover:bg-green-700",
    buttonText: "할인 받기",
    link: "#discount-event",
  },
  {
    id: 3,
    title: "모바일 앱 출시 기념 이벤트",
    description: "언제 어디서나 재무 관리를 할 수 있는 모바일 앱을 지금 다운로드하세요.",
    bgColor: "bg-purple-50",
    textColor: "text-purple-800",
    buttonColor: "bg-purple-600 hover:bg-purple-700",
    buttonText: "앱 다운로드",
    link: "#mobile-app",
  },
  {
    id: 4,
    title: "재무 관리 웨비나 참가자 모집",
    description: "전문가와 함께하는 무료 재무 관리 웨비나에 참가하세요.",
    bgColor: "bg-orange-50",
    textColor: "text-orange-800",
    buttonColor: "bg-orange-600 hover:bg-orange-700",
    buttonText: "신청하기",
    link: "#webinar",
  },
]

export default function AdBanner() {
  const [currentAd, setCurrentAd] = useState(ads[0])
  const [dismissed, setDismissed] = useState(false)

  // 일정 시간마다 광고 변경
  useEffect(() => {
    if (dismissed) return

    const interval = setInterval(() => {
      setCurrentAd((prevAd) => {
        const currentIndex = ads.findIndex((ad) => ad.id === prevAd.id)
        const nextIndex = (currentIndex + 1) % ads.length
        return ads[nextIndex]
      })
    }, 10000) // 10초마다 변경

    return () => clearInterval(interval)
  }, [dismissed])

  if (dismissed) return null

  return (
    <Card className={`mb-4 overflow-hidden ${currentAd.bgColor}`}>
      <CardContent className="p-0">
        <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-6 w-6 rounded-full bg-white/80 text-gray-500 hover:bg-white hover:text-gray-700"
            onClick={() => setDismissed(true)}
          >
            <X className="h-4 w-4" />
          </Button>

          <div className="p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className={`${currentAd.textColor}`}>
              <h3 className="font-bold text-lg">{currentAd.title}</h3>
              <p className="text-sm">{currentAd.description}</p>
            </div>

            <Button
              className={`whitespace-nowrap ${currentAd.buttonColor}`}
              onClick={() => (window.location.href = currentAd.link)}
            >
              {currentAd.buttonText}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

