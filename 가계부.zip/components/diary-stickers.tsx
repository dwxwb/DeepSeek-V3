"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// 스티커 데이터
const stickers = [
  // 동물 카테고리
  {
    id: "monkey",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "원숭이",
    category: "animals",
  },
  {
    id: "rabbit",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "토끼",
    category: "animals",
  },
  {
    id: "dog",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "강아지",
    category: "animals",
  },
  {
    id: "panda",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "판다",
    category: "animals",
  },
  {
    id: "cat",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "고양이",
    category: "animals",
  },

  // 음식 카테고리
  {
    id: "cake",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "케이크",
    category: "food",
  },
  {
    id: "fruits",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "과일",
    category: "food",
  },
  {
    id: "icecream",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "아이스크림",
    category: "food",
  },

  // 자연 카테고리
  {
    id: "rainbow",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "무지개",
    category: "nature",
  },
  {
    id: "sun",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "태양",
    category: "nature",
  },

  // 이모지 카테고리
  {
    id: "smile",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "스마일",
    category: "emoji",
  },
  {
    id: "princess",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "공주",
    category: "emoji",
  },
  {
    id: "hearts",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jpg-rhjlP5l21veXt2qE1C1Du66kDfNl7Q.jpeg",
    label: "하트",
    category: "emoji",
  },
]

interface DiaryStickerProps {
  onSelectSticker: (stickerId: string) => void
  selectedStickers: string[]
}

export default function DiaryStickers({ onSelectSticker, selectedStickers }: DiaryStickerProps) {
  const [activeCategory, setActiveCategory] = useState("all")

  // 카테고리별 스티커 필터링
  const filteredStickers =
    activeCategory === "all" ? stickers : stickers.filter((sticker) => sticker.category === activeCategory)

  return (
    <div>
      <Tabs value={activeCategory} onValueChange={setActiveCategory}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">전체</TabsTrigger>
          <TabsTrigger value="animals">동물</TabsTrigger>
          <TabsTrigger value="food">음식</TabsTrigger>
          <TabsTrigger value="nature">자연</TabsTrigger>
          <TabsTrigger value="emoji">이모지</TabsTrigger>
        </TabsList>

        <TabsContent value={activeCategory} className="mt-4">
          <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
            {filteredStickers.map((sticker) => (
              <div
                key={sticker.id}
                className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                  selectedStickers.includes(sticker.id) ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => onSelectSticker(sticker.id)}
              >
                <div className="aspect-square flex items-center justify-center">
                  <img
                    src={sticker.url || "/placeholder.svg"}
                    alt={sticker.label}
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
                <p className="text-xs text-center mt-1">{sticker.label}</p>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

