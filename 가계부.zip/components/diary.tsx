"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Smile, Heart, BookOpen, Lightbulb, Target, Activity, Book, Palette, Bookmark, Save } from "lucide-react"
import { format, parseISO, isToday, isYesterday, isSameYear } from "date-fns"
import { ko } from "date-fns/locale"

// 템플릿 데이터 (diary-templates.tsx와 동일)
const templates = [
  {
    id: "default",
    name: "기본",
    bgColor: "#ffffff",
    textColor: "#000000",
    fontFamily: "'Noto Sans KR', sans-serif",
  },
  {
    id: "minimal",
    name: "미니멀",
    bgColor: "#f8f9fa",
    textColor: "#343a40",
    fontFamily: "'Noto Sans KR', sans-serif",
  },
  {
    id: "vintage",
    name: "빈티지",
    bgColor: "#f8f3e6",
    textColor: "#5c4b3c",
    fontFamily: "'Nanum Myeongjo', serif",
  },
  {
    id: "nature",
    name: "자연",
    bgColor: "#e8f5e9",
    textColor: "#2e7d32",
    fontFamily: "'Nanum Pen Script', cursive",
  },
  {
    id: "dreamy",
    name: "드림",
    bgColor: "#e3f2fd",
    textColor: "#1565c0",
    fontFamily: "'Gaegu', cursive",
  },
  {
    id: "love",
    name: "러브",
    bgColor: "#fce4ec",
    textColor: "#c2185b",
    fontFamily: "'Gamja Flower', cursive",
  },
  {
    id: "dark",
    name: "다크",
    bgColor: "#212121",
    textColor: "#e0e0e0",
    fontFamily: "'Noto Sans KR', sans-serif",
  },
  {
    id: "bright",
    name: "밝음",
    bgColor: "#fff9c4",
    textColor: "#f57f17",
    fontFamily: "'Jua', sans-serif",
  },
  {
    id: "music",
    name: "음악",
    bgColor: "#e8eaf6",
    textColor: "#3949ab",
    fontFamily: "'Poor Story', cursive",
  },
]

// 감정 타입
type Mood = "happy" | "good" | "neutral" | "bad" | "sad"

// 일기 타입 정의
interface Diary {
  id: number
  date: string
  title: string
  content: string
  mood: Mood
  events: string[]
  thoughts: string
  ideas: string
  goals: string
  gratitude: string
  health: string
  learning: string
  images: string[]
  future: string
  tags: string[]
  favorite: boolean
  createdAt: string
  updatedAt: string
}

interface DiaryProps {
  selectedDate: Date
  template: string
  textColor: string
  bgColor: string
}

// 가상의 일기 데이터
const initialDiaries: Diary[] = [
  {
    id: 1,
    date: "2024-04-15",
    title: "새로운 프로젝트 시작",
    content:
      "오늘부터 새로운 프로젝트를 시작했다. 팀원들과 함께 아이디어를 공유하고 계획을 세웠다. 모두 열정적으로 참여해서 좋은 시작이 될 것 같다.",
    mood: "happy",
    events: ["프로젝트 킥오프 미팅", "팀 점심 식사"],
    thoughts: "새로운 시작은 항상 설레는 것 같다. 이번 프로젝트도 잘 해낼 수 있을 것이라는 자신감이 생긴다.",
    ideas: "사용자 경험을 개선하기 위한 새로운 인터페이스 아이디어가 떠올랐다. 내일 팀원들과 공유해봐야겠다.",
    goals: "이번 주까지 기획안 완성하기, 다음 주 월요일까지 프로토타입 만들기",
    gratitude: "좋은 팀원들과 함께 일할 수 있어 감사하다.",
    health: "오늘 퇴근 후 30분 조깅, 물 2L 마심",
    learning: "새로운 디자인 툴 사용법을 익히기 시작했다.",
    images: ["/placeholder.svg?height=300&width=400"],
    future: "이 프로젝트를 통해 새로운 기술을 많이 배우고 성장할 수 있을 것 같다.",
    tags: ["프로젝트", "시작", "팀워크"],
    favorite: true,
    createdAt: "2024-04-15T22:30:00",
    updatedAt: "2024-04-15T22:30:00",
  },
  {
    id: 2,
    date: "2024-04-14",
    title: "주말 여행",
    content:
      "친구들과 함께 바다로 당일 여행을 다녀왔다. 날씨가 정말 좋아서 바다가 더 아름다웠다. 오랜만에 마음껏 웃고 떠들며 스트레스를 풀 수 있었다.",
    mood: "happy",
    events: ["바다 여행", "해산물 점심", "일몰 감상"],
    thoughts: "일상에서 벗어나 자연을 느끼는 것이 얼마나 중요한지 다시 한번 깨달았다.",
    ideas: "다음 여행은 산으로 가보는 것도 좋을 것 같다.",
    goals: "한 달에 한 번은 자연 속에서 시간을 보내기",
    gratitude: "좋은 친구들, 좋은 날씨, 맛있는 음식에 감사하다.",
    health: "많이 걸어서 좋은 운동이 되었다.",
    learning: "조개 종류에 대해 새롭게 알게 되었다.",
    images: ["/placeholder.svg?height=300&width=400", "/placeholder.svg?height=300&width=400"],
    future: "다음 달에는 가족들과 함께 2박 3일 여행을 계획해봐야겠다.",
    tags: ["여행", "바다", "친구", "힐링"],
    favorite: true,
    createdAt: "2024-04-14T21:15:00",
    updatedAt: "2024-04-14T21:15:00",
  },
  {
    id: 3,
    date: "2024-04-13",
    title: "독서와 사색의 날",
    content:
      "오늘은 집에서 조용히 책을 읽으며 시간을 보냈다. 오랫동안 읽고 싶었던 '사피엔스'를 드디어 시작했다. 인류의 역사와 문명에 대한 새로운 시각을 얻을 수 있었다.",
    mood: "good",
    events: ["독서", "홈 카페"],
    thoughts: "책을 통해 다양한 관점을 접하는 것이 얼마나 중요한지 다시 한번 느꼈다.",
    ideas: "역사 관련 다큐멘터리도 찾아보면 좋을 것 같다.",
    goals: "한 달에 책 2권 읽기",
    gratitude: "조용히 독서할 수 있는 시간과 공간에 감사하다.",
    health: "스트레칭 20분, 명상 10분",
    learning: "인류 문명의 발전 과정에 대해 배웠다.",
    images: [],
    future: "다양한 분야의 책을 읽으며 지식을 넓혀가고 싶다.",
    tags: ["독서", "사피엔스", "자기계발"],
    favorite: false,
    createdAt: "2024-04-13T20:45:00",
    updatedAt: "2024-04-13T20:45:00",
  },
  {
    id: 4,
    date: "2024-04-10",
    title: "힘든 하루",
    content:
      "오늘은 업무가 많아 정신없이 바쁜 하루였다. 예상치 못한 문제가 발생해서 해결하느라 야근까지 했다. 피곤하지만 문제를 해결했다는 뿌듯함도 있다.",
    mood: "bad",
    events: ["긴급 회의", "문제 해결", "야근"],
    thoughts: "힘든 상황에서도 침착하게 대처하는 법을 배우는 중이다.",
    ideas: "비슷한 문제가 발생하지 않도록 프로세스를 개선해야겠다.",
    goals: "업무 효율성 높이기, 스트레스 관리하기",
    gratitude: "함께 고생한 동료들에게 감사하다.",
    health: "스트레스로 인해 두통이 있었다. 충분한 휴식이 필요하다.",
    learning: "위기 상황에서의 문제 해결 능력이 향상되었다.",
    images: [],
    future: "이런 상황에 더 잘 대처할 수 있도록 준비해야겠다.",
    tags: ["업무", "스트레스", "문제해결"],
    favorite: false,
    createdAt: "2024-04-10T23:10:00",
    updatedAt: "2024-04-10T23:10:00",
  },
  {
    id: 5,
    date: "2024-04-05",
    title: "새로운 취미 시작",
    content:
      "오늘부터 수채화 그리기를 시작했다. 유튜브 강의를 보며 기본적인 기법을 배웠다. 처음이라 서툴지만 그림을 그리는 과정 자체가 즐겁고 마음이 편안해졌다.",
    mood: "good",
    events: ["수채화 시작", "미술용품 쇼핑"],
    thoughts: "창작 활동이 주는 즐거움과 치유 효과를 느꼈다.",
    ideas: "매주 하나씩 다른 주제로 그림을 그려보면 좋을 것 같다.",
    goals: "기본 기법 익히기, 한 달 후에는 풍경화 그려보기",
    gratitude: "새로운 취미를 시작할 수 있는 여유에 감사하다.",
    health: "그림 그리는 동안 마음이 편안해졌다.",
    learning: "수채화의 기본 기법과 색 혼합에 대해 배웠다.",
    images: ["/placeholder.svg?height=300&width=400"],
    future: "꾸준히 연습해서 실력을 향상시키고 싶다.",
    tags: ["취미", "수채화", "예술", "시작"],
    favorite: true,
    createdAt: "2024-04-05T21:30:00",
    updatedAt: "2024-04-05T21:30:00",
  },
]

// 태그 목록
const availableTags = [
  "일상",
  "업무",
  "여행",
  "취미",
  "독서",
  "영화",
  "음악",
  "요리",
  "운동",
  "공부",
  "가족",
  "친구",
  "연애",
  "건강",
  "목표",
  "계획",
  "감사",
  "성찰",
  "성장",
  "도전",
  "성공",
  "실패",
  "행복",
  "슬픔",
]

// 이모티콘 목록
const emojis = [
  "😀",
  "😃",
  "😄",
  "😁",
  "😆",
  "😅",
  "😂",
  "🤣",
  "😊",
  "😇",
  "🙂",
  "🙃",
  "😉",
  "😌",
  "😍",
  "🥰",
  "😘",
  "😗",
  "😙",
  "😚",
  "😋",
  "😛",
  "😝",
  "😜",
  "🤪",
  "🤨",
  "🧐",
  "🤓",
  "😎",
  "🤩",
  "🥳",
  "😏",
  "😒",
  "😞",
  "😔",
  "😟",
  "😕",
  "🙁",
  "☹️",
  "😣",
  "😖",
  "😫",
  "😩",
  "🥺",
  "😢",
  "😭",
  "😤",
  "😠",
  "😡",
  "🤬",
  "🤯",
  "😳",
  "🥵",
  "🥶",
  "😱",
  "😨",
  "😰",
  "😥",
  "😓",
  "🤗",
  "🤔",
  "🤭",
  "🤫",
  "🤥",
  "😶",
  "😐",
  "😑",
  "😬",
  "🙄",
  "😯",
  "😦",
  "😧",
  "😮",
  "😲",
  "🥱",
  "😴",
  "🤤",
  "😪",
  "😵",
  "🤐",
  "🥴",
  "🤢",
  "🤮",
  "🤧",
  "😷",
  "🤒",
  "🤕",
  "🤑",
  "🤠",
  "😈",
  "👿",
  "👹",
  "👺",
  "🤡",
  "💩",
  "👻",
  "💀",
  "☠️",
  "👽",
  "👾",
]

// 스티커/그림 목록 (실제로는 이미지 URL이 들어갈 것입니다)
const stickers = [
  "/placeholder.svg?height=50&width=50&text=🌟",
  "/placeholder.svg?height=50&width=50&text=🌈",
  "/placeholder.svg?height=50&width=50&text=🌸",
  "/placeholder.svg?height=50&width=50&text=🎨",
  "/placeholder.svg?height=50&width=50&text=🎭",
  "/placeholder.svg?height=50&width=50&text=🎮",
  "/placeholder.svg?height=50&width=50&text=🎯",
  "/placeholder.svg?height=50&width=50&text=🎵",
  "/placeholder.svg?height=50&width=50&text=🏆",
  "/placeholder.svg?height=50&width=50&text=🏝️",
  "/placeholder.svg?height=50&width=50&text=🍕",
  "/placeholder.svg?height=50&width=50&text=🍦",
  "/placeholder.svg?height=50&width=50&text=🍷",
  "/placeholder.svg?height=50&width=50&text=🚗",
  "/placeholder.svg?height=50&width=50&text=✈️",
  "/placeholder.svg?height=50&width=50&text=📚",
  "/placeholder.svg?height=50&width=50&text=💻",
  "/placeholder.svg?height=50&width=50&text=📱",
  "/placeholder.svg?height=50&width=50&text=💰",
  "/placeholder.svg?height=50&width=50&text=💡",
  "/placeholder.svg?height=50&width=50&text=🎁",
  "/placeholder.svg?height=50&width=50&text=🎉",
  "/placeholder.svg?height=50&width=50&text=❤️",
  "/placeholder.svg?height=50&width=50&text=🌟",
  "/placeholder.svg?height=50&width=50&text=🔥",
  "/placeholder.svg?height=50&width=50&text=🌊",
  "/placeholder.svg?height=50&width=50&text=🌱",
]

// 이벤트 목록
const eventTypes = [
  "미팅",
  "여행",
  "생일",
  "기념일",
  "약속",
  "공연",
  "영화",
  "식사",
  "쇼핑",
  "운동",
  "독서",
  "공부",
  "요리",
  "청소",
  "휴식",
  "데이트",
]

export default function Diary({ selectedDate, template, textColor, bgColor }: DiaryProps) {
  const [diaries, setDiaries] = useState<Diary[]>(initialDiaries)
  const [activeTab, setActiveTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterTag, setFilterTag] = useState<string | null>(null)
  const [filterMood, setFilterMood] = useState<Mood | "all">("all")
  const [filterFavorite, setFilterFavorite] = useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedDiary, setSelectedDiary] = useState<Diary | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [activeSection, setActiveSection] = useState("main")
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [mood, setMood] = useState<Mood>("neutral")
  const [thoughts, setThoughts] = useState("")
  const [ideas, setIdeas] = useState("")
  const [goals, setGoals] = useState("")
  const [gratitude, setGratitude] = useState("")
  const [health, setHealth] = useState("")
  const [learning, setLearning] = useState("")
  const [future, setFuture] = useState("")

  // 새 일기 상태
  const [newTitle, setNewTitle] = useState("")
  const [newContent, setNewContent] = useState("")
  const [newMood, setNewMood] = useState<Mood>("neutral")
  const [newEvents, setNewEvents] = useState<string[]>([])
  const [newThoughts, setNewThoughts] = useState("")
  const [newIdeas, setNewIdeas] = useState("")
  const [newGoals, setNewGoals] = useState("")
  const [newGratitude, setNewGratitude] = useState("")
  const [newHealth, setNewHealth] = useState("")
  const [newLearning, setNewLearning] = useState("")
  const [newFuture, setNewFuture] = useState("")
  const [newTags, setNewTags] = useState<string[]>([])
  const [newFavorite, setNewFavorite] = useState(false)
  const [newImages, setNewImages] = useState<string[]>([])
  const [selectedEmojis, setSelectedEmojis] = useState<string[]>([])
  const [selectedStickers, setSelectedStickers] = useState<string[]>([])
  const [newEvent, setNewEvent] = useState("")

  // 파일 업로드 및 카메라 관련 ref
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // 브라우저 환경 확인
  const isBrowser = typeof window !== "undefined"
  const [isCameraAvailable, setIsCameraAvailable] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [isCapturing, setIsCapturing] = useState(false)
  const [isCameraActive, setIsCameraActive] = useState(false)

  // 선택된 템플릿 정보 가져오기
  const getTemplateInfo = () => {
    const selectedTemplate = templates.find((t) => t.id === template) || templates[0]
    return {
      fontFamily: selectedTemplate.fontFamily,
      // 사용자 지정 색상이 있으면 사용, 없으면 템플릿 기본 색상 사용
      bgColor: bgColor || selectedTemplate.bgColor,
      textColor: textColor || selectedTemplate.textColor,
    }
  }

  const templateInfo = getTemplateInfo()

  // 일기 저장
  const saveDiary = () => {
    if (!title) {
      alert("제목을 입력해주세요.")
      return
    }

    // 실제 구현에서는 여기서 API 호출 등을 통해 저장할 수 있습니다
    alert("일기가 저장되었습니다.")
  }

  // 카메라 지원 여부 확인
  useEffect(() => {
    if (!isBrowser) return

    const checkCameraAvailability = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setCameraError("이 브라우저는 카메라 접근을 지원하지 않습니다.")
          return
        }

        // 카메라 사용 가능 여부 확인
        const stream = await navigator.mediaDevices.getUserMedia({ video: true })
        stream.getTracks().forEach((track) => track.stop())
        setIsCameraAvailable(true)
      } catch (error) {
        console.error("카메라 확인 중 오류:", error)
        setCameraError("카메라에 접근할 수 없습니다. 권한을 확인해주세요.")
      }
    }

    checkCameraAvailability()
  }, [isBrowser])

  // 카메라 시작
  const startCamera = async () => {
    if (!isBrowser || !isCameraAvailable) return

    try {
      // 이미 실행 중인 스트림이 있으면 중지
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }

      // 새 스트림 시작
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      streamRef.current = stream

      // videoRef가 유효한지 확인 후 srcObject 설정
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsCameraActive(true)
      } else {
        console.warn("비디오 요소가 아직 준비되지 않았습니다.")
        // 스트림 정리
        stream.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }
    } catch (error) {
      console.error("카메라 접근 오류:", error)
      setCameraError("카메라에 접근할 수 없습니다. 권한을 확인해주세요.")
      setIsCameraAvailable(false)
    }
  }

  // 카메라 중지
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setIsCameraActive(false)
  }

  // 사진 촬영
  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return

    setIsCapturing(true)

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (context && video.videoWidth && video.videoHeight) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      context.drawImage(video, 0, 0, canvas.width, canvas.height)

      // 캡처한 이미지를 데이터 URL로 변환
      const imageDataUrl = canvas.toDataURL("image/jpeg")
      setNewImages([...newImages, imageDataUrl])

      // 카메라 중지
      stopCamera()
    }

    setIsCapturing(false)
  }

  // 파일 업로드 처리
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    const newImageUrls: string[] = []

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (evt) => {
        if (evt.target?.result) {
          newImageUrls.push(evt.target.result as string)
          if (newImageUrls.length === files.length) {
            setNewImages([...newImages, ...newImageUrls])
          }
        }
      }
      reader.readAsDataURL(file)
    })
  }

  // 필터링된 일기 가져오기
  const getFilteredDiaries = () => {
    return diaries.filter((diary) => {
      // 탭 필터링
      if (activeTab === "today" && !isToday(parseISO(diary.date))) return false
      if (activeTab === "favorite" && !diary.favorite) return false

      // 검색어 필터링
      const matchesSearch =
        searchTerm === "" ||
        diary.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        diary.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        diary.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

      // 태그 필터링
      const matchesTag = filterTag === null || diary.tags.includes(filterTag)

      // 감정 필터링
      const matchesMood = filterMood === "all" || diary.mood === filterMood

      // 즐겨찾기 필터링
      const matchesFavorite = !filterFavorite || diary.favorite

      return matchesSearch && matchesTag && matchesMood && matchesFavorite
    })
  }

  // 일기 추가
  const handleAddDiary = () => {
    if (!newTitle || !newContent || !selectedDate) {
      alert("제목과 내용을 입력해주세요.")
      return
    }

    const now = new Date().toISOString()
    const newDiary: Diary = {
      id: diaries.length > 0 ? Math.max(...diaries.map((diary) => diary.id)) + 1 : 1,
      date: format(selectedDate, "yyyy-MM-dd"),
      title: newTitle,
      content: newContent,
      mood: newMood,
      events: newEvents,
      thoughts: newThoughts,
      ideas: newIdeas,
      goals: newGoals,
      gratitude: newGratitude,
      health: newHealth,
      learning: newLearning,
      images: newImages,
      future: newFuture,
      tags: newTags,
      favorite: newFavorite,
      createdAt: now,
      updatedAt: now,
    }

    setDiaries([newDiary, ...diaries])
    resetForm()
    setIsAddDialogOpen(false)
  }

  // 일기 수정
  const handleUpdateDiary = () => {
    if (!selectedDiary || !newTitle || !newContent) {
      alert("제목과 내용을 입력해주세요.")
      return
    }

    const updatedDiaries = diaries.map((diary) => {
      if (diary.id === selectedDiary.id) {
        return {
          ...diary,
          title: newTitle,
          content: newContent,
          mood: newMood,
          events: newEvents,
          thoughts: newThoughts,
          ideas: newIdeas,
          goals: newGoals,
          gratitude: newGratitude,
          health: newHealth,
          learning: newLearning,
          images: newImages,
          future: newFuture,
          tags: newTags,
          favorite: newFavorite,
          updatedAt: new Date().toISOString(),
        }
      }
      return diary
    })

    setDiaries(updatedDiaries)
    setSelectedDiary(null)
    resetForm()
    setIsEditing(false)
    setIsViewDialogOpen(false)
  }

  // 일기 삭제
  const handleDeleteDiary = () => {
    if (!selectedDiary) return

    setDiaries(diaries.filter((diary) => diary.id !== selectedDiary.id))
    setSelectedDiary(null)
    setIsDeleteDialogOpen(false)
    setIsViewDialogOpen(false)
  }

  // 즐겨찾기 토글
  const toggleFavorite = (id: number) => {
    setDiaries(diaries.map((diary) => (diary.id === id ? { ...diary, favorite: !diary.favorite } : diary)))
  }

  // 일기 보기
  const handleViewDiary = (diary: Diary) => {
    setSelectedDiary(diary)
    setNewTitle(diary.title)
    setNewContent(diary.content)
    setNewMood(diary.mood)
    setNewEvents(diary.events)
    setNewThoughts(diary.thoughts)
    setNewIdeas(diary.ideas)
    setNewGoals(diary.goals)
    setNewGratitude(diary.gratitude)
    setNewHealth(diary.health)
    setNewLearning(diary.learning)
    setNewImages(diary.images)
    setNewFuture(diary.future)
    setNewTags(diary.tags)
    setNewFavorite(diary.favorite)
    setIsViewDialogOpen(true)
  }

  // 일기 편집 시작
  const startEditing = () => {
    setIsEditing(true)
  }

  // 폼 초기화
  const resetForm = () => {
    setNewTitle("")
    setNewContent("")
    setNewMood("neutral")
    setNewEvents([])
    setNewThoughts("")
    setNewIdeas("")
    setNewGoals("")
    setNewGratitude("")
    setNewHealth("")
    setNewLearning("")
    setNewImages([])
    setNewFuture("")
    setNewTags([])
    setNewFavorite(false)
    setSelectedEmojis([])
    setSelectedStickers([])
    setIsEditing(false)
    setActiveSection("main")
    stopCamera()
  }

  // 날짜 포맷팅
  const formatDate = (dateString: string) => {
    const date = parseISO(dateString)
    if (isToday(date)) return "오늘"
    if (isYesterday(date)) return "어제"

    if (isSameYear(date, new Date())) {
      return format(date, "M월 d일", { locale: ko })
    }

    return format(date, "yyyy년 M월 d일", { locale: ko })
  }

  // 시간 포맷팅
  const formatTime = (dateTimeString: string) => {
    const date = parseISO(dateTimeString)
    return format(date, "a h:mm", { locale: ko })
  }

  // 태그 추가
  const addTag = (tag: string) => {
    if (!newTags.includes(tag)) {
      setNewTags([...newTags, tag])
    }
  }

  // 태그 제거
  const removeTag = (tag: string) => {
    setNewTags(newTags.filter((t) => t !== tag))
  }

  // 이벤트 추가
  const addEvent = () => {
    if (newEvent && !newEvents.includes(newEvent)) {
      setNewEvents([...newEvents, newEvent])
      setNewEvent("")
    }
  }

  // 이벤트 제거
  const removeEvent = (event: string) => {
    setNewEvents(newEvents.filter((e) => e !== event))
  }

  // 이모티콘 토글
  const toggleEmoji = (emoji: string) => {
    if (selectedEmojis.includes(emoji)) {
      setSelectedEmojis(selectedEmojis.filter((e) => e !== emoji))
    } else {
      setSelectedEmojis([...selectedEmojis, emoji])
    }
  }

  // 스티커 토글
  const toggleSticker = (sticker: string) => {
    if (selectedStickers.includes(sticker)) {
      setSelectedStickers(selectedStickers.filter((s) => s !== sticker))
    } else {
      setSelectedStickers([...selectedStickers, sticker])
    }
  }

  // 이미지 제거
  const removeImage = (index: number) => {
    setNewImages(newImages.filter((_, i) => i !== index))
  }

  // 감정 아이콘 가져오기
  const getMoodIcon = (moodValue: Mood) => {
    switch (moodValue) {
      case "happy":
        return "😄"
      case "good":
        return "🙂"
      case "neutral":
        return "😐"
      case "bad":
        return "😕"
      case "sad":
        return "😢"
      default:
        return "😐"
    }
  }

  // 감정 텍스트 가져오기
  const getMoodText = (moodValue: Mood) => {
    switch (moodValue) {
      case "happy":
        return "행복"
      case "good":
        return "좋음"
      case "neutral":
        return "보통"
      case "bad":
        return "나쁨"
      case "sad":
        return "슬픔"
      default:
        return "보통"
    }
  }

  // 컴포넌트 언마운트 시 카메라 정리
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  const filteredDiaries = getFilteredDiaries()

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">일기 작성</h2>
        <div className="flex gap-2">
          <Button onClick={saveDiary}>
            <Save className="mr-2 h-4 w-4" />
            저장하기
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-1/4 space-y-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>섹션</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                variant={activeSection === "main" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("main")}
              >
                <BookOpen className="mr-2 h-4 w-4" />
                기본 정보
              </Button>
              <Button
                variant={activeSection === "thoughts" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("thoughts")}
              >
                <Smile className="mr-2 h-4 w-4" />
                감정 및 생각
              </Button>
              <Button
                variant={activeSection === "ideas" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("ideas")}
              >
                <Lightbulb className="mr-2 h-4 w-4" />
                아이디어
              </Button>
              <Button
                variant={activeSection === "goals" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("goals")}
              >
                <Target className="mr-2 h-4 w-4" />
                목표 및 계획
              </Button>
              <Button
                variant={activeSection === "gratitude" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("gratitude")}
              >
                <Heart className="mr-2 h-4 w-4" />
                감사한 일
              </Button>
              <Button
                variant={activeSection === "health" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("health")}
              >
                <Activity className="mr-2 h-4 w-4" />
                건강 및 습관
              </Button>
              <Button
                variant={activeSection === "learning" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("learning")}
              >
                <Book className="mr-2 h-4 w-4" />
                독서 및 학습
              </Button>
              <Button
                variant={activeSection === "creative" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("creative")}
              >
                <Palette className="mr-2 h-4 w-4" />
                창의적 표현
              </Button>
              <Button
                variant={activeSection === "future" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveSection("future")}
              >
                <Bookmark className="mr-2 h-4 w-4" />
                미래에 대한 다짐
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>정보</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div>
                  <span className="font-medium">날짜:</span> {format(selectedDate, "yyyy년 MM월 dd일", { locale: ko })}
                </div>
                <div>
                  <span className="font-medium">템플릿:</span>{" "}
                  {templates.find((t) => t.id === template)?.name || "기본"}
                </div>
                <div className="flex items-center gap-1">
                  <span className="font-medium">감정:</span> <span>{getMoodIcon(mood)}</span>{" "}
                  <span>{getMoodText(mood)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="w-full md:w-3/4">
          <Card
            style={{
              backgroundColor: templateInfo.bgColor,
              color: templateInfo.textColor,
              fontFamily: templateInfo.fontFamily,
            }}
          >
            <CardHeader className="pb-3 border-b" style={{ borderColor: `${templateInfo.textColor}20` }}>
              <div className="flex justify-between items-center">
                <CardTitle>{format(selectedDate, "yyyy년 MM월 dd일", { locale: ko })}</CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{getMoodIcon(mood)}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              {activeSection === "main" && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title" className="mb-1 block">
                      제목
                    </Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="일기 제목을 입력하세요"
                      style={{
                        backgroundColor: `${templateInfo.bgColor}80`,
                        color: templateInfo.textColor,
                        borderColor: `${templateInfo.textColor}30`,
                      }}
                    />
                  </div>

                  <div>
                    <Label htmlFor="mood" className="mb-1 block">
                      오늘의 감정
                    </Label>
                    <Select value={mood} onValueChange={(value) => setMood(value as Mood)}>
                      <SelectTrigger
                        id="mood"
                        style={{
                          backgroundColor: `${templateInfo.bgColor}80`,
                          color: templateInfo.textColor,
                          borderColor: `${templateInfo.textColor}30`,
                        }}
                      >
                        <SelectValue placeholder="감정 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="happy">행복 😄</SelectItem>
                        <SelectItem value="good">좋음 🙂</SelectItem>
                        <SelectItem value="neutral">보통 😐</SelectItem>
                        <SelectItem value="bad">나쁨 😕</SelectItem>
                        <SelectItem value="sad">슬픔 😢</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="content" className="mb-1 block">
                      오늘의 일기
                    </Label>
                    <Textarea
                      id="content"
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="오늘 하루를 자유롭게 기록해보세요"
                      rows={10}
                      style={{
                        backgroundColor: `${templateInfo.bgColor}80`,
                        color: templateInfo.textColor,
                        borderColor: `${templateInfo.textColor}30`,
                      }}
                    />
                  </div>
                </div>
              )}

              {activeSection === "thoughts" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">감정 및 생각</h3>
                  <p className="text-sm opacity-80">오늘 경험한 일에 대한 감정과 생각을 솔직하게 기록해보세요.</p>
                  <Textarea
                    value={thoughts}
                    onChange={(e) => setThoughts(e.target.value)}
                    placeholder="오늘 어떤 감정을 느꼈나요? 왜 그런 감정이 들었나요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}

              {activeSection === "ideas" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">아이디어 및 영감</h3>
                  <p className="text-sm opacity-80">오늘 떠오른 아이디어나 영감을 기록해두세요.</p>
                  <Textarea
                    value={ideas}
                    onChange={(e) => setIdeas(e.target.value)}
                    placeholder="어떤 새로운 아이디어가 떠올랐나요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}

              {activeSection === "goals" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">목표 및 계획</h3>
                  <p className="text-sm opacity-80">
                    단기적 또는 장기적인 목표를 설정하고, 이를 달성하기 위한 계획을 세워보세요.
                  </p>
                  <Textarea
                    value={goals}
                    onChange={(e) => setGoals(e.target.value)}
                    placeholder="어떤 목표를 세우고 계신가요? 어떻게 달성할 계획인가요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}

              {activeSection === "gratitude" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">감사한 일</h3>
                  <p className="text-sm opacity-80">오늘 하루 감사했던 일이나 사람들을 적어보세요.</p>
                  <Textarea
                    value={gratitude}
                    onChange={(e) => setGratitude(e.target.value)}
                    placeholder="오늘 어떤 것에 감사함을 느꼈나요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}

              {activeSection === "health" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">건강 및 습관 추적</h3>
                  <p className="text-sm opacity-80">
                    운동, 식사, 수면 등 건강 관련 사항이나 새로운 습관 형성 과정을 기록해보세요.
                  </p>
                  <Textarea
                    value={health}
                    onChange={(e) => setHealth(e.target.value)}
                    placeholder="오늘 건강을 위해 어떤 활동을 했나요? 어떤 습관을 형성하고 있나요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}

              {activeSection === "learning" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">독서 및 학습 내용</h3>
                  <p className="text-sm opacity-80">읽은 책이나 학습한 내용을 요약하고 느낀 점을 적어보세요.</p>
                  <Textarea
                    value={learning}
                    onChange={(e) => setLearning(e.target.value)}
                    placeholder="오늘 어떤 책을 읽거나 어떤 것을 배웠나요? 어떤 생각이 들었나요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}

              {activeSection === "creative" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">창의적 표현</h3>
                  <p className="text-sm opacity-80">글, 그림, 사진 등을 활용하여 창의적으로 자신을 표현해보세요.</p>
                  <div className="flex justify-center py-4">
                    <Button
                      variant="outline"
                      style={{
                        backgroundColor: `${templateInfo.bgColor}80`,
                        color: templateInfo.textColor,
                        borderColor: `${templateInfo.textColor}30`,
                      }}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      이미지 추가하기
                    </Button>
                  </div>
                </div>
              )}

              {activeSection === "future" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">미래에 대한 다짐</h3>
                  <p className="text-sm opacity-80">앞으로의 다짐이나 자신에게 보내는 격려의 말을 적어보세요.</p>
                  <Textarea
                    value={future}
                    onChange={(e) => setFuture(e.target.value)}
                    placeholder="앞으로 어떻게 살아가고 싶나요? 자신에게 어떤 말을 해주고 싶나요?"
                    rows={12}
                    style={{
                      backgroundColor: `${templateInfo.bgColor}80`,
                      color: templateInfo.textColor,
                      borderColor: `${templateInfo.textColor}30`,
                    }}
                  />
                </div>
              )}
            </CardContent>
            <CardFooter
              className="border-t flex justify-between"
              style={{ borderColor: `${templateInfo.textColor}20` }}
            >
              <div className="text-sm opacity-70">{format(new Date(), "yyyy-MM-dd HH:mm", { locale: ko })}</div>
              <Button
                onClick={saveDiary}
                style={{
                  backgroundColor: templateInfo.textColor,
                  color: templateInfo.bgColor,
                }}
              >
                <Save className="mr-2 h-4 w-4" />
                저장하기
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

