"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CalendarIcon, Download, Printer, FileText, BarChart4, Filter } from "lucide-react"
import { format, subMonths } from "date-fns"
import { ko } from "date-fns/locale"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"

// 가상의 보고서 데이터
const monthlyData = [
  { name: "1월", 수입: 3200000, 지출: 2400000, 매출: 5000000, 매입: 3500000 },
  { name: "2월", 수입: 3000000, 지출: 1390000, 매출: 4800000, 매입: 3200000 },
  { name: "3월", 수입: 2000000, 지출: 9800000, 매출: 4200000, 매입: 3800000 },
  { name: "4월", 수입: 2780000, 지출: 3900000, 매출: 5200000, 매입: 4100000 },
  { name: "5월", 수입: 1890000, 지출: 4800000, 매출: 4500000, 매입: 3900000 },
  { name: "6월", 수입: 2390000, 지출: 3800000, 매출: 5100000, 매입: 4200000 },
]

const categoryData = [
  { name: "식비", value: 400000 },
  { name: "주거비", value: 300000 },
  { name: "교통비", value: 200000 },
  { name: "여가", value: 100000 },
  { name: "의료비", value: 150000 },
  { name: "통신비", value: 80000 },
]

const salesData = [
  { name: "서비스", value: 5000000 },
  { name: "제품", value: 2500000 },
  { name: "유지보수", value: 1200000 },
  { name: "컨설팅", value: 800000 },
]

const purchaseData = [
  { name: "소모품", value: 120000 },
  { name: "전자기기", value: 1500000 },
  { name: "복리후생", value: 850000 },
  { name: "임대료", value: 2000000 },
  { name: "공과금", value: 450000 },
]

// 아이템별 매출 데이터
const itemSalesData = [
  { id: 1, name: "웹 애플리케이션 개발", category: "서비스", quantity: 3, unitPrice: 3000000, amount: 9000000 },
  { id: 2, name: "모바일 앱 개발", category: "서비스", quantity: 2, unitPrice: 2000000, amount: 4000000 },
  { id: 3, name: "시스템 유지보수", category: "유지보수", quantity: 6, unitPrice: 1200000, amount: 7200000 },
  { id: 4, name: "IT 컨설팅", category: "컨설팅", quantity: 10, unitPrice: 800000, amount: 8000000 },
  { id: 5, name: "서버 호스팅", category: "서비스", quantity: 12, unitPrice: 500000, amount: 6000000 },
]

// 아이템별 매입 데이터
const itemPurchaseData = [
  { id: 1, name: "A4 용지", category: "소모품", quantity: 50, unitPrice: 5000, amount: 250000 },
  { id: 2, name: "볼펜", category: "소모품", quantity: 200, unitPrice: 1000, amount: 200000 },
  { id: 3, name: "갤럭시북", category: "전자기기", quantity: 5, unitPrice: 1500000, amount: 7500000 },
  { id: 4, name: "커피", category: "복리후생", quantity: 30, unitPrice: 10000, amount: 300000 },
  { id: 5, name: "사무실 임대료", category: "임대료", quantity: 6, unitPrice: 2000000, amount: 12000000 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D"]

export default function Reports() {
  const [startDate, setStartDate] = useState<Date>(subMonths(new Date(), 6))
  const [endDate, setEndDate] = useState<Date>(new Date())
  const [reportType, setReportType] = useState("monthly")
  const [activeTab, setActiveTab] = useState("income-expense")
  const [itemReportType, setItemReportType] = useState("sales")
  const [compareEnabled, setCompareEnabled] = useState(false)

  // 아이템별 데이터 가져오기
  const getItemData = () => {
    return itemReportType === "sales" ? itemSalesData : itemPurchaseData
  }

  // 아이템별 카테고리 합계 계산
  const getItemCategorySummary = () => {
    const data = getItemData()
    const categories: Record<string, number> = {}

    data.forEach((item) => {
      if (!categories[item.category]) {
        categories[item.category] = 0
      }
      categories[item.category] += item.amount
    })

    return Object.entries(categories).map(([name, value]) => ({ name, value }))
  }

  // 엑셀 내보내기
  const exportToExcel = () => {
    alert("엑셀 내보내기 기능은 준비 중입니다.")
  }

  // 인쇄 기능
  const printReport = () => {
    alert("인쇄 기능은 준비 중입니다.")
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">보고서</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={printReport}>
            <Printer className="mr-2 h-4 w-4" />
            인쇄
          </Button>
          <Button variant="outline" onClick={exportToExcel}>
            <Download className="mr-2 h-4 w-4" />
            내보내기
          </Button>
          <Button variant="outline">
            <FileText className="mr-2 h-4 w-4" />
            PDF 저장
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>보고서 설정</CardTitle>
          <CardDescription>보고서 유형과 기간을 선택하세요</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-1/4">
              <label className="text-sm font-medium">보고서 유형</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="보고서 유형 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">월간 보고서</SelectItem>
                  <SelectItem value="quarterly">분기 보고서</SelectItem>
                  <SelectItem value="yearly">연간 보고서</SelectItem>
                  <SelectItem value="custom">사용자 정의</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="w-full md:w-1/4">
              <label className="text-sm font-medium">시작일</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full mt-1 justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "PPP", { locale: ko }) : "시작일 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="w-full md:w-1/4">
              <label className="text-sm font-medium">종료일</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full mt-1 justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "PPP", { locale: ko }) : "종료일 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="w-full md:w-1/4">
              <label className="text-sm font-medium">비교 옵션</label>
              <Select
                value={compareEnabled ? "enabled" : "disabled"}
                onValueChange={(value) => setCompareEnabled(value === "enabled")}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="비교 옵션 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="disabled">비교 없음</SelectItem>
                  <SelectItem value="enabled">전년 동기 비교</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="income-expense">수입/지출</TabsTrigger>
          <TabsTrigger value="category">카테고리 분석</TabsTrigger>
          <TabsTrigger value="sales">매출 분석</TabsTrigger>
          <TabsTrigger value="purchase">매입 분석</TabsTrigger>
          <TabsTrigger value="item">아이템별 분석</TabsTrigger>
        </TabsList>

        <TabsContent value="income-expense">
          <Card>
            <CardHeader>
              <CardTitle>월별 수입/지출 추이</CardTitle>
              <CardDescription>
                {format(startDate, "yyyy년 MM월 dd일", { locale: ko })} ~{" "}
                {format(endDate, "yyyy년 MM월 dd일", { locale: ko })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                  <Legend />
                  <Bar dataKey="수입" fill="#0088FE" />
                  <Bar dataKey="지출" fill="#FF8042" />
                  {compareEnabled && (
                    <>
                      <Bar dataKey="전년수입" fill="#0088FE" fillOpacity={0.5} />
                      <Bar dataKey="전년지출" fill="#FF8042" fillOpacity={0.5} />
                    </>
                  )}
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div>
                <span className="font-medium">총 수입: </span>
                <span className="font-bold text-blue-600">
                  {monthlyData.reduce((sum, item) => sum + item.수입, 0).toLocaleString()}원
                </span>
              </div>
              <div>
                <span className="font-medium">총 지출: </span>
                <span className="font-bold text-orange-600">
                  {monthlyData.reduce((sum, item) => sum + item.지출, 0).toLocaleString()}원
                </span>
              </div>
              <div>
                <span className="font-medium">순이익: </span>
                <span className="font-bold text-green-600">
                  {(
                    monthlyData.reduce((sum, item) => sum + item.수입, 0) -
                    monthlyData.reduce((sum, item) => sum + item.지출, 0)
                  ).toLocaleString()}
                  원
                </span>
              </div>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>순이익 추이</CardTitle>
              <CardDescription>최근 6개월 간의 순이익 추이</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart
                  data={monthlyData.map((item) => ({
                    name: item.name,
                    순이익: item.수입 - item.지출,
                    ...(compareEnabled ? { 전년순이익: (item.수입 - item.지출) * 0.8 } : {}),
                  }))}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                  <Legend />
                  <Line type="monotone" dataKey="순이익" stroke="#8884d8" activeDot={{ r: 8 }} />
                  {compareEnabled && (
                    <Line type="monotone" dataKey="전년순이익" stroke="#8884d8" strokeDasharray="5 5" />
                  )}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="category">
          <Card>
            <CardHeader>
              <CardTitle>지출 카테고리 분석</CardTitle>
              <CardDescription>카테고리별 지출 비율</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RePieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                </RePieChart>
              </ResponsiveContainer>
            </CardContent>
            <CardFooter>
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>카테고리</TableHead>
                      <TableHead className="text-right">금액</TableHead>
                      <TableHead className="text-right">비율</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoryData.map((category, index) => {
                      const total = categoryData.reduce((sum, item) => sum + item.value, 0)
                      const percentage = (category.value / total) * 100

                      return (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: COLORS[index % COLORS.length] }}
                              />
                              {category.name}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">{category.value.toLocaleString()}원</TableCell>
                          <TableCell className="text-right">{percentage.toFixed(1)}%</TableCell>
                        </TableRow>
                      )
                    })}
                    <TableRow className="font-bold">
                      <TableCell>합계</TableCell>
                      <TableCell className="text-right">
                        {categoryData.reduce((sum, item) => sum + item.value, 0).toLocaleString()}원
                      </TableCell>
                      <TableCell className="text-right">100%</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="sales">
          <Card>
            <CardHeader>
              <CardTitle>매출 카테고리 분석</CardTitle>
              <CardDescription>카테고리별 매출 비율</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RePieChart>
                  <Pie
                    data={salesData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {salesData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                </RePieChart>
              </ResponsiveContainer>
            </CardContent>
            <CardFooter>
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>카테고리</TableHead>
                      <TableHead className="text-right">금액</TableHead>
                      <TableHead className="text-right">비율</TableHead>
                      {compareEnabled && (
                        <>
                          <TableHead className="text-right">전년 동기</TableHead>
                          <TableHead className="text-right">증감률</TableHead>
                        </>
                      )}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {salesData.map((category, index) => {
                      const total = salesData.reduce((sum, item) => sum + item.value, 0)
                      const percentage = (category.value / total) * 100
                      const lastYearValue = category.value * 0.8 // 가상의 전년 데이터
                      const growthRate = ((category.value - lastYearValue) / lastYearValue) * 100

                      return (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: COLORS[index % COLORS.length] }}
                              />
                              {category.name}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">{category.value.toLocaleString()}원</TableCell>
                          <TableCell className="text-right">{percentage.toFixed(1)}%</TableCell>
                          {compareEnabled && (
                            <>
                              <TableCell className="text-right">{lastYearValue.toLocaleString()}원</TableCell>
                              <TableCell
                                className={`text-right ${growthRate >= 0 ? "text-green-600" : "text-red-600"}`}
                              >
                                {growthRate >= 0 ? "+" : ""}
                                {growthRate.toFixed(1)}%
                              </TableCell>
                            </>
                          )}
                        </TableRow>
                      )
                    })}
                    <TableRow className="font-bold">
                      <TableCell>합계</TableCell>
                      <TableCell className="text-right">
                        {salesData.reduce((sum, item) => sum + item.value, 0).toLocaleString()}원
                      </TableCell>
                      <TableCell className="text-right">100%</TableCell>
                      {compareEnabled && (
                        <>
                          <TableCell className="text-right">
                            {(salesData.reduce((sum, item) => sum + item.value, 0) * 0.8).toLocaleString()}원
                          </TableCell>
                          <TableCell className="text-right text-green-600">+25.0%</TableCell>
                        </>
                      )}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>월별 매출 추이</CardTitle>
              <CardDescription>최근 6개월 간의 매출 추이</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                  <Legend />
                  <Line type="monotone" dataKey="매출" stroke="#0088FE" activeDot={{ r: 8 }} />
                  {compareEnabled && <Line type="monotone" dataKey="전년매출" stroke="#0088FE" strokeDasharray="5 5" />}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="purchase">
          <Card>
            <CardHeader>
              <CardTitle>매입 카테고리 분석</CardTitle>
              <CardDescription>카테고리별 매입 비율</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RePieChart>
                  <Pie
                    data={purchaseData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {purchaseData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                </RePieChart>
              </ResponsiveContainer>
            </CardContent>
            <CardFooter>
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>카테고리</TableHead>
                      <TableHead className="text-right">금액</TableHead>
                      <TableHead className="text-right">비율</TableHead>
                      {compareEnabled && (
                        <>
                          <TableHead className="text-right">전년 동기</TableHead>
                          <TableHead className="text-right">증감률</TableHead>
                        </>
                      )}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {purchaseData.map((category, index) => {
                      const total = purchaseData.reduce((sum, item) => sum + item.value, 0)
                      const percentage = (category.value / total) * 100
                      const lastYearValue = category.value * 0.9 // 가상의 전년 데이터
                      const growthRate = ((category.value - lastYearValue) / lastYearValue) * 100

                      return (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: COLORS[index % COLORS.length] }}
                              />
                              {category.name}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">{category.value.toLocaleString()}원</TableCell>
                          <TableCell className="text-right">{percentage.toFixed(1)}%</TableCell>
                          {compareEnabled && (
                            <>
                              <TableCell className="text-right">{lastYearValue.toLocaleString()}원</TableCell>
                              <TableCell
                                className={`text-right ${growthRate >= 0 ? "text-red-600" : "text-green-600"}`}
                              >
                                {growthRate >= 0 ? "+" : ""}
                                {growthRate.toFixed(1)}%
                              </TableCell>
                            </>
                          )}
                        </TableRow>
                      )
                    })}
                    <TableRow className="font-bold">
                      <TableCell>합계</TableCell>
                      <TableCell className="text-right">
                        {purchaseData.reduce((sum, item) => sum + item.value, 0).toLocaleString()}원
                      </TableCell>
                      <TableCell className="text-right">100%</TableCell>
                      {compareEnabled && (
                        <>
                          <TableCell className="text-right">
                            {(purchaseData.reduce((sum, item) => sum + item.value, 0) * 0.9).toLocaleString()}원
                          </TableCell>
                          <TableCell className="text-right text-red-600">+11.1%</TableCell>
                        </>
                      )}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>월별 매입 추이</CardTitle>
              <CardDescription>최근 6개월 간의 매입 추이</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                  <Legend />
                  <Line type="monotone" dataKey="매입" stroke="#FF8042" activeDot={{ r: 8 }} />
                  {compareEnabled && <Line type="monotone" dataKey="전년매입" stroke="#FF8042" strokeDasharray="5 5" />}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="item">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>아이템별 분석</CardTitle>
                  <CardDescription>아이템별 매출/매입 분석</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Select value={itemReportType} onValueChange={setItemReportType}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="유형 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sales">매출 아이템</SelectItem>
                      <SelectItem value="purchase">매입 아이템</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">아이템별 금액</h3>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>아이템명</TableHead>
                          <TableHead>카테고리</TableHead>
                          <TableHead className="text-right">수량</TableHead>
                          <TableHead className="text-right">단가</TableHead>
                          <TableHead className="text-right">금액</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getItemData().map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell>{item.category}</TableCell>
                            <TableCell className="text-right">{item.quantity.toLocaleString()}</TableCell>
                            <TableCell className="text-right">{item.unitPrice.toLocaleString()}원</TableCell>
                            <TableCell className="text-right">{item.amount.toLocaleString()}원</TableCell>
                          </TableRow>
                        ))}
                        <TableRow className="font-bold">
                          <TableCell colSpan={4} className="text-right">
                            합계
                          </TableCell>
                          <TableCell className="text-right">
                            {getItemData()
                              .reduce((sum, item) => sum + item.amount, 0)
                              .toLocaleString()}
                            원
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">카테고리별 비율</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <RePieChart>
                      <Pie
                        data={getItemCategorySummary()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {getItemCategorySummary().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => value.toLocaleString() + "원"} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div>
                <span className="font-medium">총 {itemReportType === "sales" ? "매출" : "매입"}: </span>
                <span className="font-bold">
                  {getItemData()
                    .reduce((sum, item) => sum + item.amount, 0)
                    .toLocaleString()}
                  원
                </span>
              </div>
              <div>
                <span className="font-medium">아이템 수: </span>
                <span className="font-bold">{getItemData().length}개</span>
              </div>
              <div>
                <span className="font-medium">평균 단가: </span>
                <span className="font-bold">
                  {(
                    getItemData().reduce((sum, item) => sum + item.unitPrice, 0) / getItemData().length
                  ).toLocaleString()}
                  원
                </span>
              </div>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>아이템별 추이 분석</CardTitle>
              <CardDescription>기간별 아이템 판매/구매 추이</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] flex items-center justify-center bg-muted rounded-md">
                <div className="text-center">
                  <BarChart4 className="h-16 w-16 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">아이템을 선택하면 추이 차트가 표시됩니다</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

