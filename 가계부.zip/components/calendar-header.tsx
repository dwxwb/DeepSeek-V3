import { Card, CardContent } from "@/components/ui/card"
import { format } from "date-fns"
import { ko } from "date-fns/locale"

interface CalendarHeaderProps {
  title: string
  date: Date
  incomeTotal?: number
  expenseTotal?: number
  salesTotal?: number
  purchaseTotal?: number
  totalAmount: number
}

export default function CalendarHeader({
  title,
  date,
  incomeTotal,
  expenseTotal,
  salesTotal,
  purchaseTotal,
  totalAmount,
}: CalendarHeaderProps) {
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h3 className="text-xl font-bold">{title}</h3>
            <p className="text-muted-foreground">{format(date, "yyyy년 MM월", { locale: ko })}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full md:w-auto">
            {incomeTotal !== undefined && (
              <div className="p-3 border rounded-md">
                <div className="text-sm font-medium">수입</div>
                <div className="text-lg font-bold text-green-600">{incomeTotal.toLocaleString()}원</div>
              </div>
            )}

            {expenseTotal !== undefined && (
              <div className="p-3 border rounded-md">
                <div className="text-sm font-medium">지출</div>
                <div className="text-lg font-bold text-red-600">{Math.abs(expenseTotal).toLocaleString()}원</div>
              </div>
            )}

            {salesTotal !== undefined && (
              <div className="p-3 border rounded-md">
                <div className="text-sm font-medium">매출</div>
                <div className="text-lg font-bold text-red-600">{salesTotal.toLocaleString()}원</div>
              </div>
            )}

            {purchaseTotal !== undefined && (
              <div className="p-3 border rounded-md">
                <div className="text-sm font-medium">매입</div>
                <div className="text-lg font-bold text-blue-600">{Math.abs(purchaseTotal).toLocaleString()}원</div>
              </div>
            )}

            <div className="p-3 border rounded-md">
              <div className="text-sm font-medium">합계</div>
              <div className={`text-lg font-bold ${totalAmount >= 0 ? "text-green-600" : "text-red-600"}`}>
                {totalAmount.toLocaleString()}원
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

