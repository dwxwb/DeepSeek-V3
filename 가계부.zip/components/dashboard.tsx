"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { ArrowUpRight, ArrowDownRight, TrendingUp, Wallet, FileSpreadsheet, FileText } from "lucide-react"

const monthlyData = [
  { name: "1월", 수입: 320, 지출: 240 },
  { name: "2월", 수입: 300, 지출: 139 },
  { name: "3월", 수입: 200, 지출: 980 },
  { name: "4월", 수입: 278, 지출: 390 },
  { name: "5월", 수입: 189, 지출: 480 },
  { name: "6월", 수입: 239, 지출: 380 },
]

const pieData = [
  { name: "식비", value: 400 },
  { name: "주거비", value: 300 },
  { name: "교통비", value: 200 },
  { name: "여가", value: 100 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

export default function Dashboard() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">이번 달 수입</CardTitle>
          <ArrowUpRight className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₩2,350,000</div>
          <p className="text-xs text-muted-foreground">전월 대비 +12%</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">이번 달 지출</CardTitle>
          <ArrowDownRight className="h-4 w-4 text-red-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₩1,890,000</div>
          <p className="text-xs text-muted-foreground">전월 대비 -3%</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">매출 현황</CardTitle>
          <TrendingUp className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₩5,670,000</div>
          <p className="text-xs text-muted-foreground">목표 달성률 78%</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">매입 현황</CardTitle>
          <Wallet className="h-4 w-4 text-orange-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₩3,120,000</div>
          <p className="text-xs text-muted-foreground">예산 사용률 65%</p>
        </CardContent>
      </Card>

      <Card className="col-span-2">
        <CardHeader>
          <CardTitle>월별 수입/지출 현황</CardTitle>
          <CardDescription>최근 6개월 간의 수입과 지출 추이</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="수입" fill="#0088FE" />
              <Bar dataKey="지출" fill="#FF8042" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="col-span-2">
        <CardHeader>
          <CardTitle>지출 카테고리 분석</CardTitle>
          <CardDescription>이번 달 지출 카테고리별 비율</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="col-span-4">
        <CardHeader className="flex flex-row items-center">
          <div>
            <CardTitle>최근 활동</CardTitle>
            <CardDescription>최근 처리된 작업 내역</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <FileSpreadsheet className="h-6 w-6 text-blue-500" />
              <div>
                <p className="font-medium">엑셀 데이터 가져오기 완료</p>
                <p className="text-sm text-muted-foreground">2023년 4분기 매출 데이터 (오늘 14:23)</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <FileText className="h-6 w-6 text-green-500" />
              <div>
                <p className="font-medium">월간 보고서 생성 완료</p>
                <p className="text-sm text-muted-foreground">2023년 12월 가계부 보고서 (오늘 11:05)</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Wallet className="h-6 w-6 text-orange-500" />
              <div>
                <p className="font-medium">새 거래 기록 추가</p>
                <p className="text-sm text-muted-foreground">사무용품 구매 - ₩120,000 (어제 16:42)</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

