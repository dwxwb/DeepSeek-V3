"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Lightbulb,
  TrendingDown,
  Coffee,
  ShoppingBag,
  Utensils,
  AlertCircle,
  CheckCircle2,
  PiggyBank,
  Target,
  Plus,
  Trash2,
  Edit,
  ArrowRight,
  Sparkles,
} from "lucide-react"
import { getEmojiForCategoryName } from "@/lib/category-data"

// 가상의 지출 인사이트 데이터
const spendingInsights = [
  {
    id: 1,
    type: "alert",
    category: "식비",
    title: "이번 달 커피 지출이 너무 많아요!",
    description: "이번 달 커피 지출이 지난 달보다 35% 증가했습니다. 하루에 한 잔만 줄여도 월 3만원을 절약할 수 있어요.",
    amount: 87500,
    previousAmount: 65000,
    change: 35,
    icon: Coffee,
    action: "절약 계획 세우기",
  },
  {
    id: 2,
    type: "alert",
    category: "쇼핑",
    title: "온라인 쇼핑 지출이 증가했어요",
    description: "이번 달 온라인 쇼핑 지출이 평소보다 많네요. 필요한 물건만 구매하는 것이 어떨까요?",
    amount: 245000,
    previousAmount: 180000,
    change: 36,
    icon: ShoppingBag,
    action: "쇼핑 목록 만들기",
  },
  {
    id: 3,
    type: "tip",
    category: "식비",
    title: "식비 절약 팁",
    description: "주 1-2회 집에서 도시락을 준비하면 월 5만원 이상 절약할 수 있어요.",
    icon: Utensils,
    action: "더 많은 팁 보기",
  },
  {
    id: 4,
    type: "achievement",
    category: "교통비",
    title: "교통비 절약 성공!",
    description: "지난 달보다 교통비를 15% 절약했어요. 대중교통 이용이 도움이 되었네요!",
    amount: 85000,
    previousAmount: 100000,
    change: -15,
    icon: TrendingDown,
    action: "절약 계획 유지하기",
  },
]

// 가상의 저축 목표 데이터
const initialSavingGoals = [
  {
    id: 1,
    title: "여행 자금",
    targetAmount: 2000000,
    currentAmount: 1200000,
    deadline: "2024-08-31",
    autoSave: true,
    autoSaveAmount: 200000,
    autoSaveFrequency: "monthly",
    category: "여행",
    icon: "✈️",
  },
  {
    id: 2,
    title: "비상금",
    targetAmount: 5000000,
    currentAmount: 2500000,
    deadline: "2024-12-31",
    autoSave: true,
    autoSaveAmount: 300000,
    autoSaveFrequency: "monthly",
    category: "비상금",
    icon: "🛡️",
  },
  {
    id: 3,
    title: "노트북 구매",
    targetAmount: 1500000,
    currentAmount: 500000,
    deadline: "2024-06-30",
    autoSave: false,
    autoSaveAmount: 0,
    autoSaveFrequency: "monthly",
    category: "전자기기",
    icon: "💻",
  },
]

export default function AIInsights() {
  const [activeTab, setActiveTab] = useState("insights")
  const [savingGoals, setSavingGoals] = useState(initialSavingGoals)
  const [openNewGoal, setOpenNewGoal] = useState(false)
  const [newGoalTitle, setNewGoalTitle] = useState("")
  const [newGoalAmount, setNewGoalAmount] = useState(1000000)
  const [newGoalDeadline, setNewGoalDeadline] = useState("")
  const [newGoalAutoSave, setNewGoalAutoSave] = useState(false)
  const [newGoalAutoSaveAmount, setNewGoalAutoSaveAmount] = useState(100000)
  const [newGoalCategory, setNewGoalCategory] = useState("여행")
  const [editingGoalId, setEditingGoalId] = useState<number | null>(null)

  // 저축 목표 추가
  const handleAddGoal = () => {
    if (!newGoalTitle || !newGoalAmount || !newGoalDeadline) {
      alert("모든 필수 항목을 입력해주세요.")
      return
    }

    const newGoal = {
      id: savingGoals.length + 1,
      title: newGoalTitle,
      targetAmount: newGoalAmount,
      currentAmount: 0,
      deadline: newGoalDeadline,
      autoSave: newGoalAutoSave,
      autoSaveAmount: newGoalAutoSaveAmount,
      autoSaveFrequency: "monthly",
      category: newGoalCategory,
      icon: getEmojiForCategoryName(newGoalCategory),
    }

    setSavingGoals([...savingGoals, newGoal])
    resetNewGoalForm()
    setOpenNewGoal(false)
  }

  // 저축 목표 수정
  const handleEditGoal = (id: number) => {
    const goal = savingGoals.find((g) => g.id === id)
    if (!goal) return

    setNewGoalTitle(goal.title)
    setNewGoalAmount(goal.targetAmount)
    setNewGoalDeadline(goal.deadline)
    setNewGoalAutoSave(goal.autoSave)
    setNewGoalAutoSaveAmount(goal.autoSaveAmount)
    setNewGoalCategory(goal.category)
    setEditingGoalId(id)
    setOpenNewGoal(true)
  }

  // 저축 목표 수정 저장
  const handleSaveEditGoal = () => {
    if (!editingGoalId) return

    const updatedGoals = savingGoals.map((goal) => {
      if (goal.id === editingGoalId) {
        return {
          ...goal,
          title: newGoalTitle,
          targetAmount: newGoalAmount,
          deadline: newGoalDeadline,
          autoSave: newGoalAutoSave,
          autoSaveAmount: newGoalAutoSaveAmount,
          category: newGoalCategory,
          icon: getEmojiForCategoryName(newGoalCategory),
        }
      }
      return goal
    })

    setSavingGoals(updatedGoals)
    resetNewGoalForm()
    setOpenNewGoal(false)
    setEditingGoalId(null)
  }

  // 저축 목표 삭제
  const handleDeleteGoal = (id: number) => {
    setSavingGoals(savingGoals.filter((goal) => goal.id !== id))
  }

  // 자동 저축 설정 변경
  const handleAutoSaveChange = (id: number, checked: boolean) => {
    setSavingGoals(savingGoals.map((goal) => (goal.id === id ? { ...goal, autoSave: checked } : goal)))
  }

  // 새 목표 폼 초기화
  const resetNewGoalForm = () => {
    setNewGoalTitle("")
    setNewGoalAmount(1000000)
    setNewGoalDeadline("")
    setNewGoalAutoSave(false)
    setNewGoalAutoSaveAmount(100000)
    setNewGoalCategory("여행")
  }

  // 진행률 계산
  const calculateProgress = (current: number, target: number) => {
    return Math.min(Math.round((current / target) * 100), 100)
  }

  // 남은 일수 계산
  const calculateRemainingDays = (deadline: string) => {
    const today = new Date()
    const deadlineDate = new Date(deadline)
    const diffTime = deadlineDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 0 ? diffDays : 0
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI 인사이트 & 자동 저축</h2>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              resetNewGoalForm()
              setOpenNewGoal(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />새 저축 목표
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="insights">지출 인사이트</TabsTrigger>
          <TabsTrigger value="savings">저축 목표</TabsTrigger>
        </TabsList>

        <TabsContent value="insights">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                <CardTitle>AI 지출 인사이트</CardTitle>
              </div>
              <CardDescription>AI가 분석한 지출 패턴과 절약 팁</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {spendingInsights.map((insight) => (
                  <Card
                    key={insight.id}
                    className={`
                    ${insight.type === "alert" ? "border-red-200 bg-red-50" : ""}
                    ${insight.type === "tip" ? "border-blue-200 bg-blue-50" : ""}
                    ${insight.type === "achievement" ? "border-green-200 bg-green-50" : ""}
                  `}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div
                          className={`
                          p-2 rounded-full
                          ${insight.type === "alert" ? "bg-red-100 text-red-600" : ""}
                          ${insight.type === "tip" ? "bg-blue-100 text-blue-600" : ""}
                          ${insight.type === "achievement" ? "bg-green-100 text-green-600" : ""}
                        `}
                        >
                          {insight.type === "alert" && <AlertCircle className="h-5 w-5" />}
                          {insight.type === "tip" && <Lightbulb className="h-5 w-5" />}
                          {insight.type === "achievement" && <CheckCircle2 className="h-5 w-5" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="flex items-center gap-1">
                              <span role="img" aria-label={insight.category}>
                                {getEmojiForCategoryName(insight.category)}
                              </span>
                              {insight.category}
                            </Badge>
                            {insight.change && (
                              <Badge variant={insight.change > 0 ? "destructive" : "success"}>
                                {insight.change > 0 ? "+" : ""}
                                {insight.change}%
                              </Badge>
                            )}
                          </div>
                          <h3
                            className={`font-medium mb-1
                            ${insight.type === "alert" ? "text-red-700" : ""}
                            ${insight.type === "tip" ? "text-blue-700" : ""}
                            ${insight.type === "achievement" ? "text-green-700" : ""}
                          `}
                          >
                            {insight.title}
                          </h3>
                          <p
                            className={`text-sm mb-3
                            ${insight.type === "alert" ? "text-red-600" : ""}
                            ${insight.type === "tip" ? "text-blue-600" : ""}
                            ${insight.type === "achievement" ? "text-green-600" : ""}
                          `}
                          >
                            {insight.description}
                          </p>

                          {insight.amount && insight.previousAmount && (
                            <div className="flex items-center gap-4 mb-3">
                              <div>
                                <div className="text-xs text-muted-foreground">이번 달</div>
                                <div className="font-medium">{insight.amount.toLocaleString()}원</div>
                              </div>
                              <ArrowRight className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <div className="text-xs text-muted-foreground">지난 달</div>
                                <div className="font-medium">{insight.previousAmount.toLocaleString()}원</div>
                              </div>
                            </div>
                          )}

                          <Button
                            variant="outline"
                            size="sm"
                            className={`
                              ${insight.type === "alert" ? "border-red-200 text-red-600 hover:bg-red-100" : ""}
                              ${insight.type === "tip" ? "border-blue-200 text-blue-600 hover:bg-blue-100" : ""}
                              ${insight.type === "achievement" ? "border-green-200 text-green-600 hover:bg-green-100" : ""}
                            `}
                          >
                            {insight.action}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <Sparkles className="mr-2 h-4 w-4" />더 많은 인사이트 보기
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="savings">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <PiggyBank className="h-5 w-5 text-primary" />
                <CardTitle>저축 목표</CardTitle>
              </div>
              <CardDescription>저축 목표를 설정하고 자동 저축으로 목표를 달성하세요</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {savingGoals.length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 bg-muted rounded-md">
                    <Target className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-center text-muted-foreground mb-4">저축 목표가 없습니다.</p>
                    <Button
                      onClick={() => {
                        resetNewGoalForm()
                        setOpenNewGoal(true)
                      }}
                    >
                      <Plus className="mr-2 h-4 w-4" />새 저축 목표
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savingGoals.map((goal) => {
                      const progress = calculateProgress(goal.currentAmount, goal.targetAmount)
                      const remainingDays = calculateRemainingDays(goal.deadline)

                      return (
                        <Card key={goal.id} className="overflow-hidden">
                          <div className="h-2 bg-primary" style={{ width: `${progress}%` }}></div>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2">
                                <div className="text-2xl">{goal.icon}</div>
                                <div>
                                  <h3 className="font-medium">{goal.title}</h3>
                                  <p className="text-xs text-muted-foreground">
                                    {remainingDays > 0 ? `${remainingDays}일 남음 (${goal.deadline})` : "기한 만료"}
                                  </p>
                                </div>
                              </div>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => handleEditGoal(goal.id)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                  onClick={() => handleDeleteGoal(goal.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>

                            <div className="mt-4">
                              <div className="flex justify-between mb-1 text-sm">
                                <span>{goal.currentAmount.toLocaleString()}원</span>
                                <span>{goal.targetAmount.toLocaleString()}원</span>
                              </div>
                              <Progress value={progress} className="h-2" />
                              <p className="text-xs text-right mt-1 text-muted-foreground">{progress}% 달성</p>
                            </div>

                            <div className="mt-4 flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-xs">자동 저축</span>
                                <Switch
                                  checked={goal.autoSave}
                                  onCheckedChange={(checked) => handleAutoSaveChange(goal.id, checked)}
                                />
                              </div>
                              {goal.autoSave && (
                                <Badge variant="outline">매월 {goal.autoSaveAmount.toLocaleString()}원</Badge>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>
                )}

                {openNewGoal && (
                  <Card>
                    <CardHeader>
                      <CardTitle>{editingGoalId ? "저축 목표 수정" : "새 저축 목표"}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid gap-2">
                          <Label htmlFor="title">목표 제목</Label>
                          <Input
                            id="title"
                            value={newGoalTitle}
                            onChange={(e) => setNewGoalTitle(e.target.value)}
                            placeholder="예: 여행 자금, 비상금"
                            required
                          />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="category">카테고리</Label>
                          <Select value={newGoalCategory} onValueChange={setNewGoalCategory}>
                            <SelectTrigger id="category">
                              <SelectValue placeholder="카테고리 선택" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="여행">여행</SelectItem>
                              <SelectItem value="비상금">비상금</SelectItem>
                              <SelectItem value="전자기기">전자기기</SelectItem>
                              <SelectItem value="교육">교육</SelectItem>
                              <SelectItem value="자동차">자동차</SelectItem>
                              <SelectItem value="주택">주택</SelectItem>
                              <SelectItem value="기타">기타</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="target-amount">목표 금액</Label>
                          <Input
                            id="target-amount"
                            type="number"
                            value={newGoalAmount}
                            onChange={(e) => setNewGoalAmount(Number(e.target.value))}
                            required
                          />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="deadline">목표 기한</Label>
                          <Input
                            id="deadline"
                            type="date"
                            value={newGoalDeadline}
                            onChange={(e) => setNewGoalDeadline(e.target.value)}
                            required
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Switch id="auto-save" checked={newGoalAutoSave} onCheckedChange={setNewGoalAutoSave} />
                            <Label htmlFor="auto-save">자동 저축 활성화</Label>
                          </div>
                        </div>

                        {newGoalAutoSave && (
                          <div className="grid gap-2">
                            <Label htmlFor="auto-save-amount">월 자동 저축 금액</Label>
                            <Input
                              id="auto-save-amount"
                              type="number"
                              value={newGoalAutoSaveAmount}
                              onChange={(e) => setNewGoalAutoSaveAmount(Number(e.target.value))}
                            />
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setOpenNewGoal(false)
                          setEditingGoalId(null)
                          resetNewGoalForm()
                        }}
                      >
                        취소
                      </Button>
                      <Button onClick={editingGoalId ? handleSaveEditGoal : handleAddGoal}>
                        {editingGoalId ? "수정" : "저장"}
                      </Button>
                    </CardFooter>
                  </Card>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  resetNewGoalForm()
                  setOpenNewGoal(true)
                }}
              >
                <Plus className="mr-2 h-4 w-4" />새 저축 목표
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

