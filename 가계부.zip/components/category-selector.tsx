"use client"

import type React from "react"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Plus, Search } from "lucide-react"
import { expenseCategories, incomeCategories, type Category } from "@/lib/category-data"

interface CategorySelectorProps {
  onSelectCategory: (category: Category, amount?: number) => void
  initialAmount?: number
  title?: string
  description?: string
}

export default function CategorySelector({
  onSelectCategory,
  initialAmount = 0,
  title = "카테고리 선택",
  description = "거래 카테고리를 선택하세요",
}: CategorySelectorProps) {
  const [activeTab, setActiveTab] = useState("expense")
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newCategoryName, setNewCategoryName] = useState("")
  const [newCategoryEmoji, setNewCategoryEmoji] = useState("📋")
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [customCategories, setCustomCategories] = useState<Category[]>([])
  const [amount, setAmount] = useState<number>(initialAmount)

  // 카테고리 필터링
  const filteredExpenseCategories = [
    ...expenseCategories,
    ...customCategories.filter((c) => !expenseCategories.some((ec) => ec.id === c.id)),
  ].filter((category) => category.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const filteredIncomeCategories = [
    ...incomeCategories,
    ...customCategories.filter((c) => !incomeCategories.some((ic) => ic.id === c.id)),
  ].filter((category) => category.name.toLowerCase().includes(searchTerm.toLowerCase()))

  // 카테고리 추가
  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return

    const newCategory: Category = {
      id: `custom-${Date.now()}`,
      name: newCategoryName,
      emoji: newCategoryEmoji,
    }

    setCustomCategories([...customCategories, newCategory])
    setNewCategoryName("")
    setNewCategoryEmoji("📋")
    setIsAddDialogOpen(false)
  }

  // 카테고리 수정
  const handleEditCategory = (category: Category) => {
    setEditingCategory(category)
    setNewCategoryName(category.name)
    setNewCategoryEmoji(category.emoji)
    setIsAddDialogOpen(true)
  }

  // 카테고리 수정 저장
  const handleSaveEdit = () => {
    if (!editingCategory || !newCategoryName.trim()) return

    const updatedCategories = customCategories.map((cat) =>
      cat.id === editingCategory.id ? { ...cat, name: newCategoryName, emoji: newCategoryEmoji } : cat,
    )

    setCustomCategories(updatedCategories)
    setEditingCategory(null)
    setNewCategoryName("")
    setNewCategoryEmoji("📋")
    setIsAddDialogOpen(false)
  }

  // 카테고리 삭제
  const handleDeleteCategory = (categoryId: string) => {
    setCustomCategories(customCategories.filter((cat) => cat.id !== categoryId))
  }

  // 카테고리 선택
  const handleSelectCategory = (category: Category) => {
    onSelectCategory(category, amount)
  }

  // 금액 변경
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, "")
    setAmount(value ? Number.parseInt(value) : 0)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>{title}</CardTitle>
            <Button variant="outline" size="sm" onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-1" /> 추가
            </Button>
          </div>
          <CardDescription>{description}</CardDescription>
          <div className="relative mt-2">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="카테고리 검색..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="pb-1">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="expense">지출</TabsTrigger>
              <TabsTrigger value="income">수입</TabsTrigger>
            </TabsList>

            <TabsContent value="expense" className="mt-0">
              <div className="grid grid-cols-4 gap-3">
                {filteredExpenseCategories.map((category) => (
                  <Button
                    key={category.id}
                    variant="outline"
                    className="h-auto flex flex-col py-3 px-2 items-center justify-center gap-1 hover:bg-accent"
                    onClick={() => handleSelectCategory(category)}
                  >
                    <span className="text-2xl" role="img" aria-label={category.name}>
                      {category.emoji}
                    </span>
                    <span className="text-xs font-normal text-center">{category.name}</span>
                  </Button>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="income" className="mt-0">
              <div className="grid grid-cols-4 gap-3">
                {filteredIncomeCategories.map((category) => (
                  <Button
                    key={category.id}
                    variant="outline"
                    className="h-auto flex flex-col py-3 px-2 items-center justify-center gap-1 hover:bg-accent"
                    onClick={() => handleSelectCategory(category)}
                  >
                    <span className="text-2xl" role="img" aria-label={category.name}>
                      {category.emoji}
                    </span>
                    <span className="text-xs font-normal text-center">{category.name}</span>
                  </Button>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="flex justify-between pt-3">
          <div className="flex items-center gap-2 w-full">
            <Label htmlFor="amount" className="text-sm whitespace-nowrap">
              금액:
            </Label>
            <Input
              id="amount"
              type="text"
              value={amount.toLocaleString()}
              onChange={handleAmountChange}
              className="text-right font-medium"
            />
            <span className="text-sm whitespace-nowrap">원</span>
          </div>
        </CardFooter>
      </Card>

      {/* 카테고리 추가/수정 다이얼로그 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingCategory ? "카테고리 수정" : "새 카테고리 추가"}</DialogTitle>
            <DialogDescription>
              {editingCategory ? "카테고리 정보를 수정하세요" : "새로운 카테고리를 추가하세요"}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="category-emoji">이모티콘</Label>
              <div className="flex gap-2">
                <div className="w-12 h-12 flex items-center justify-center text-3xl border rounded-md">
                  {newCategoryEmoji}
                </div>
                <Input
                  id="category-emoji"
                  value={newCategoryEmoji}
                  onChange={(e) => setNewCategoryEmoji(e.target.value)}
                  placeholder="이모티콘 입력"
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-muted-foreground">이모티콘을 직접 입력하거나 복사하여 붙여넣으세요</p>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="category-name">카테고리 이름</Label>
              <Input
                id="category-name"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="카테고리 이름 입력"
              />
            </div>
          </div>

          <DialogFooter className="flex justify-between">
            {editingCategory && (
              <Button
                variant="destructive"
                onClick={() => {
                  if (editingCategory) handleDeleteCategory(editingCategory.id)
                  setIsAddDialogOpen(false)
                  setEditingCategory(null)
                }}
              >
                삭제
              </Button>
            )}
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddDialogOpen(false)
                  setEditingCategory(null)
                  setNewCategoryName("")
                  setNewCategoryEmoji("📋")
                }}
              >
                취소
              </Button>
              <Button onClick={editingCategory ? handleSaveEdit : handleAddCategory}>
                {editingCategory ? "수정" : "추가"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

