"use client"

import type React from "react"

import { useState, useRef } from "react"
import { format } from "date-fns"
import { ko } from "date-fns/locale"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Smile, Image, Save, CalendarIcon, PaintBucket, Type, FileText } from "lucide-react"

// 감정 이모티콘 목록
const emotions = [
  { value: "happy", label: "행복", emoji: "😊" },
  { value: "sad", label: "슬픔", emoji: "😢" },
  { value: "angry", label: "화남", emoji: "😠" },
  { value: "excited", label: "신남", emoji: "😆" },
  { value: "tired", label: "피곤", emoji: "😫" },
  { value: "calm", label: "평온", emoji: "😌" },
  { value: "worried", label: "걱정", emoji: "😟" },
  { value: "surprised", label: "놀람", emoji: "😲" },
  { value: "love", label: "사랑", emoji: "😍" },
  { value: "confused", label: "혼란", emoji: "😕" },
]

// 일기장 섹션 목록
const diarySections = [
  { value: "daily", label: "일상 기록" },
  { value: "gratitude", label: "감사 일기" },
  { value: "dream", label: "꿈 일기" },
  { value: "goal", label: "목표 일기" },
  { value: "travel", label: "여행 일기" },
  { value: "food", label: "식사 일기" },
  { value: "study", label: "학습 일기" },
  { value: "work", label: "업무 일기" },
  { value: "health", label: "건강 일기" },
  { value: "reflection", label: "성찰 일기" },
]

// 배경 이미지 목록
const backgroundImages = [
  { value: "none", label: "없음", url: "" },
  {
    value: "nature",
    label: "자연",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%281%29.jpg-WiRRI9UlNWv99roT0HaNU3tm0f4Kep.jpeg",
  },
  { value: "sky", label: "하늘", url: "/placeholder.svg?height=400&width=600&text=하늘" },
  { value: "ocean", label: "바다", url: "/placeholder.svg?height=400&width=600&text=바다" },
  { value: "mountain", label: "산", url: "/placeholder.svg?height=400&width=600&text=산" },
  { value: "forest", label: "숲", url: "/placeholder.svg?height=400&width=600&text=숲" },
  { value: "city", label: "도시", url: "/placeholder.svg?height=400&width=600&text=도시" },
  { value: "abstract", label: "추상", url: "/placeholder.svg?height=400&width=600&text=추상" },
]

// 스티커 목록
const stickers = [
  { id: "monkey", url: "/placeholder.svg?height=100&width=100&text=원숭이", label: "원숭이" },
  { id: "rabbit", url: "/placeholder.svg?height=100&width=100&text=토끼", label: "토끼" },
  { id: "dog", url: "/placeholder.svg?height=100&width=100&text=강아지", label: "강아지" },
  { id: "panda", url: "/placeholder.svg?height=100&width=100&text=판다", label: "판다" },
  { id: "cat", url: "/placeholder.svg?height=100&width=100&text=고양이", label: "고양이" },
  { id: "princess", url: "/placeholder.svg?height=100&width=100&text=공주", label: "공주" },
  { id: "cake", url: "/placeholder.svg?height=100&width=100&text=케이크", label: "케이크" },
  { id: "rainbow", url: "/placeholder.svg?height=100&width=100&text=무지개", label: "무지개" },
  { id: "smile", url: "/placeholder.svg?height=100&width=100&text=스마일", label: "스마일" },
]

// 텍스트 색상 목록
const textColors = [
  { value: "#000000", label: "검정" },
  { value: "#333333", label: "짙은 회색" },
  { value: "#555555", label: "회색" },
  { value: "#FFFFFF", label: "흰색" },
  { value: "#ECF0F1", label: "밝은 회색" },
  { value: "#4B0082", label: "짙은 보라색" },
  { value: "#FFDC00", label: "밝은 노랑" },
  { value: "#FFFFF0", label: "아이보리" },
  { value: "#e74c3c", label: "빨강" },
  { value: "#3498db", label: "파랑" },
]

// 텍스트 폰트 목록
const textFonts = [
  { value: "'Noto Sans KR', sans-serif", label: "기본" },
  { value: "'Nanum Myeongjo', serif", label: "명조" },
  { value: "'Nanum Pen Script', cursive", label: "펜 글씨" },
  { value: "'Gaegu', cursive", label: "개구" },
  { value: "'Gamja Flower', cursive", label: "감자 꽃" },
  { value: "'Jua', sans-serif", label: "주아" },
  { value: "'Poor Story', cursive", label: "푸어 스토리" },
]

export default function DiaryEditor() {
  const [date, setDate] = useState<Date>(new Date())
  const [section, setSection] = useState("daily")
  const [title, setTitle] = useState("")
  const [emotion, setEmotion] = useState("happy")
  const [content, setContent] = useState("")
  const [backgroundImage, setBackgroundImage] = useState("")
  const [textColor, setTextColor] = useState("#000000")
  const [textFont, setTextFont] = useState("'Noto Sans KR', sans-serif")
  const [selectedStickers, setSelectedStickers] = useState<string[]>([])
  const [photos, setPhotos] = useState<string[]>([])
  const [isEmotionDialogOpen, setIsEmotionDialogOpen] = useState(false)
  const [isStickerDialogOpen, setIsStickerDialogOpen] = useState(false)
  const [isBackgroundDialogOpen, setIsBackgroundDialogOpen] = useState(false)
  const [isTextStyleDialogOpen, setIsTextStyleDialogOpen] = useState(false)

  const fileInputRef = useRef<HTMLInputElement>(null)

  // 이모티콘 선택 처리
  const handleEmotionSelect = (value: string) => {
    setEmotion(value)
    setIsEmotionDialogOpen(false)
  }

  // 스티커 선택 처리
  const handleStickerSelect = (stickerId: string) => {
    if (selectedStickers.includes(stickerId)) {
      setSelectedStickers(selectedStickers.filter((id) => id !== stickerId))
    } else {
      setSelectedStickers([...selectedStickers, stickerId])
    }
  }

  // 배경 이미지 선택 처리
  const handleBackgroundSelect = (url: string) => {
    setBackgroundImage(url)
    setIsBackgroundDialogOpen(false)
  }

  // 파일 업로드 처리
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newPhotos: string[] = []

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          newPhotos.push(e.target.result as string)
          if (newPhotos.length === files.length) {
            setPhotos([...photos, ...newPhotos])
          }
        }
      }
      reader.readAsDataURL(file)
    })
  }

  // 일기 저장 처리
  const handleSaveDiary = () => {
    // 여기에 일기 저장 로직 구현
    alert("일기가 저장되었습니다!")
  }

  // 선택된 감정 이모티콘 가져오기
  const getSelectedEmotion = () => {
    return emotions.find((e) => e.value === emotion)?.emoji || "😊"
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>일기 작성</CardTitle>
            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {format(date, "PPP", { locale: ko })}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => date && setDate(date)}
                    initialFocus
                    locale={ko}
                  />
                </PopoverContent>
              </Popover>
              <Button onClick={handleSaveDiary}>
                <Save className="h-4 w-4 mr-2" />
                저장
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* 섹션 선택 */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="section">섹션 선택</Label>
                <Select value={section} onValueChange={setSection}>
                  <SelectTrigger id="section">
                    <SelectValue placeholder="섹션 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {diarySections.map((section) => (
                      <SelectItem key={section.value} value={section.value}>
                        {section.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 제목 입력 */}
              <div className="md:col-span-2">
                <Label htmlFor="title">제목</Label>
                <Input
                  id="title"
                  placeholder="일기 제목을 입력하세요"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              {/* 오늘의 감정 */}
              <div>
                <Label>오늘의 감정</Label>
                <Dialog open={isEmotionDialogOpen} onOpenChange={setIsEmotionDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full">
                      <span className="text-2xl mr-2">{getSelectedEmotion()}</span>
                      <span>{emotions.find((e) => e.value === emotion)?.label}</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>오늘의 감정 선택</DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-5 gap-2 mt-4">
                      {emotions.map((emotion) => (
                        <Button
                          key={emotion.value}
                          variant="outline"
                          className="h-16 flex flex-col"
                          onClick={() => handleEmotionSelect(emotion.value)}
                        >
                          <span className="text-2xl">{emotion.emoji}</span>
                          <span className="text-xs mt-1">{emotion.label}</span>
                        </Button>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* 일기 작성 도구 */}
            <div className="flex flex-wrap gap-2">
              <Dialog open={isStickerDialogOpen} onOpenChange={setIsStickerDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Smile className="h-4 w-4 mr-2" />
                    이모티콘
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>이모티콘 선택</DialogTitle>
                  </DialogHeader>
                  <Tabs defaultValue="all">
                    <TabsList className="grid w-full grid-cols-5">
                      <TabsTrigger value="all">전체</TabsTrigger>
                      <TabsTrigger value="animals">동물</TabsTrigger>
                      <TabsTrigger value="food">음식</TabsTrigger>
                      <TabsTrigger value="nature">자연</TabsTrigger>
                      <TabsTrigger value="emoji">이모지</TabsTrigger>
                    </TabsList>
                    <TabsContent value="all" className="mt-4">
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                        {stickers.map((sticker) => (
                          <div
                            key={sticker.id}
                            className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                              selectedStickers.includes(sticker.id) ? "ring-2 ring-primary" : ""
                            }`}
                            onClick={() => handleStickerSelect(sticker.id)}
                          >
                            <div className="aspect-square flex items-center justify-center">
                              <img
                                src={sticker.url || "/placeholder.svg"}
                                alt={sticker.label}
                                className="max-h-full max-w-full object-contain"
                              />
                            </div>
                            <p className="text-xs text-center mt-1">{sticker.label}</p>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="animals" className="mt-4">
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                        {stickers
                          .filter((s) => ["monkey", "rabbit", "dog", "panda", "cat"].includes(s.id))
                          .map((sticker) => (
                            <div
                              key={sticker.id}
                              className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                                selectedStickers.includes(sticker.id) ? "ring-2 ring-primary" : ""
                              }`}
                              onClick={() => handleStickerSelect(sticker.id)}
                            >
                              <div className="aspect-square flex items-center justify-center">
                                <img
                                  src={sticker.url || "/placeholder.svg"}
                                  alt={sticker.label}
                                  className="max-h-full max-w-full object-contain"
                                />
                              </div>
                              <p className="text-xs text-center mt-1">{sticker.label}</p>
                            </div>
                          ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="food" className="mt-4">
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                        {stickers
                          .filter((s) => ["cake"].includes(s.id))
                          .map((sticker) => (
                            <div
                              key={sticker.id}
                              className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                                selectedStickers.includes(sticker.id) ? "ring-2 ring-primary" : ""
                              }`}
                              onClick={() => handleStickerSelect(sticker.id)}
                            >
                              <div className="aspect-square flex items-center justify-center">
                                <img
                                  src={sticker.url || "/placeholder.svg"}
                                  alt={sticker.label}
                                  className="max-h-full max-w-full object-contain"
                                />
                              </div>
                              <p className="text-xs text-center mt-1">{sticker.label}</p>
                            </div>
                          ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="nature" className="mt-4">
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                        {stickers
                          .filter((s) => ["rainbow"].includes(s.id))
                          .map((sticker) => (
                            <div
                              key={sticker.id}
                              className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                                selectedStickers.includes(sticker.id) ? "ring-2 ring-primary" : ""
                              }`}
                              onClick={() => handleStickerSelect(sticker.id)}
                            >
                              <div className="aspect-square flex items-center justify-center">
                                <img
                                  src={sticker.url || "/placeholder.svg"}
                                  alt={sticker.label}
                                  className="max-h-full max-w-full object-contain"
                                />
                              </div>
                              <p className="text-xs text-center mt-1">{sticker.label}</p>
                            </div>
                          ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="emoji" className="mt-4">
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                        {stickers
                          .filter((s) => ["smile", "princess"].includes(s.id))
                          .map((sticker) => (
                            <div
                              key={sticker.id}
                              className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                                selectedStickers.includes(sticker.id) ? "ring-2 ring-primary" : ""
                              }`}
                              onClick={() => handleStickerSelect(sticker.id)}
                            >
                              <div className="aspect-square flex items-center justify-center">
                                <img
                                  src={sticker.url || "/placeholder.svg"}
                                  alt={sticker.label}
                                  className="max-h-full max-w-full object-contain"
                                />
                              </div>
                              <p className="text-xs text-center mt-1">{sticker.label}</p>
                            </div>
                          ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </DialogContent>
              </Dialog>

              <Dialog open={isBackgroundDialogOpen} onOpenChange={setIsBackgroundDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <PaintBucket className="h-4 w-4 mr-2" />
                    배경 선택
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>배경 이미지 선택</DialogTitle>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    {backgroundImages.map((bg) => (
                      <div
                        key={bg.value}
                        className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                          backgroundImage === bg.url ? "ring-2 ring-primary" : ""
                        }`}
                        onClick={() => handleBackgroundSelect(bg.url)}
                      >
                        {bg.url ? (
                          <div className="aspect-video relative overflow-hidden rounded-md">
                            <img
                              src={bg.url || "/placeholder.svg"}
                              alt={bg.label}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-1 text-xs text-center">
                              {bg.label}
                            </div>
                          </div>
                        ) : (
                          <div className="aspect-video flex items-center justify-center bg-muted rounded-md">
                            <span>{bg.label}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={isTextStyleDialogOpen} onOpenChange={setIsTextStyleDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Type className="h-4 w-4 mr-2" />
                    텍스트 스타일
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>텍스트 스타일 설정</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-4">
                    <div>
                      <Label htmlFor="textColor">텍스트 색상</Label>
                      <div className="grid grid-cols-5 gap-2 mt-2">
                        {textColors.map((color) => (
                          <button
                            key={color.value}
                            className={`w-full h-10 rounded-md border ${
                              textColor === color.value ? "ring-2 ring-primary" : ""
                            }`}
                            style={{ backgroundColor: color.value }}
                            onClick={() => setTextColor(color.value)}
                            title={color.label}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="textFont">텍스트 폰트</Label>
                      <Select value={textFont} onValueChange={setTextFont}>
                        <SelectTrigger id="textFont">
                          <SelectValue placeholder="폰트 선택" />
                        </SelectTrigger>
                        <SelectContent>
                          {textFonts.map((font) => (
                            <SelectItem key={font.value} value={font.value}>
                              <span style={{ fontFamily: font.value }}>{font.label}</span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="p-4 border rounded-md" style={{ color: textColor, fontFamily: textFont }}>
                      <p className="text-lg font-medium">텍스트 미리보기</p>
                      <p>이렇게 텍스트가 표시됩니다. 원하는 스타일을 선택하세요.</p>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                <Image className="h-4 w-4 mr-2" />
                사진 추가
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  multiple
                  onChange={handleFileUpload}
                />
              </Button>

              <Button variant="outline" size="sm">
                <FileText className="h-4 w-4 mr-2" />
                템플릿 적용
              </Button>
            </div>

            {/* 일기 내용 작성 영역 */}
            <div
              className="relative border rounded-md p-4 min-h-[400px]"
              style={{
                backgroundImage: backgroundImage ? `url(${backgroundImage})` : "none",
                backgroundSize: "cover",
                backgroundPosition: "center",
                color: textColor,
                fontFamily: textFont,
              }}
            >
              {/* 선택된 스티커 표시 */}
              {selectedStickers.length > 0 && (
                <div className="absolute top-2 right-2 flex flex-wrap gap-2 max-w-[150px]">
                  {selectedStickers.map((stickerId) => {
                    const sticker = stickers.find((s) => s.id === stickerId)
                    return sticker ? (
                      <div key={stickerId} className="w-10 h-10">
                        <img
                          src={sticker.url || "/placeholder.svg"}
                          alt={sticker.label}
                          className="w-full h-full object-contain"
                        />
                      </div>
                    ) : null
                  })}
                </div>
              )}

              {/* 업로드된 사진 표시 */}
              {photos.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {photos.map((photo, index) => (
                    <div key={index} className="relative w-24 h-24 border rounded-md overflow-hidden">
                      <img
                        src={photo || "/placeholder.svg"}
                        alt={`업로드 이미지 ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}

              <Textarea
                placeholder="오늘의 일기를 작성해보세요..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="min-h-[300px] bg-transparent border-none focus-visible:ring-0 focus-visible:ring-offset-0 resize-none"
                style={{ color: textColor, fontFamily: textFont }}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">{format(date, "yyyy년 MM월 dd일 EEEE", { locale: ko })}</div>
          <Button onClick={handleSaveDiary}>저장</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

