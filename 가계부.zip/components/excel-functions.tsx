"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import {
  FileUp,
  Download,
  Search,
  SortAsc,
  SortDesc,
  Calculator,
  PieChart,
  Table2,
  BarChart4,
  Sigma,
  Percent,
  ArrowUpDown,
} from "lucide-react"

// 가상의 데이터
const sampleData = [
  {
    id: 1,
    date: "2023-12-15",
    category: "소모품",
    vendor: "오피스디포",
    item: "A4 용지",
    quantity: 10,
    unitPrice: 5000,
    amount: 50000,
    taxRate: 10,
    taxAmount: 5000,
    totalAmount: 55000,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 2,
    date: "2023-12-15",
    category: "소모품",
    vendor: "오피스디포",
    item: "볼펜",
    quantity: 50,
    unitPrice: 1000,
    amount: 50000,
    taxRate: 10,
    taxAmount: 5000,
    totalAmount: 55000,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 3,
    date: "2023-12-15",
    category: "소모품",
    vendor: "오피스디포",
    item: "포스트잇",
    quantity: 20,
    unitPrice: 1000,
    amount: 20000,
    taxRate: 10,
    taxAmount: 2000,
    totalAmount: 22000,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 4,
    date: "2023-12-10",
    category: "전자기기",
    vendor: "삼성전자",
    item: "갤럭시북",
    quantity: 3,
    unitPrice: 500000,
    amount: 1500000,
    taxRate: 10,
    taxAmount: 150000,
    totalAmount: 1650000,
    paymentMethod: "계좌이체",
    paymentStatus: "완료",
  },
  {
    id: 5,
    date: "2023-12-05",
    category: "복리후생",
    vendor: "쿠팡",
    item: "커피",
    quantity: 5,
    unitPrice: 10000,
    amount: 50000,
    taxRate: 10,
    taxAmount: 5000,
    totalAmount: 55000,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 6,
    date: "2023-12-05",
    category: "복리후생",
    vendor: "쿠팡",
    item: "과자세트",
    quantity: 5,
    unitPrice: 7000,
    amount: 35000,
    taxRate: 10,
    taxAmount: 3500,
    totalAmount: 38500,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 7,
    date: "2023-11-20",
    category: "소모품",
    vendor: "오피스디포",
    item: "A4 용지",
    quantity: 5,
    unitPrice: 5000,
    amount: 25000,
    taxRate: 10,
    taxAmount: 2500,
    totalAmount: 27500,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 8,
    date: "2023-11-15",
    category: "복리후생",
    vendor: "쿠팡",
    item: "커피",
    quantity: 3,
    unitPrice: 10000,
    amount: 30000,
    taxRate: 10,
    taxAmount: 3000,
    totalAmount: 33000,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
  {
    id: 9,
    date: "2023-11-10",
    category: "전자기기",
    vendor: "LG전자",
    item: "모니터",
    quantity: 2,
    unitPrice: 300000,
    amount: 600000,
    taxRate: 10,
    taxAmount: 60000,
    totalAmount: 660000,
    paymentMethod: "계좌이체",
    paymentStatus: "완료",
  },
  {
    id: 10,
    date: "2023-11-05",
    category: "소모품",
    vendor: "오피스디포",
    item: "볼펜",
    quantity: 30,
    unitPrice: 1000,
    amount: 30000,
    taxRate: 10,
    taxAmount: 3000,
    totalAmount: 33000,
    paymentMethod: "카드",
    paymentStatus: "완료",
  },
]

export default function ExcelFunctions() {
  const [data, setData] = useState(sampleData)
  const [activeTab, setActiveTab] = useState("data")
  const [selectedRows, setSelectedRows] = useState<number[]>([])
  const [pivotField, setPivotField] = useState("category")
  const [pivotValue, setPivotValue] = useState("amount")
  const [filterField, setFilterField] = useState("")
  const [filterValue, setFilterValue] = useState("")
  const [sortField, setSortField] = useState("date")
  const [sortDirection, setSortDirection] = useState("desc")
  const [conditionalFormat, setConditionalFormat] = useState(true)

  // 피벗 테이블 데이터 계산
  const getPivotData = () => {
    const pivotData: Record<string, number> = {}

    data.forEach((item) => {
      const key = item[pivotField as keyof typeof item] as string
      const value = item[pivotValue as keyof typeof item] as number

      if (!pivotData[key]) {
        pivotData[key] = 0
      }

      pivotData[key] += value
    })

    return Object.entries(pivotData).map(([key, value]) => ({
      key,
      value,
    }))
  }

  // 필터링된 데이터 가져오기
  const getFilteredData = () => {
    if (!filterField || !filterValue) return data

    return data.filter((item) => {
      const fieldValue = item[filterField as keyof typeof item]
      if (typeof fieldValue === "string") {
        return fieldValue.toLowerCase().includes(filterValue.toLowerCase())
      } else if (typeof fieldValue === "number") {
        return fieldValue.toString().includes(filterValue)
      }
      return false
    })
  }

  // 정렬된 데이터 가져오기
  const getSortedData = () => {
    const filtered = getFilteredData()

    return [...filtered].sort((a, b) => {
      const aValue = a[sortField as keyof typeof a]
      const bValue = b[sortField as keyof typeof b]

      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
      } else if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue
      }

      return 0
    })
  }

  // 합계 계산
  const calculateSum = (field: string) => {
    return getFilteredData().reduce((sum, item) => sum + ((item[field as keyof typeof item] as number) || 0), 0)
  }

  // 평균 계산
  const calculateAverage = (field: string) => {
    const filteredData = getFilteredData()
    if (filteredData.length === 0) return 0
    return calculateSum(field) / filteredData.length
  }

  // 최대값 계산
  const calculateMax = (field: string) => {
    return Math.max(...getFilteredData().map((item) => (item[field as keyof typeof item] as number) || 0))
  }

  // 최소값 계산
  const calculateMin = (field: string) => {
    const values = getFilteredData().map((item) => (item[field as keyof typeof item] as number) || 0)
    return values.length > 0 ? Math.min(...values) : 0
  }

  // 행 선택 처리
  const toggleRowSelection = (id: number) => {
    if (selectedRows.includes(id)) {
      setSelectedRows(selectedRows.filter((rowId) => rowId !== id))
    } else {
      setSelectedRows([...selectedRows, id])
    }
  }

  // 모든 행 선택/해제
  const toggleAllRows = () => {
    if (selectedRows.length === data.length) {
      setSelectedRows([])
    } else {
      setSelectedRows(data.map((item) => item.id))
    }
  }

  // 조건부 서식 적용
  const getConditionalStyle = (value: number, field: string) => {
    if (!conditionalFormat) return {}

    if (field === "amount" || field === "totalAmount") {
      if (value > 500000) return { backgroundColor: "rgba(239, 68, 68, 0.1)", color: "rgb(185, 28, 28)" }
      if (value > 100000) return { backgroundColor: "rgba(245, 158, 11, 0.1)", color: "rgb(180, 83, 9)" }
      if (value > 50000) return { backgroundColor: "rgba(16, 185, 129, 0.1)", color: "rgb(4, 120, 87)" }
    }

    return {}
  }

  // 엑셀 내보내기
  const exportToExcel = () => {
    alert("엑셀 내보내기 기능은 준비 중입니다.")
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">엑셀 기능</h2>
        <div className="flex gap-2">
          <Button variant="outline">
            <FileUp className="mr-2 h-4 w-4" />
            가져오기
          </Button>
          <Button variant="outline" onClick={exportToExcel}>
            <Download className="mr-2 h-4 w-4" />
            내보내기
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="data">데이터</TabsTrigger>
          <TabsTrigger value="pivot">피벗 테이블</TabsTrigger>
          <TabsTrigger value="chart">차트</TabsTrigger>
          <TabsTrigger value="formula">수식 및 함수</TabsTrigger>
        </TabsList>

        <TabsContent value="data">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>데이터 테이블</CardTitle>
                  <CardDescription>데이터를 필터링하고 정렬하세요</CardDescription>
                </div>
                <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="검색..."
                      className="pl-8"
                      value={filterValue}
                      onChange={(e) => setFilterValue(e.target.value)}
                    />
                  </div>

                  <Select value={filterField} onValueChange={setFilterField}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="필터 필드 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">필터 없음</SelectItem>
                      <SelectItem value="category">카테고리</SelectItem>
                      <SelectItem value="vendor">거래처</SelectItem>
                      <SelectItem value="item">품목</SelectItem>
                      <SelectItem value="paymentMethod">결제 방법</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="gap-1"
                      onClick={() => setSortDirection(sortDirection === "asc" ? "desc" : "asc")}
                    >
                      {sortDirection === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
                    </Button>
                    <Select value={sortField} onValueChange={setSortField}>
                      <SelectTrigger className="w-full md:w-[180px]">
                        <SelectValue placeholder="정렬 필드 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="date">날짜</SelectItem>
                        <SelectItem value="category">카테고리</SelectItem>
                        <SelectItem value="vendor">거래처</SelectItem>
                        <SelectItem value="amount">금액</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40px]">
                        <Checkbox checked={selectedRows.length === data.length} onCheckedChange={toggleAllRows} />
                      </TableHead>
                      <TableHead>날짜</TableHead>
                      <TableHead>카테고리</TableHead>
                      <TableHead>거래처</TableHead>
                      <TableHead>품목</TableHead>
                      <TableHead className="text-right">수량</TableHead>
                      <TableHead className="text-right">단가</TableHead>
                      <TableHead className="text-right">공급가액</TableHead>
                      <TableHead className="text-right">세액</TableHead>
                      <TableHead className="text-right">합계</TableHead>
                      <TableHead>결제 방법</TableHead>
                      <TableHead>결제 상태</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getSortedData().map((item) => (
                      <TableRow key={item.id} className={selectedRows.includes(item.id) ? "bg-muted/50" : ""}>
                        <TableCell>
                          <Checkbox
                            checked={selectedRows.includes(item.id)}
                            onCheckedChange={() => toggleRowSelection(item.id)}
                          />
                        </TableCell>
                        <TableCell>{item.date}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>{item.vendor}</TableCell>
                        <TableCell>{item.item}</TableCell>
                        <TableCell className="text-right">{item.quantity.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{item.unitPrice.toLocaleString()}원</TableCell>
                        <TableCell className="text-right" style={getConditionalStyle(item.amount, "amount")}>
                          {item.amount.toLocaleString()}원
                        </TableCell>
                        <TableCell className="text-right">{item.taxAmount.toLocaleString()}원</TableCell>
                        <TableCell
                          className="text-right font-medium"
                          style={getConditionalStyle(item.totalAmount, "totalAmount")}
                        >
                          {item.totalAmount.toLocaleString()}원
                        </TableCell>
                        <TableCell>{item.paymentMethod}</TableCell>
                        <TableCell>{item.paymentStatus}</TableCell>
                      </TableRow>
                    ))}
                    {getSortedData().length === 0 && (
                      <TableRow>
                        <TableCell colSpan={12} className="text-center py-4 text-muted-foreground">
                          검색 결과가 없습니다
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">총 {getSortedData().length}개 항목</div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <Label htmlFor="conditional-format" className="text-sm">
                    조건부 서식:
                  </Label>
                  <Checkbox
                    id="conditional-format"
                    checked={conditionalFormat}
                    onCheckedChange={(checked) => setConditionalFormat(!!checked)}
                  />
                </div>
                <div className="text-sm">
                  선택: <span className="font-medium">{selectedRows.length}개</span>
                </div>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="pivot">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>피벗 테이블</CardTitle>
                  <CardDescription>데이터를 다양한 관점에서 분석하세요</CardDescription>
                </div>
                <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
                  <Select value={pivotField} onValueChange={setPivotField}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="행 필드 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="category">카테고리</SelectItem>
                      <SelectItem value="vendor">거래처</SelectItem>
                      <SelectItem value="item">품목</SelectItem>
                      <SelectItem value="paymentMethod">결제 방법</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={pivotValue} onValueChange={setPivotValue}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="값 필드 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="amount">공급가액</SelectItem>
                      <SelectItem value="taxAmount">세액</SelectItem>
                      <SelectItem value="totalAmount">합계</SelectItem>
                      <SelectItem value="quantity">수량</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        {pivotField === "category"
                          ? "카테고리"
                          : pivotField === "vendor"
                            ? "거래처"
                            : pivotField === "item"
                              ? "품목"
                              : "결제 방법"}
                      </TableHead>
                      <TableHead className="text-right">
                        {pivotValue === "amount"
                          ? "공급가액"
                          : pivotValue === "taxAmount"
                            ? "세액"
                            : pivotValue === "totalAmount"
                              ? "합계"
                              : "수량"}
                      </TableHead>
                      <TableHead className="text-right">비율</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getPivotData().map((item, index) => {
                      const total = getPivotData().reduce((sum, i) => sum + i.value, 0)
                      const percentage = total > 0 ? (item.value / total) * 100 : 0

                      return (
                        <TableRow key={index}>
                          <TableCell>{item.key}</TableCell>
                          <TableCell className="text-right">
                            {item.value.toLocaleString()}
                            {pivotValue !== "quantity" ? "원" : ""}
                          </TableCell>
                          <TableCell className="text-right">{percentage.toFixed(1)}%</TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">총 {getPivotData().length}개 항목</div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <PieChart className="mr-2 h-4 w-4" />
                  차트로 보기
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  내보내기
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="chart">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>데이터 시각화</CardTitle>
                  <CardDescription>데이터를 차트로 시각화하세요</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <PieChart className="mr-2 h-4 w-4" />
                    파이 차트
                  </Button>
                  <Button variant="outline" size="sm">
                    <BarChart4 className="mr-2 h-4 w-4" />
                    막대 차트
                  </Button>
                  <Button variant="outline" size="sm">
                    <ArrowUpDown className="mr-2 h-4 w-4" />선 차트
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] flex items-center justify-center bg-muted rounded-md">
                <div className="text-center">
                  <PieChart className="h-16 w-16 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">차트 유형을 선택하세요</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="formula">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>수식 및 함수</CardTitle>
                  <CardDescription>데이터 계산 및 분석 함수</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Calculator className="mr-2 h-4 w-4" />
                    계산기
                  </Button>
                  <Button variant="outline" size="sm">
                    <Table2 className="mr-2 h-4 w-4" />
                    피벗 테이블
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Sigma className="mr-2 h-4 w-4" />
                      합계 (SUM)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">공급가액:</span>
                        <span className="font-medium">{calculateSum("amount").toLocaleString()}원</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">세액:</span>
                        <span className="font-medium">{calculateSum("taxAmount").toLocaleString()}원</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">합계:</span>
                        <span className="font-medium">{calculateSum("totalAmount").toLocaleString()}원</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Calculator className="mr-2 h-4 w-4" />
                      평균 (AVERAGE)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">공급가액:</span>
                        <span className="font-medium">{calculateAverage("amount").toLocaleString()}원</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">세액:</span>
                        <span className="font-medium">{calculateAverage("taxAmount").toLocaleString()}원</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">합계:</span>
                        <span className="font-medium">{calculateAverage("totalAmount").toLocaleString()}원</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <ArrowUpDown className="mr-2 h-4 w-4" />
                      최대/최소 (MAX/MIN)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">최대 금액:</span>
                        <span className="font-medium">{calculateMax("totalAmount").toLocaleString()}원</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">최소 금액:</span>
                        <span className="font-medium">{calculateMin("totalAmount").toLocaleString()}원</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">최대 수량:</span>
                        <span className="font-medium">{calculateMax("quantity").toLocaleString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Percent className="mr-2 h-4 w-4" />
                      비율 (PERCENTAGE)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">세액 비율:</span>
                        <span className="font-medium">
                          {((calculateSum("taxAmount") / calculateSum("amount")) * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">카테고리 비율:</span>
                        <span className="font-medium">
                          {getPivotData().length > 0
                            ? getPivotData()[0].key +
                              ": " +
                              (
                                (getPivotData()[0].value / getPivotData().reduce((sum, i) => sum + i.value, 0)) *
                                100
                              ).toFixed(1) +
                              "%"
                            : "0%"}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

