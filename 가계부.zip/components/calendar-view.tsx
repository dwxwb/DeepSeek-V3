"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, ChevronRight, Download, Filter, CalendarIcon, ArrowUpDown, RefreshCw } from "lucide-react"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameDay,
  addMonths,
  subMonths,
  isSameMonth,
  parseISO,
  isToday,
} from "date-fns"
import { ko } from "date-fns/locale"
import { getEmojiForCategoryName } from "@/lib/category-data"

// 통합 거래 타입 정의
type TransactionType = "가계부" | "매입" | "매출" | "정기거래"

interface Transaction {
  id: number
  date: string
  type: TransactionType
  category: string
  description: string
  amount: number
  paymentMethod?: string
  customer?: string
  memo?: string
  recurring?: boolean
  frequency?: string
}

// 가상의 가계부 데이터
const ledgerData: Transaction[] = [
  {
    id: 1,
    date: "2024-04-15",
    type: "가계부",
    category: "식비",
    description: "점심 식사",
    amount: -12000,
    paymentMethod: "신용카드",
    memo: "",
  },
  {
    id: 2,
    date: "2024-04-14",
    type: "가계부",
    category: "교통",
    description: "지하철 요금",
    amount: -1500,
    paymentMethod: "교통카드",
    memo: "출근",
  },
  {
    id: 3,
    date: "2024-04-13",
    type: "가계부",
    category: "쇼핑",
    description: "생필품 구매",
    amount: -35000,
    paymentMethod: "체크카드",
    memo: "샴푸, 치약 등",
  },
  {
    id: 4,
    date: "2024-04-10",
    type: "가계부",
    category: "급여",
    description: "4월 급여",
    amount: 2500000,
    paymentMethod: "계좌이체",
    memo: "",
  },
  {
    id: 5,
    date: "2024-04-05",
    type: "가계부",
    category: "통신",
    description: "휴대폰 요금",
    amount: -55000,
    paymentMethod: "자동이체",
    memo: "",
  },
]

// 가상의 매입/매출 데이터
const transactionData: Transaction[] = [
  {
    id: 101,
    date: "2024-04-16",
    type: "매출",
    category: "판매",
    description: "제품 판매",
    amount: 150000,
    customer: "홍길동",
    paymentMethod: "신용카드",
    memo: "정기 고객",
  },
  {
    id: 102,
    date: "2024-04-12",
    type: "매입",
    category: "소모품",
    description: "사무용품 구매",
    amount: -45000,
    customer: "문구점",
    paymentMethod: "체크카드",
    memo: "종이, 펜 등",
  },
  {
    id: 103,
    date: "2024-04-08",
    type: "매출",
    category: "서비스",
    description: "서비스 제공",
    amount: 200000,
    customer: "김철수",
    paymentMethod: "계좌이체",
    memo: "",
  },
  {
    id: 104,
    date: "2024-04-05",
    type: "매입",
    category: "식비",
    description: "직원 식대",
    amount: -85000,
    customer: "식당",
    paymentMethod: "법인카드",
    memo: "회식",
  },
  {
    id: 105,
    date: "2024-04-01",
    type: "매출",
    category: "판매",
    description: "제품 판매",
    amount: 120000,
    customer: "이영희",
    paymentMethod: "현금",
    memo: "",
  },
]

// 가상의 정기 거래 데이터
const recurringData: Transaction[] = [
  {
    id: 201,
    date: "2024-04-25",
    type: "정기거래",
    category: "월급",
    description: "직원 급여",
    amount: -3500000,
    paymentMethod: "계좌이체",
    recurring: true,
    frequency: "monthly",
  },
  {
    id: 202,
    date: "2024-04-20",
    type: "정기거래",
    category: "임대료",
    description: "사무실 임대료",
    amount: -1200000,
    paymentMethod: "자동이체",
    recurring: true,
    frequency: "monthly",
  },
  {
    id: 203,
    date: "2024-04-15",
    type: "정기거래",
    category: "통신",
    description: "인터넷 요금",
    amount: -55000,
    paymentMethod: "자동이체",
    recurring: true,
    frequency: "monthly",
  },
  {
    id: 204,
    date: "2024-04-10",
    type: "정기거래",
    category: "구독",
    description: "소프트웨어 구독",
    amount: -29000,
    paymentMethod: "신용카드",
    recurring: true,
    frequency: "monthly",
  },
  {
    id: 205,
    date: "2024-04-05",
    type: "정기거래",
    category: "보험",
    description: "보험료",
    amount: -150000,
    paymentMethod: "자동이체",
    recurring: true,
    frequency: "monthly",
  },
]

// 모든 거래 데이터 통합
const allTransactions: Transaction[] = [...ledgerData, ...transactionData, ...recurringData]

export default function CalendarView() {
  const [date, setDate] = useState<Date>(new Date())
  const [viewMode, setViewMode] = useState<"month" | "day">("month")
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [openTransactionDetail, setOpenTransactionDetail] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const [filterType, setFilterType] = useState<"all" | "가계부" | "매입" | "매출" | "정기거래">("all")
  const [transactions, setTransactions] = useState<Transaction[]>(allTransactions)
  const [isLoading, setIsLoading] = useState(false)

  // 현재 월의 날짜 범위 계산
  const monthStart = startOfMonth(date)
  const monthEnd = endOfMonth(date)
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd })

  // 날짜별 거래 데이터 그룹화
  const getTransactionsForDate = (day: Date) => {
    return transactions.filter((transaction) => {
      const transactionDate = parseISO(transaction.date)
      return (
        isSameDay(transactionDate, day) &&
        (filterType === "all" ||
          (filterType === "매입" && transaction.type === "매입") ||
          (filterType === "매출" && transaction.type === "매출") ||
          (filterType === "가계부" && transaction.type === "가계부") ||
          (filterType === "정기거래" && transaction.type === "정기거래"))
      )
    })
  }

  // 월별 거래 데이터 그룹화
  const getTransactionsForMonth = (month: Date) => {
    return transactions.filter((transaction) => {
      const transactionDate = parseISO(transaction.date)
      return (
        isSameMonth(transactionDate, month) &&
        (filterType === "all" ||
          (filterType === "매입" && transaction.type === "매입") ||
          (filterType === "매출" && transaction.type === "매출") ||
          (filterType === "가계부" && transaction.type === "가계부") ||
          (filterType === "정기거래" && transaction.type === "정기거래"))
      )
    })
  }

  // 날짜별 총 금액 계산
  const getTotalForDate = (day: Date, type: "수입" | "지출" | "all") => {
    const dayTransactions = getTransactionsForDate(day)

    if (type === "all") {
      return dayTransactions.reduce((sum, transaction) => sum + transaction.amount, 0)
    } else if (type === "수입") {
      return dayTransactions
        .filter((transaction) => transaction.amount > 0)
        .reduce((sum, transaction) => sum + transaction.amount, 0)
    } else {
      return dayTransactions
        .filter((transaction) => transaction.amount < 0)
        .reduce((sum, transaction) => sum + transaction.amount, 0)
    }
  }

  // 월별 총 금액 계산
  const getTotalForMonth = (month: Date, type: "수입" | "지출" | "all") => {
    const monthTransactions = getTransactionsForMonth(month)

    if (type === "all") {
      return monthTransactions.reduce((sum, transaction) => sum + transaction.amount, 0)
    } else if (type === "수입") {
      return monthTransactions
        .filter((transaction) => transaction.amount > 0)
        .reduce((sum, transaction) => sum + transaction.amount, 0)
    } else {
      return monthTransactions
        .filter((transaction) => transaction.amount < 0)
        .reduce((sum, transaction) => sum + transaction.amount, 0)
    }
  }

  // 날짜 선택 처리
  const handleDateSelect = (day: Date) => {
    setSelectedDate(day)
    setViewMode("day")
  }

  // 거래 선택 처리
  const handleTransactionSelect = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setOpenTransactionDetail(true)
  }

  // 이전 달로 이동
  const goToPreviousMonth = () => {
    setDate(subMonths(date, 1))
  }

  // 다음 달로 이동
  const goToNextMonth = () => {
    setDate(addMonths(date, 1))
  }

  // 오늘로 이동
  const goToToday = () => {
    setDate(new Date())
    if (viewMode === "day") {
      setSelectedDate(new Date())
    }
  }

  // 월 뷰로 돌아가기
  const backToMonthView = () => {
    setViewMode("month")
    setSelectedDate(null)
  }

  // 데이터 새로고침
  const refreshData = () => {
    setIsLoading(true)

    // 실제 구현에서는 여기서 API 호출을 통해 최신 데이터를 가져올 것입니다.
    setTimeout(() => {
      setTransactions(allTransactions)
      setIsLoading(false)
    }, 1000)
  }

  // 현재 표시 중인 거래 데이터
  const currentTransactions =
    viewMode === "day" && selectedDate ? getTransactionsForDate(selectedDate) : getTransactionsForMonth(date)

  // 거래 유형에 따른 배지 색상
  const getTransactionTypeBadge = (type: TransactionType) => {
    switch (type) {
      case "가계부":
        return "default"
      case "매입":
        return "destructive"
      case "매출":
        return "success"
      case "정기거래":
        return "secondary"
      default:
        return "default"
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">캘린더</h2>
        <div className="flex gap-2">
          <Select
            value={filterType}
            onValueChange={(value: "all" | "가계부" | "매입" | "매출" | "정기거래") => setFilterType(value)}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="유형 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">전체</SelectItem>
              <SelectItem value="가계부">가계부</SelectItem>
              <SelectItem value="매입">매입</SelectItem>
              <SelectItem value="매출">매출</SelectItem>
              <SelectItem value="정기거래">정기거래</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={goToToday}>
            오늘
          </Button>

          <div className="flex">
            <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <Button variant="outline" onClick={refreshData} disabled={isLoading}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            새로고침
          </Button>

          {viewMode === "day" && (
            <Button variant="outline" onClick={backToMonthView}>
              <CalendarIcon className="mr-2 h-4 w-4" />
              월별 보기
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="calendar" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="calendar">캘린더 보기</TabsTrigger>
          <TabsTrigger value="list">목록 보기</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar">
          {viewMode === "month" ? (
            <Card>
              <CardHeader>
                <CardTitle>{format(date, "yyyy년 MM월", { locale: ko })}</CardTitle>
                <CardDescription>{filterType === "all" ? "모든 거래 내역" : `${filterType} 내역`}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-1">
                  {["일", "월", "화", "수", "목", "금", "토"].map((day) => (
                    <div key={day} className="text-center font-medium py-2">
                      {day}
                    </div>
                  ))}

                  {daysInMonth.map((day, i) => {
                    const dayTransactions = getTransactionsForDate(day)
                    const incomeTotal = getTotalForDate(day, "수입")
                    const expenseTotal = getTotalForDate(day, "지출")
                    const hasTransactions = dayTransactions.length > 0

                    // 첫 번째 날의 요일에 맞게 빈 셀 추가
                    const startOffset = i === 0 ? day.getDay() : 0
                    const offsetCells = i === 0 ? Array(startOffset).fill(null) : []

                    return (
                      <>
                        {i === 0 &&
                          offsetCells.map((_, index) => (
                            <div key={`offset-${index}`} className="p-1 border rounded-md bg-muted/20"></div>
                          ))}
                        <div
                          key={day.toString()}
                          className={`p-1 border rounded-md min-h-[100px] cursor-pointer hover:bg-muted/20 ${
                            isToday(day) ? "border-primary" : ""
                          }`}
                          onClick={() => handleDateSelect(day)}
                        >
                          <div
                            className={`text-right font-medium p-1 ${
                              day.getDay() === 0 ? "text-red-500" : day.getDay() === 6 ? "text-blue-500" : ""
                            }`}
                          >
                            {format(day, "d")}
                          </div>

                          {hasTransactions && (
                            <div className="space-y-1 p-1">
                              {incomeTotal > 0 && (
                                <div className="text-xs text-green-600">수입: {incomeTotal.toLocaleString()}원</div>
                              )}
                              {expenseTotal < 0 && (
                                <div className="text-xs text-red-600">
                                  지출: {Math.abs(expenseTotal).toLocaleString()}원
                                </div>
                              )}
                              {dayTransactions.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {filterType === "all" && (
                                    <>
                                      {dayTransactions.some((t) => t.type === "가계부") && (
                                        <Badge variant="outline" className="text-xs">
                                          가계부
                                        </Badge>
                                      )}
                                      {dayTransactions.some((t) => t.type === "매입") && (
                                        <Badge variant="outline" className="text-xs">
                                          매입
                                        </Badge>
                                      )}
                                      {dayTransactions.some((t) => t.type === "매출") && (
                                        <Badge variant="outline" className="text-xs">
                                          매출
                                        </Badge>
                                      )}
                                      {dayTransactions.some((t) => t.type === "정기거래") && (
                                        <Badge variant="outline" className="text-xs">
                                          정기
                                        </Badge>
                                      )}
                                    </>
                                  )}
                                  <Badge variant="outline" className="text-xs">
                                    {dayTransactions.length}건
                                  </Badge>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </>
                    )
                  })}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div>
                  <span className="text-sm text-muted-foreground">총 {currentTransactions.length}건의 거래</span>
                </div>
                <div className="flex gap-4">
                  <div>
                    <span className="text-sm font-medium">수입: </span>
                    <span className="text-sm font-bold text-green-600">
                      {getTotalForMonth(date, "수입").toLocaleString()}원
                    </span>
                  </div>
                  <div>
                    <span className="text-sm font-medium">지출: </span>
                    <span className="text-sm font-bold text-red-600">
                      {Math.abs(getTotalForMonth(date, "지출")).toLocaleString()}원
                    </span>
                  </div>
                  <div>
                    <span className="text-sm font-medium">잔액: </span>
                    <span
                      className={`text-sm font-bold ${getTotalForMonth(date, "all") >= 0 ? "text-blue-600" : "text-red-600"}`}
                    >
                      {getTotalForMonth(date, "all").toLocaleString()}원
                    </span>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>{selectedDate && format(selectedDate, "yyyy년 MM월 dd일", { locale: ko })}</CardTitle>
                <CardDescription>{filterType === "all" ? "모든 거래 내역" : `${filterType} 내역`}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {currentTransactions.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>유형</TableHead>
                          <TableHead>카테고리</TableHead>
                          <TableHead>내용</TableHead>
                          <TableHead>{filterType !== "매입" ? "거래처" : "공급처"}</TableHead>
                          <TableHead className="text-right">금액</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentTransactions.map((transaction) => (
                          <TableRow
                            key={transaction.id}
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleTransactionSelect(transaction)}
                          >
                            <TableCell>
                              <Badge variant={getTransactionTypeBadge(transaction.type)}>{transaction.type}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <span role="img" aria-label={transaction.category}>
                                  {getEmojiForCategoryName(transaction.category)}
                                </span>
                                <span>{transaction.category}</span>
                              </div>
                            </TableCell>
                            <TableCell>{transaction.description}</TableCell>
                            <TableCell>{transaction.customer || "-"}</TableCell>
                            <TableCell
                              className={`text-right font-medium ${
                                transaction.amount > 0 ? "text-green-600" : "text-red-600"
                              }`}
                            >
                              {transaction.amount.toLocaleString()}원
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">해당 날짜에 거래 내역이 없습니다.</div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div>
                  <span className="text-sm text-muted-foreground">총 {currentTransactions.length}건의 거래</span>
                </div>
                <div className="flex gap-4">
                  {selectedDate && (
                    <>
                      <div>
                        <span className="text-sm font-medium">수입: </span>
                        <span className="text-sm font-bold text-green-600">
                          {getTotalForDate(selectedDate, "수입").toLocaleString()}원
                        </span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">지출: </span>
                        <span className="text-sm font-bold text-red-600">
                          {Math.abs(getTotalForDate(selectedDate, "지출")).toLocaleString()}원
                        </span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">잔액: </span>
                        <span
                          className={`text-sm font-bold ${getTotalForDate(selectedDate, "all") >= 0 ? "text-blue-600" : "text-red-600"}`}
                        >
                          {getTotalForDate(selectedDate, "all").toLocaleString()}원
                        </span>
                      </div>
                    </>
                  )}
                </div>
              </CardFooter>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>{format(date, "yyyy년 MM월", { locale: ko })} 거래 목록</CardTitle>
                  <CardDescription>{filterType === "all" ? "모든 거래 내역" : `${filterType} 내역`}</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Filter className="mr-2 h-4 w-4" />
                    필터
                  </Button>
                  <Button variant="outline" size="sm">
                    <ArrowUpDown className="mr-2 h-4 w-4" />
                    정렬
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    내보내기
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>날짜</TableHead>
                      <TableHead>유형</TableHead>
                      <TableHead>카테고리</TableHead>
                      <TableHead>내용</TableHead>
                      <TableHead>거래처</TableHead>
                      <TableHead className="text-right">금액</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentTransactions.length > 0 ? (
                      currentTransactions.map((transaction) => (
                        <TableRow
                          key={transaction.id}
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => handleTransactionSelect(transaction)}
                        >
                          <TableCell>{transaction.date}</TableCell>
                          <TableCell>
                            <Badge variant={getTransactionTypeBadge(transaction.type)}>{transaction.type}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <span role="img" aria-label={transaction.category}>
                                {getEmojiForCategoryName(transaction.category)}
                              </span>
                              <span>{transaction.category}</span>
                            </div>
                          </TableCell>
                          <TableCell>{transaction.description}</TableCell>
                          <TableCell>{transaction.customer || "-"}</TableCell>
                          <TableCell
                            className={`text-right font-medium ${
                              transaction.amount > 0 ? "text-green-600" : "text-red-600"
                            }`}
                          >
                            {transaction.amount.toLocaleString()}원
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-4 text-muted-foreground">
                          해당 기간에 거래 내역이 없습니다.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div>
                <span className="text-sm text-muted-foreground">총 {currentTransactions.length}건의 거래</span>
              </div>
              <div className="flex gap-4">
                <div>
                  <span className="text-sm font-medium">수입: </span>
                  <span className="text-sm font-bold text-green-600">
                    {getTotalForMonth(date, "수입").toLocaleString()}원
                  </span>
                </div>
                <div>
                  <span className="text-sm font-medium">지출: </span>
                  <span className="text-sm font-bold text-red-600">
                    {Math.abs(getTotalForMonth(date, "지출")).toLocaleString()}원
                  </span>
                </div>
                <div>
                  <span className="text-sm font-medium">잔액: </span>
                  <span
                    className={`text-sm font-bold ${getTotalForMonth(date, "all") >= 0 ? "text-blue-600" : "text-red-600"}`}
                  >
                    {getTotalForMonth(date, "all").toLocaleString()}원
                  </span>
                </div>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 거래 상세 정보 다이얼로그 */}
      <Dialog open={openTransactionDetail} onOpenChange={setOpenTransactionDetail}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>거래 상세 정보</DialogTitle>
            <DialogDescription>
              {selectedTransaction?.date} - {selectedTransaction?.description}
            </DialogDescription>
          </DialogHeader>

          {selectedTransaction && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">유형</p>
                  <p className="font-medium">
                    <Badge variant={getTransactionTypeBadge(selectedTransaction.type)}>
                      {selectedTransaction.type}
                    </Badge>
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">날짜</p>
                  <p className="font-medium">{selectedTransaction.date}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">카테고리</p>
                  <p className="font-medium flex items-center gap-1">
                    <span role="img" aria-label={selectedTransaction.category}>
                      {getEmojiForCategoryName(selectedTransaction.category)}
                    </span>
                    {selectedTransaction.category}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {selectedTransaction.type === "매입" ? "공급처" : "거래처"}
                  </p>
                  <p className="font-medium">{selectedTransaction.customer || "-"}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">내용</p>
                <p className="font-medium">{selectedTransaction.description}</p>
              </div>

              {selectedTransaction.memo && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">메모</p>
                  <p className="font-medium">{selectedTransaction.memo}</p>
                </div>
              )}

              {selectedTransaction.paymentMethod && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">결제 수단</p>
                  <p className="font-medium">{selectedTransaction.paymentMethod}</p>
                </div>
              )}

              {selectedTransaction.recurring && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">주기</p>
                  <p className="font-medium">
                    {selectedTransaction.frequency === "monthly"
                      ? "매월"
                      : selectedTransaction.frequency === "weekly"
                        ? "매주"
                        : selectedTransaction.frequency === "yearly"
                          ? "매년"
                          : selectedTransaction.frequency}
                  </p>
                </div>
              )}

              <div className="bg-muted p-4 rounded-md">
                <div className="flex justify-between items-center">
                  <p className="text-sm font-medium">금액</p>
                  <p className={`font-bold ${selectedTransaction.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                    {selectedTransaction.amount.toLocaleString()}원
                  </p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

