"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, Plus, Edit } from "lucide-react"
import { format, addMonths, subMonths, isSameDay, parseISO } from "date-fns"
import { ko } from "date-fns/locale"

interface DiaryCalendarProps {
  selectedDate: Date
  onSelectDate: (date: Date) => void
}

// 가상의 일기 데이터 (실제 구현에서는 상태 관리 라이브러리나 API를 통해 가져올 것입니다)
const diaryEntries = [
  { id: 1, date: "2024-04-15", title: "새로운 프로젝트 시작", mood: "happy" },
  { id: 2, date: "2024-04-14", title: "주말 여행", mood: "happy" },
  { id: 3, date: "2024-04-10", title: "힘든 하루", mood: "bad" },
  { id: 4, date: "2024-04-05", title: "새로운 취미 시작", mood: "good" },
  { id: 5, date: "2024-04-20", title: "친구와의 만남", mood: "happy" },
]

export default function DiaryCalendar({ selectedDate, onSelectDate }: DiaryCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date())
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedDayEntries, setSelectedDayEntries] = useState<any[]>([])

  // 선택한 날짜의 일기 항목 가져오기
  useEffect(() => {
    const entries = diaryEntries.filter((entry) => isSameDay(parseISO(entry.date), selectedDate))
    setSelectedDayEntries(entries)
  }, [selectedDate])

  // 이전 달로 이동
  const goToPreviousMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1))
  }

  // 다음 달로 이동
  const goToNextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1))
  }

  // 날짜에 일기가 있는지 확인
  const hasDiaryEntry = (date: Date) => {
    return diaryEntries.some((entry) => isSameDay(parseISO(entry.date), date))
  }

  // 날짜의 감정 가져오기
  const getMoodForDate = (date: Date) => {
    const entry = diaryEntries.find((entry) => isSameDay(parseISO(entry.date), date))
    return entry?.mood || null
  }

  // 감정에 따른 이모티콘 가져오기
  const getMoodEmoji = (mood: string | null) => {
    switch (mood) {
      case "happy":
        return "😄"
      case "good":
        return "🙂"
      case "neutral":
        return "😐"
      case "bad":
        return "😕"
      case "sad":
        return "😢"
      default:
        return null
    }
  }

  // 날짜 선택 처리
  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      onSelectDate(date)
    }
  }

  // 새 일기 작성 다이얼로그 열기
  const openCreateDialog = () => {
    setIsCreateDialogOpen(true)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">일기장 캘린더</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={() => setCurrentMonth(new Date())}>
            오늘
          </Button>
          <Button variant="outline" size="icon" onClick={goToNextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>{format(currentMonth, "yyyy년 MM월", { locale: ko })}</CardTitle>
            <CardDescription>일기를 작성한 날짜에는 표시가 나타납니다</CardDescription>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={handleDateSelect}
              month={currentMonth}
              onMonthChange={setCurrentMonth}
              locale={ko}
              className="rounded-md border"
              modifiers={{
                hasDiary: (date) => hasDiaryEntry(date),
              }}
              modifiersStyles={{
                hasDiary: {
                  fontWeight: "bold",
                  border: "2px solid var(--primary)",
                },
              }}
              components={{
                DayContent: ({ date }) => {
                  const mood = getMoodForDate(date)
                  const moodEmoji = getMoodEmoji(mood)

                  return (
                    <div className="relative w-full h-full flex items-center justify-center">
                      {date.getDate()}
                      {moodEmoji && <span className="absolute -bottom-1 text-xs">{moodEmoji}</span>}
                    </div>
                  )
                },
              }}
            />
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={openCreateDialog}>
              <Plus className="mr-2 h-4 w-4" />새 일기 작성하기
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{format(selectedDate, "yyyy년 MM월 dd일", { locale: ko })}</CardTitle>
            <CardDescription>선택한 날짜의 일기</CardDescription>
          </CardHeader>
          <CardContent>
            {selectedDayEntries.length > 0 ? (
              <div className="space-y-4">
                {selectedDayEntries.map((entry) => (
                  <div key={entry.id} className="p-3 border rounded-md">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium">{entry.title}</h3>
                      <span>{getMoodEmoji(entry.mood)}</span>
                    </div>
                    <Button variant="outline" size="sm" className="w-full mt-2">
                      <Edit className="mr-2 h-3 w-3" />
                      일기 보기
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">이 날짜에 작성된 일기가 없습니다</div>
            )}
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={openCreateDialog}>
              <Plus className="mr-2 h-4 w-4" />새 일기 작성하기
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>새 일기 작성</DialogTitle>
            <DialogDescription>
              {format(selectedDate, "yyyy년 MM월 dd일", { locale: ko })}에 새 일기를 작성합니다
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p>일기 작성 페이지로 이동하시겠습니까?</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              취소
            </Button>
            <Button
              onClick={() => {
                setIsCreateDialogOpen(false)
                // 여기서 일기 작성 탭으로 이동하는 로직을 추가할 수 있습니다
                // 예: router.push('/diary/write') 또는 상태 변경을 통한 탭 전환
                document
                  .querySelector('[data-value="diary"]')
                  ?.dispatchEvent(new MouseEvent("click", { bubbles: true }))
              }}
            >
              일기 작성하기
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

