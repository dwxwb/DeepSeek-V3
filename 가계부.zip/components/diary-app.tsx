"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { ko } from "date-fns/locale"
import Diary from "./diary"
import DiaryTemplates from "./diary-templates"
import { Card, CardContent } from "@/components/ui/card"

export default function DiaryApp() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [activeTab, setActiveTab] = useState("write")
  const [selectedTemplate, setSelectedTemplate] = useState("default")
  const [textColor, setTextColor] = useState("#000000")
  const [bgColor, setBgColor] = useState("#ffffff")

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="write">일기 작성</TabsTrigger>
          <TabsTrigger value="templates">템플릿 선택</TabsTrigger>
        </TabsList>

        <TabsContent value="write" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-1">
              <Card>
                <CardContent className="p-4">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    locale={ko}
                    className="rounded-md border"
                  />
                </CardContent>
              </Card>
            </div>
            <div className="md:col-span-3">
              <Diary selectedDate={selectedDate} template={selectedTemplate} textColor={textColor} bgColor={bgColor} />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="mt-4">
          <DiaryTemplates selectedTemplate={selectedTemplate} onSelectTemplate={setSelectedTemplate} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

