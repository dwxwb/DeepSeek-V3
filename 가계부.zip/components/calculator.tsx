"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Copy, ArrowLeft, Percent, Divide, X, Minus, Plus, Equal } from "lucide-react"

export default function Calculator({ onClose }: { onClose?: () => void }) {
  const [display, setDisplay] = useState("0")
  const [memory, setMemory] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [history, setHistory] = useState<string[]>([])
  const [taxRate, setTaxRate] = useState(10) // 기본 세율 10%
  const [amount, setAmount] = useState(0)
  const [activeTab, setActiveTab] = useState("standard")

  // 숫자 버튼 클릭 처리
  const handleDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === "0" ? digit : display + digit)
    }
  }

  // 소수점 버튼 클릭 처리
  const handleDecimal = () => {
    if (waitingForOperand) {
      setDisplay("0.")
      setWaitingForOperand(false)
    } else if (display.indexOf(".") === -1) {
      setDisplay(display + ".")
    }
  }

  // 연산자 버튼 클릭 처리
  const handleOperator = (nextOperator: string) => {
    const inputValue = Number.parseFloat(display)

    if (memory === null) {
      setMemory(inputValue)
    } else if (operation) {
      const result = performCalculation(memory, inputValue, operation)
      setMemory(result)
      setDisplay(String(result))
      setHistory([...history, `${memory} ${operation} ${inputValue} = ${result}`])
    }

    setWaitingForOperand(true)
    setOperation(nextOperator)
  }

  // 계산 수행
  const performCalculation = (firstOperand: number, secondOperand: number, operator: string) => {
    switch (operator) {
      case "+":
        return firstOperand + secondOperand
      case "-":
        return firstOperand - secondOperand
      case "×":
        return firstOperand * secondOperand
      case "÷":
        return firstOperand / secondOperand
      case "%":
        return firstOperand % secondOperand
      default:
        return secondOperand
    }
  }

  // 등호 버튼 클릭 처리
  const handleEquals = () => {
    if (memory === null || operation === null) {
      return
    }

    const inputValue = Number.parseFloat(display)
    const result = performCalculation(memory, inputValue, operation)
    const calculation = `${memory} ${operation} ${inputValue} = ${result}`

    setDisplay(String(result))
    setHistory([...history, calculation])
    setMemory(null)
    setOperation(null)
    setWaitingForOperand(true)
  }

  // 초기화 버튼 클릭 처리
  const handleClear = () => {
    setDisplay("0")
    setMemory(null)
    setOperation(null)
    setWaitingForOperand(false)
  }

  // 백스페이스 버튼 클릭 처리
  const handleBackspace = () => {
    if (waitingForOperand) return

    setDisplay(display.length === 1 ? "0" : display.slice(0, -1))
  }

  // 부호 변경 버튼 클릭 처리
  const handleToggleSign = () => {
    const value = Number.parseFloat(display)
    setDisplay(String(-value))
  }

  // 세금 계산
  const calculateTax = () => {
    const tax = (amount * taxRate) / 100
    const total = amount + tax
    setHistory([
      ...history,
      `금액: ${amount.toLocaleString()}원, 세율: ${taxRate}%`,
      `부가세: ${tax.toLocaleString()}원, 합계: ${total.toLocaleString()}원`,
    ])
  }

  // 결과 복사
  const copyToClipboard = (text: string = display) => {
    navigator.clipboard.writeText(text)
  }

  // 키보드 이벤트 처리
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 계산기가 열려있을 때만 키보드 이벤트 처리
      if (e.key >= "0" && e.key <= "9") {
        handleDigit(e.key)
      } else if (e.key === ".") {
        handleDecimal()
      } else if (e.key === "+" || e.key === "-") {
        handleOperator(e.key)
      } else if (e.key === "*") {
        handleOperator("×")
      } else if (e.key === "/") {
        handleOperator("÷")
      } else if (e.key === "Enter" || e.key === "=") {
        handleEquals()
      } else if (e.key === "Escape") {
        handleClear()
      } else if (e.key === "Backspace") {
        handleBackspace()
      } else if (e.key === "%") {
        handleOperator("%")
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [display, memory, operation, waitingForOperand])

  // 계산기가 열렸을 때 자동으로 포커스를 주기 위한 ref 추가
  const calculatorRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // 컴포넌트가 마운트되면 포커스
    if (calculatorRef.current) {
      calculatorRef.current.focus()
    }
  }, [])

  // 카드 컴포넌트에 ref와 tabIndex 추가
  return (
    <Card className="w-full max-w-md mx-auto" ref={calculatorRef} tabIndex={0}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">계산기</CardTitle>
        {onClose && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            ✕
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="standard">기본</TabsTrigger>
            <TabsTrigger value="tax">세금 계산</TabsTrigger>
          </TabsList>

          <TabsContent value="standard" className="space-y-4">
            <div className="flex flex-col gap-2">
              <div className="bg-muted p-4 rounded-md text-right text-2xl font-mono h-16 flex items-center justify-end overflow-hidden">
                {display}
              </div>

              <div className="grid grid-cols-4 gap-2">
                <Button variant="outline" onClick={handleClear}>
                  C
                </Button>
                <Button variant="outline" onClick={handleToggleSign}>
                  +/-
                </Button>
                <Button variant="outline" onClick={() => handleOperator("%")}>
                  <Percent className="h-4 w-4" />
                </Button>
                <Button variant="outline" onClick={() => handleOperator("÷")}>
                  <Divide className="h-4 w-4" />
                </Button>

                <Button variant="outline" onClick={() => handleDigit("7")}>
                  7
                </Button>
                <Button variant="outline" onClick={() => handleDigit("8")}>
                  8
                </Button>
                <Button variant="outline" onClick={() => handleDigit("9")}>
                  9
                </Button>
                <Button variant="outline" onClick={() => handleOperator("×")}>
                  <X className="h-4 w-4" />
                </Button>

                <Button variant="outline" onClick={() => handleDigit("4")}>
                  4
                </Button>
                <Button variant="outline" onClick={() => handleDigit("5")}>
                  5
                </Button>
                <Button variant="outline" onClick={() => handleDigit("6")}>
                  6
                </Button>
                <Button variant="outline" onClick={() => handleOperator("-")}>
                  <Minus className="h-4 w-4" />
                </Button>

                <Button variant="outline" onClick={() => handleDigit("1")}>
                  1
                </Button>
                <Button variant="outline" onClick={() => handleDigit("2")}>
                  2
                </Button>
                <Button variant="outline" onClick={() => handleDigit("3")}>
                  3
                </Button>
                <Button variant="outline" onClick={() => handleOperator("+")}>
                  <Plus className="h-4 w-4" />
                </Button>

                <Button variant="outline" onClick={() => handleDigit("0")}>
                  0
                </Button>
                <Button variant="outline" onClick={handleDecimal}>
                  .
                </Button>
                <Button variant="outline" onClick={handleBackspace}>
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <Button variant="default" onClick={handleEquals}>
                  <Equal className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {history.length > 0 && (
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium">계산 기록</h3>
                  <Button variant="ghost" size="sm" onClick={() => setHistory([])}>
                    지우기
                  </Button>
                </div>
                <div className="bg-muted p-2 rounded-md text-sm font-mono max-h-32 overflow-y-auto">
                  {history.map((item, index) => (
                    <div key={index} className="flex justify-between items-center py-1">
                      <span>{item}</span>
                      <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => copyToClipboard(item)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="tax" className="space-y-4">
            <div className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="amount">금액</Label>
                <Input
                  id="amount"
                  type="number"
                  value={amount || ""}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  placeholder="금액 입력"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="tax-rate">세율 (%)</Label>
                <Input
                  id="tax-rate"
                  type="number"
                  value={taxRate}
                  onChange={(e) => setTaxRate(Number(e.target.value))}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>부가세</Label>
                  <div className="bg-muted p-2 rounded-md mt-1 text-right">
                    {((amount * taxRate) / 100).toLocaleString()}원
                  </div>
                </div>
                <div>
                  <Label>합계</Label>
                  <div className="bg-muted p-2 rounded-md mt-1 text-right font-medium">
                    {(amount + (amount * taxRate) / 100).toLocaleString()}원
                  </div>
                </div>
              </div>

              <Button className="w-full" onClick={calculateTax}>
                계산하기
              </Button>
            </div>

            {history.length > 0 && (
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium">계산 기록</h3>
                  <Button variant="ghost" size="sm" onClick={() => setHistory([])}>
                    지우기
                  </Button>
                </div>
                <div className="bg-muted p-2 rounded-md text-sm font-mono max-h-32 overflow-y-auto">
                  {history.map((item, index) => (
                    <div key={index} className="flex justify-between items-center py-1">
                      <span>{item}</span>
                      <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => copyToClipboard(item)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="ghost" size="sm" onClick={() => copyToClipboard()}>
          <Copy className="mr-2 h-4 w-4" />
          결과 복사
        </Button>
      </CardFooter>
    </Card>
  )
}

