"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Plus,
  Edit,
  Trash2,
  BarChart4,
  ArrowUpDown,
  Tag,
  QrCode,
  FileUp,
  Download,
  MoreHorizontal,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// 가상의 품목 데이터
const initialItems = [
  {
    id: 1,
    code: "A001",
    name: "A4 용지",
    category: "소모품",
    unit: "박스",
    unitPrice: 5000,
    purchasePrice: 4000,
    sellingPrice: 5000,
    stock: 15,
    minStock: 5,
    description: "A4 용지 500매",
    barcode: "8801234567890",
    status: "활성",
    tags: ["사무용품", "소모품"],
  },
  {
    id: 2,
    code: "A002",
    name: "볼펜",
    category: "소모품",
    unit: "개",
    unitPrice: 1000,
    purchasePrice: 800,
    sellingPrice: 1000,
    stock: 100,
    minStock: 20,
    description: "검정색 볼펜",
    barcode: "8801234567891",
    status: "활성",
    tags: ["사무용품", "소모품"],
  },
  {
    id: 3,
    code: "A003",
    name: "포스트잇",
    category: "소모품",
    unit: "팩",
    unitPrice: 1000,
    purchasePrice: 800,
    sellingPrice: 1000,
    stock: 30,
    minStock: 10,
    description: "컬러 포스트잇",
    barcode: "8801234567892",
    status: "활성",
    tags: ["사무용품", "소모품"],
  },
  {
    id: 4,
    code: "B001",
    name: "갤럭시북",
    category: "전자기기",
    unit: "대",
    unitPrice: 500000,
    purchasePrice: 450000,
    sellingPrice: 500000,
    stock: 5,
    minStock: 2,
    description: "삼성 노트북",
    barcode: "8801234567893",
    status: "활성",
    tags: ["전자기기", "자산"],
  },
  {
    id: 5,
    code: "C001",
    name: "커피",
    category: "복리후생",
    unit: "박스",
    unitPrice: 10000,
    purchasePrice: 8000,
    sellingPrice: 10000,
    stock: 8,
    minStock: 3,
    description: "원두커피",
    barcode: "8801234567894",
    status: "활성",
    tags: ["간식", "복리후생"],
  },
  {
    id: 6,
    code: "C002",
    name: "과자세트",
    category: "복리후생",
    unit: "박스",
    unitPrice: 7000,
    purchasePrice: 5500,
    sellingPrice: 7000,
    stock: 10,
    minStock: 3,
    description: "과자 모음",
    barcode: "8801234567895",
    status: "활성",
    tags: ["간식", "복리후생"],
  },
  {
    id: 7,
    code: "D001",
    name: "모니터",
    category: "전자기기",
    unit: "대",
    unitPrice: 300000,
    purchasePrice: 250000,
    sellingPrice: 300000,
    stock: 3,
    minStock: 1,
    description: "27인치 모니터",
    barcode: "8801234567896",
    status: "활성",
    tags: ["전자기기", "자산"],
  },
  {
    id: 8,
    code: "D002",
    name: "키보드",
    category: "전자기기",
    unit: "개",
    unitPrice: 50000,
    purchasePrice: 40000,
    sellingPrice: 50000,
    stock: 5,
    minStock: 2,
    description: "기계식 키보드",
    barcode: "8801234567897",
    status: "활성",
    tags: ["전자기기", "자산"],
  },
]

// 가상의 재고 이력 데이터
const stockHistoryData = [
  {
    id: 1,
    date: "2023-12-15",
    itemCode: "A001",
    itemName: "A4 용지",
    type: "입고",
    quantity: 10,
    beforeStock: 5,
    afterStock: 15,
    memo: "정기 발주",
  },
  {
    id: 2,
    date: "2023-12-10",
    itemCode: "B001",
    itemName: "갤럭시북",
    type: "입고",
    quantity: 3,
    beforeStock: 2,
    afterStock: 5,
    memo: "개발팀 노트북 구매",
  },
  {
    id: 3,
    date: "2023-12-05",
    itemCode: "C001",
    itemName: "커피",
    type: "입고",
    quantity: 5,
    beforeStock: 3,
    afterStock: 8,
    memo: "12월 간식 구매",
  },
  {
    id: 4,
    date: "2023-12-01",
    itemCode: "A002",
    itemName: "볼펜",
    type: "출고",
    quantity: 20,
    beforeStock: 120,
    afterStock: 100,
    memo: "사무용품 사용",
  },
  {
    id: 5,
    date: "2023-11-25",
    itemCode: "A003",
    itemName: "포스트잇",
    type: "출고",
    quantity: 5,
    beforeStock: 35,
    afterStock: 30,
    memo: "사무용품 사용",
  },
]

export default function ItemManagement() {
  const [items, setItems] = useState(initialItems)
  const [stockHistory, setStockHistory] = useState(stockHistoryData)
  const [activeTab, setActiveTab] = useState("items")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCategory, setFilterCategory] = useState("")
  const [filterStatus, setFilterStatus] = useState("")
  const [openNewItem, setOpenNewItem] = useState(false)
  const [openStockAdjust, setOpenStockAdjust] = useState(false)
  const [selectedItem, setSelectedItem] = useState<any>(null)

  // 필터링된 품목 데이터 가져오기
  const getFilteredItems = () => {
    return items.filter((item) => {
      // 검색어 필터링
      const matchesSearch =
        searchTerm === "" ||
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

      // 카테고리 필터링
      const matchesCategory = filterCategory === "" || item.category === filterCategory

      // 상태 필터링
      const matchesStatus = filterStatus === "" || item.status === filterStatus

      return matchesSearch && matchesCategory && matchesStatus
    })
  }

  // 재고 부족 품목 가져오기
  const getLowStockItems = () => {
    return items.filter((item) => item.stock <= item.minStock)
  }

  // 품목 추가 처리
  const handleAddItem = (newItem: any) => {
    setItems([...items, { ...newItem, id: items.length + 1 }])
    setOpenNewItem(false)
  }

  // 품목 수정 처리
  const handleEditItem = (updatedItem: any) => {
    setItems(items.map((item) => (item.id === updatedItem.id ? updatedItem : item)))
    setSelectedItem(null)
  }

  // 품목 삭제 처리
  const handleDeleteItem = (id: number) => {
    setItems(items.filter((item) => item.id !== id))
  }

  // 재고 조정 처리
  const handleStockAdjust = (itemId: number, quantity: number, type: string, memo: string) => {
    const item = items.find((i) => i.id === itemId)
    if (!item) return

    const beforeStock = item.stock
    const afterStock = type === "입고" ? beforeStock + quantity : beforeStock - quantity

    // 품목 재고 업데이트
    setItems(items.map((i) => (i.id === itemId ? { ...i, stock: afterStock } : i)))

    // 재고 이력 추가
    const newHistory = {
      id: stockHistory.length + 1,
      date: new Date().toISOString().split("T")[0],
      itemCode: item.code,
      itemName: item.name,
      type,
      quantity,
      beforeStock,
      afterStock,
      memo,
    }

    setStockHistory([newHistory, ...stockHistory])
    setOpenStockAdjust(false)
  }

  // 엑셀 내보내기
  const exportToExcel = () => {
    alert("엑셀 내보내기 기능은 준비 중입니다.")
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">품목 관리</h2>
        <div className="flex gap-2">
          <Button onClick={() => setOpenNewItem(true)}>
            <Plus className="mr-2 h-4 w-4" />새 품목 추가
          </Button>
          <Button variant="outline" onClick={() => setOpenStockAdjust(true)}>
            <ArrowUpDown className="mr-2 h-4 w-4" />
            재고 조정
          </Button>
          <Button variant="outline">
            <FileUp className="mr-2 h-4 w-4" />
            가져오기
          </Button>
          <Button variant="outline" onClick={exportToExcel}>
            <Download className="mr-2 h-4 w-4" />
            내보내기
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="items">품목 목록</TabsTrigger>
          <TabsTrigger value="stock">재고 현황</TabsTrigger>
          <TabsTrigger value="history">재고 이력</TabsTrigger>
        </TabsList>

        <TabsContent value="items">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>품목 목록</CardTitle>
                  <CardDescription>모든 품목을 관리하세요</CardDescription>
                </div>
                <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="검색..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="카테고리 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">전체 카테고리</SelectItem>
                      <SelectItem value="소모품">소모품</SelectItem>
                      <SelectItem value="전자기기">전자기기</SelectItem>
                      <SelectItem value="복리후생">복리후생</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="상태 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">전체 상태</SelectItem>
                      <SelectItem value="활성">활성</SelectItem>
                      <SelectItem value="비활성">비활성</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>코드</TableHead>
                      <TableHead>품목명</TableHead>
                      <TableHead>카테고리</TableHead>
                      <TableHead>단위</TableHead>
                      <TableHead className="text-right">매입가</TableHead>
                      <TableHead className="text-right">판매가</TableHead>
                      <TableHead className="text-right">재고</TableHead>
                      <TableHead>태그</TableHead>
                      <TableHead>상태</TableHead>
                      <TableHead className="w-[80px]">액션</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getFilteredItems().map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.code}</TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>{item.unit}</TableCell>
                        <TableCell className="text-right">{item.purchasePrice.toLocaleString()}원</TableCell>
                        <TableCell className="text-right">{item.sellingPrice.toLocaleString()}원</TableCell>
                        <TableCell
                          className={`text-right ${item.stock <= item.minStock ? "text-red-500 font-bold" : ""}`}
                        >
                          {item.stock.toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {item.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={item.status === "활성" ? "default" : "secondary"} className="text-xs">
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setSelectedItem(item)}>
                                <Edit className="mr-2 h-4 w-4" />
                                수정
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <ArrowUpDown className="mr-2 h-4 w-4" />
                                재고 조정
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <QrCode className="mr-2 h-4 w-4" />
                                바코드 출력
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteItem(item.id)}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                삭제
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                    {getFilteredItems().length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center py-4 text-muted-foreground">
                          검색 결과가 없습니다
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">총 {getFilteredItems().length}개 품목</div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Tag className="mr-2 h-4 w-4" />
                  라벨 출력
                </Button>
                <Button variant="outline" size="sm">
                  <BarChart4 className="mr-2 h-4 w-4" />
                  분석
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="stock">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>재고 현황</CardTitle>
                  <CardDescription>품목별 재고 현황을 확인하세요</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setOpenStockAdjust(true)}>
                    <ArrowUpDown className="mr-2 h-4 w-4" />
                    재고 조정
                  </Button>
                  <Button variant="outline" onClick={exportToExcel}>
                    <Download className="mr-2 h-4 w-4" />
                    내보내기
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>코드</TableHead>
                      <TableHead>품목명</TableHead>
                      <TableHead>카테고리</TableHead>
                      <TableHead>단위</TableHead>
                      <TableHead className="text-right">현재 재고</TableHead>
                      <TableHead className="text-right">최소 재고</TableHead>
                      <TableHead className="text-right">재고 가치</TableHead>
                      <TableHead>상태</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id} className={item.stock <= item.minStock ? "bg-red-50" : ""}>
                        <TableCell>{item.code}</TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>{item.unit}</TableCell>
                        <TableCell
                          className={`text-right ${item.stock <= item.minStock ? "text-red-500 font-bold" : ""}`}
                        >
                          {item.stock.toLocaleString()}
                        </TableCell>
                        <TableCell className="text-right">{item.minStock.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          {(item.stock * item.purchasePrice).toLocaleString()}원
                        </TableCell>
                        <TableCell>
                          <Badge variant={item.stock > item.minStock ? "default" : "destructive"} className="text-xs">
                            {item.stock > item.minStock ? "정상" : "재고 부족"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">
                총 {items.length}개 품목 / 재고 부족: {getLowStockItems().length}개
              </div>
              <div>
                <span className="font-medium">총 재고 가치: </span>
                <span className="font-bold">
                  {items.reduce((sum, item) => sum + item.stock * item.purchasePrice, 0).toLocaleString()}원
                </span>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>재고 이력</CardTitle>
                  <CardDescription>재고 변동 이력을 확인하세요</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={exportToExcel}>
                    <Download className="mr-2 h-4 w-4" />
                    내보내기
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>날짜</TableHead>
                      <TableHead>품목 코드</TableHead>
                      <TableHead>품목명</TableHead>
                      <TableHead>유형</TableHead>
                      <TableHead className="text-right">수량</TableHead>
                      <TableHead className="text-right">이전 재고</TableHead>
                      <TableHead className="text-right">이후 재고</TableHead>
                      <TableHead>메모</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stockHistory.map((history) => (
                      <TableRow key={history.id}>
                        <TableCell>{history.date}</TableCell>
                        <TableCell>{history.itemCode}</TableCell>
                        <TableCell>{history.itemName}</TableCell>
                        <TableCell>
                          <Badge variant={history.type === "입고" ? "default" : "secondary"} className="text-xs">
                            {history.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">{history.quantity.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{history.beforeStock.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{history.afterStock.toLocaleString()}</TableCell>
                        <TableCell>{history.memo}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter>
              <div className="text-sm text-muted-foreground">총 {stockHistory.length}개 이력</div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 새 품목 추가 다이얼로그 */}
      <Dialog open={openNewItem} onOpenChange={setOpenNewItem}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>새 품목 추가</DialogTitle>
            <DialogDescription>새로운 품목 정보를 입력하세요</DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="code">품목 코드</Label>
              <Input id="code" placeholder="품목 코드 입력" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="name">품목명</Label>
              <Input id="name" placeholder="품목명 입력" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category">카테고리</Label>
              <Select defaultValue="소모품">
                <SelectTrigger id="category">
                  <SelectValue placeholder="카테고리 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="소모품">소모품</SelectItem>
                  <SelectItem value="전자기기">전자기기</SelectItem>
                  <SelectItem value="복리후생">복리후생</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="unit">단위</Label>
              <Input id="unit" placeholder="단위 입력 (예: 개, 박스)" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="purchasePrice">매입가</Label>
              <Input id="purchasePrice" type="number" placeholder="매입가 입력" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="sellingPrice">판매가</Label>
              <Input id="sellingPrice" type="number" placeholder="판매가 입력" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="stock">초기 재고</Label>
              <Input id="stock" type="number" placeholder="초기 재고 입력" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="minStock">최소 재고</Label>
              <Input id="minStock" type="number" placeholder="최소 재고 입력" />
            </div>
            <div className="grid gap-2 md:col-span-2">
              <Label htmlFor="description">설명</Label>
              <Input id="description" placeholder="품목 설명 입력" />
            </div>
            <div className="grid gap-2 md:col-span-2">
              <Label htmlFor="tags">태그 (쉼표로 구분)</Label>
              <Input id="tags" placeholder="태그 입력 (예: 사무용품, 소모품)" />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenNewItem(false)}>
              취소
            </Button>
            <Button>저장</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 재고 조정 다이얼로그 */}
      <Dialog open={openStockAdjust} onOpenChange={setOpenStockAdjust}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>재고 조정</DialogTitle>
            <DialogDescription>품목의 재고를 조정하세요</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="item">품목 선택</Label>
              <Select>
                <SelectTrigger id="item">
                  <SelectValue placeholder="품목 선택" />
                </SelectTrigger>
                <SelectContent>
                  {items.map((item) => (
                    <SelectItem key={item.id} value={item.id.toString()}>
                      {item.code} - {item.name} (현재 재고: {item.stock})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type">조정 유형</Label>
              <Select defaultValue="입고">
                <SelectTrigger id="type">
                  <SelectValue placeholder="유형 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="입고">입고</SelectItem>
                  <SelectItem value="출고">출고</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="quantity">수량</Label>
              <Input id="quantity" type="number" placeholder="수량 입력" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="memo">메모</Label>
              <Input id="memo" placeholder="메모 입력" />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenStockAdjust(false)}>
              취소
            </Button>
            <Button>저장</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 품목 수정 다이얼로그 */}
      <Dialog open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>품목 수정</DialogTitle>
            <DialogDescription>
              {selectedItem?.code} - {selectedItem?.name}
            </DialogDescription>
          </DialogHeader>

          {selectedItem && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-code">품목 코드</Label>
                <Input id="edit-code" defaultValue={selectedItem.code} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-name">품목명</Label>
                <Input id="edit-name" defaultValue={selectedItem.name} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-category">카테고리</Label>
                <Select defaultValue={selectedItem.category}>
                  <SelectTrigger id="edit-category">
                    <SelectValue placeholder="카테고리 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="소모품">소모품</SelectItem>
                    <SelectItem value="전자기기">전자기기</SelectItem>
                    <SelectItem value="복리후생">복리후생</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-unit">단위</Label>
                <Input id="edit-unit" defaultValue={selectedItem.unit} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-purchasePrice">매입가</Label>
                <Input id="edit-purchasePrice" type="number" defaultValue={selectedItem.purchasePrice} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-sellingPrice">판매가</Label>
                <Input id="edit-sellingPrice" type="number" defaultValue={selectedItem.sellingPrice} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-stock">재고</Label>
                <Input id="edit-stock" type="number" defaultValue={selectedItem.stock} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-minStock">최소 재고</Label>
                <Input id="edit-minStock" type="number" defaultValue={selectedItem.minStock} />
              </div>
              <div className="grid gap-2 md:col-span-2">
                <Label htmlFor="edit-description">설명</Label>
                <Input id="edit-description" defaultValue={selectedItem.description} />
              </div>
              <div className="grid gap-2 md:col-span-2">
                <Label htmlFor="edit-tags">태그 (쉼표로 구분)</Label>
                <Input id="edit-tags" defaultValue={selectedItem.tags.join(", ")} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status">상태</Label>
                <Select defaultValue={selectedItem.status}>
                  <SelectTrigger id="edit-status">
                    <SelectValue placeholder="상태 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="활성">활성</SelectItem>
                    <SelectItem value="비활성">비활성</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedItem(null)}>
              취소
            </Button>
            <Button>저장</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

