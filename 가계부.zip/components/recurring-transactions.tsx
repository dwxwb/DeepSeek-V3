"use client"

import { TabsContent } from "@/components/ui/tabs"

import { TabsTrigger } from "@/components/ui/tabs"

import { TabsList } from "@/components/ui/tabs"

import { Tabs } from "@/components/ui/tabs"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Plus, Edit, Trash2, MoreHorizontal, RefreshCw, AlertCircle } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { format } from "date-fns"
import { ko } from "date-fns/locale"
import type { Category } from "@/lib/category-data"

// 가상의 정기 거래 데이터
const initialRecurringTransactions = [
  {
    id: 1,
    title: "사무실 임대료",
    type: "지출",
    amount: 2000000,
    category: "임대료",
    categoryEmoji: "🏠",
    frequency: "monthly",
    startDate: "2023-01-01",
    nextDate: "2024-04-01",
    description: "매월 1일 자동 이체",
    active: true,
  },
  {
    id: 2,
    title: "인터넷 요금",
    type: "지출",
    amount: 55000,
    category: "통신",
    categoryEmoji: "📱",
    frequency: "monthly",
    startDate: "2023-01-15",
    nextDate: "2024-04-15",
    description: "매월 15일 자동 이체",
    active: true,
  },
  {
    id: 3,
    title: "전기세",
    type: "지출",
    amount: 350000,
    category: "공과금",
    categoryEmoji: "💡",
    frequency: "monthly",
    startDate: "2023-01-25",
    nextDate: "2024-04-25",
    description: "매월 25일 자동 이체",
    active: true,
  },
  {
    id: 4,
    title: "직원 급여",
    type: "지출",
    amount: 15000000,
    category: "월급",
    categoryEmoji: "💰",
    frequency: "monthly",
    startDate: "2023-01-30",
    nextDate: "2024-04-30",
    description: "매월 말일 자동 이체",
    active: true,
  },
  {
    id: 5,
    title: "유지보수 계약 - A기업",
    type: "수입",
    amount: 1200000,
    category: "급여",
    categoryEmoji: "💰",
    frequency: "monthly",
    startDate: "2023-01-05",
    nextDate: "2024-04-05",
    description: "매월 5일 입금",
    active: true,
  },
  {
    id: 6,
    title: "유지보수 계약 - B기업",
    type: "수입",
    amount: 800000,
    category: "급여",
    categoryEmoji: "💰",
    frequency: "monthly",
    startDate: "2023-01-10",
    nextDate: "2024-04-10",
    description: "매월 10일 입금",
    active: true,
  },
  {
    id: 7,
    title: "보험료",
    type: "지출",
    amount: 120000,
    category: "보험",
    categoryEmoji: "🛡️",
    frequency: "quarterly",
    startDate: "2023-01-15",
    nextDate: "2024-04-15",
    description: "분기별 납부",
    active: true,
  },
  {
    id: 8,
    title: "세금",
    type: "지출",
    amount: 5000000,
    category: "세금",
    categoryEmoji: "📝",
    frequency: "yearly",
    startDate: "2023-03-15",
    nextDate: "2024-03-15",
    description: "연간 법인세",
    active: true,
  },
  {
    id: 9,
    title: "도메인 갱신",
    type: "지출",
    amount: 50000,
    category: "IT비용",
    categoryEmoji: "🖥️",
    frequency: "yearly",
    startDate: "2023-06-01",
    nextDate: "2024-06-01",
    description: "연간 도메인 갱신",
    active: true,
  },
  {
    id: 10,
    title: "서버 호스팅",
    type: "지출",
    amount: 150000,
    category: "IT비용",
    categoryEmoji: "🖥️",
    frequency: "monthly",
    startDate: "2023-01-20",
    nextDate: "2024-04-20",
    description: "매월 20일 자동 결제",
    active: false,
  },
]

// 정기 거래 카테고리 (지출)
const expenseCategories = [
  { id: "rent", name: "임대료", emoji: "🏠" },
  { id: "utility", name: "공과금", emoji: "💡" },
  { id: "communication", name: "통신", emoji: "📱" },
  { id: "insurance", name: "보험", emoji: "🛡️" },
  { id: "tax", name: "세금", emoji: "📝" },
  { id: "accounting", name: "회계", emoji: "📊" },
  { id: "salary", name: "월급", emoji: "💰" },
  { id: "food", name: "식비", emoji: "🍽️" },
  { id: "it", name: "IT비용", emoji: "🖥️" },
  { id: "subscription", name: "구독", emoji: "📺" },
  { id: "maintenance", name: "유지보수", emoji: "🔧" },
]

// 정기 거래 카테고리 (수입)
const incomeCategories = [
  { id: "salary", name: "급여", emoji: "💰" },
  { id: "bonus", name: "보너스", emoji: "🎉" },
  { id: "interest", name: "이자", emoji: "💹" },
  { id: "investment", name: "투자", emoji: "📈" },
  { id: "side-job", name: "부업", emoji: "🛠️" },
  { id: "daily-wage", name: "일당", emoji: "💵" },
  { id: "gift", name: "선물", emoji: "🎁" },
  { id: "maintenance", name: "유지보수", emoji: "🔧" },
  { id: "rent", name: "임대수입", emoji: "🏠" },
]

export default function RecurringTransactions() {
  const [recurringTransactions, setRecurringTransactions] = useState(initialRecurringTransactions)
  const [openNewTransaction, setOpenNewTransaction] = useState(false)
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<any | null>(null)
  const [date, setDate] = useState<Date>()
  const [filterType, setFilterType] = useState<"all" | "수입" | "지출">("all")
  const [filterFrequency, setFilterFrequency] = useState<"all" | "monthly" | "quarterly" | "yearly">("all")
  const [filterActive, setFilterActive] = useState<"all" | "active" | "inactive">("all")
  const [transactionType, setTransactionType] = useState<"수입" | "지출">("지출")
  const [title, setTitle] = useState("")
  const [amount, setAmount] = useState(0)
  const [frequency, setFrequency] = useState("monthly")
  const [description, setDescription] = useState("")
  const [active, setActive] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null)
  const [editingItemId, setEditingItemId] = useState<number | null>(null)

  // 필터링된 정기 거래 데이터 가져오기
  const getFilteredTransactions = () => {
    return recurringTransactions.filter((transaction) => {
      // 유형 필터링
      const matchesType = filterType === "all" || transaction.type === filterType

      // 주기 필터링
      const matchesFrequency = filterFrequency === "all" || transaction.frequency === filterFrequency

      // 활성 상태 필터링
      const matchesActive =
        filterActive === "all" ||
        (filterActive === "active" && transaction.active) ||
        (filterActive === "inactive" && !transaction.active)

      return matchesType && matchesFrequency && matchesActive
    })
  }

  // 카테고리 선택 처리
  const handleCategorySelect = (category: Category, categoryAmount?: number) => {
    setSelectedCategory(category)
    if (categoryAmount !== undefined) {
      setAmount(categoryAmount)
    }
    setIsCategoryDialogOpen(false)
  }

  // 정기 거래 추가
  const handleAddTransaction = () => {
    if (!selectedCategory || !title || !date) {
      alert("필수 항목을 모두 입력해주세요.")
      return
    }

    const newTransaction = {
      id: recurringTransactions.length + 1,
      title,
      type: transactionType,
      amount: transactionType === "지출" ? -Math.abs(amount) : Math.abs(amount),
      category: selectedCategory.name,
      categoryEmoji: selectedCategory.emoji,
      frequency,
      startDate: format(date, "yyyy-MM-dd"),
      nextDate: format(date, "yyyy-MM-dd"),
      description,
      active,
    }

    setRecurringTransactions([...recurringTransactions, newTransaction])
    resetForm()
    setOpenNewTransaction(false)
  }

  // 정기 거래 수정
  const handleEditTransaction = (id: number) => {
    const transaction = recurringTransactions.find((item) => item.id === id)
    if (!transaction) return

    setEditingItemId(id)
    setTitle(transaction.title)
    setTransactionType(transaction.type as "수입" | "지출")
    setAmount(Math.abs(transaction.amount))
    setFrequency(transaction.frequency)
    setDate(new Date(transaction.nextDate))
    setDescription(transaction.description)
    setActive(transaction.active)

    // 카테고리 설정
    const category = {
      id: transaction.category.toLowerCase().replace(/\s+/g, "-"),
      name: transaction.category,
      emoji: transaction.categoryEmoji,
    }
    setSelectedCategory(category)

    setOpenNewTransaction(true)
  }

  // 수정 저장
  const handleSaveEdit = () => {
    if (!selectedCategory || !title || !date || editingItemId === null) {
      alert("필수 항목을 모두 입력해주세요.")
      return
    }

    const updatedTransactions = recurringTransactions.map((transaction) => {
      if (transaction.id === editingItemId) {
        return {
          ...transaction,
          title,
          type: transactionType,
          amount: transactionType === "지출" ? -Math.abs(amount) : Math.abs(amount),
          category: selectedCategory.name,
          categoryEmoji: selectedCategory.emoji,
          frequency,
          nextDate: format(date, "yyyy-MM-dd"),
          description,
          active,
        }
      }
      return transaction
    })

    setRecurringTransactions(updatedTransactions)
    resetForm()
    setOpenNewTransaction(false)
    setEditingItemId(null)
  }

  // 정기 거래 삭제 처리
  const handleDeleteTransaction = (id: number) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      setRecurringTransactions(recurringTransactions.filter((transaction) => transaction.id !== id))
    }
  }

  // 정기 거래 활성/비활성 전환
  const toggleTransactionActive = (id: number) => {
    setRecurringTransactions(
      recurringTransactions.map((transaction) =>
        transaction.id === id ? { ...transaction, active: !transaction.active } : transaction,
      ),
    )
  }

  // 폼 초기화
  const resetForm = () => {
    setTitle("")
    setTransactionType("지출")
    setSelectedCategory(null)
    setAmount(0)
    setFrequency("monthly")
    setDate(undefined)
    setDescription("")
    setActive(true)
  }

  // 주기 표시 텍스트
  const getFrequencyText = (frequency: string) => {
    switch (frequency) {
      case "monthly":
        return "매월"
      case "quarterly":
        return "분기별"
      case "yearly":
        return "매년"
      default:
        return frequency
    }
  }

  // 다음 결제일까지 남은 일수 계산
  const getDaysRemaining = (nextDate: string) => {
    const today = new Date()
    const next = new Date(nextDate)
    const diffTime = next.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  // 월간 총액 계산
  const calculateMonthlyTotal = (type: "수입" | "지출") => {
    return recurringTransactions
      .filter((t) => t.active && t.type === type)
      .reduce((sum, t) => {
        // 주기에 따라 월간 환산
        const amount = Math.abs(t.amount)
        switch (t.frequency) {
          case "monthly":
            return sum + amount
          case "quarterly":
            return sum + amount / 3
          case "yearly":
            return sum + amount / 12
          default:
            return sum
        }
      }, 0)
  }

  const filteredTransactions = getFilteredTransactions()

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">정기 거래 관리</h2>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              resetForm()
              setTransactionType("지출")
              setOpenNewTransaction(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            지출 추가
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              resetForm()
              setTransactionType("수입")
              setOpenNewTransaction(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            수입 추가
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">월간 정기 수입</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{calculateMonthlyTotal("수입").toLocaleString()}원</div>
            <p className="text-xs text-muted-foreground">
              활성화된 정기 수입 항목: {recurringTransactions.filter((t) => t.active && t.type === "수입").length}개
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">월간 정기 지출</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{calculateMonthlyTotal("지출").toLocaleString()}원</div>
            <p className="text-xs text-muted-foreground">
              활성화된 정기 지출 항목: {recurringTransactions.filter((t) => t.active && t.type === "지출").length}개
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">월간 순 현금흐름</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${
                calculateMonthlyTotal("수입") - calculateMonthlyTotal("지출") >= 0 ? "text-blue-600" : "text-red-600"
              }`}
            >
              {(calculateMonthlyTotal("수입") - calculateMonthlyTotal("지출")).toLocaleString()}원
            </div>
            <p className="text-xs text-muted-foreground">
              총 정기 거래: {recurringTransactions.filter((t) => t.active).length}개
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>정기 거래 목록</CardTitle>
              <CardDescription>모든 정기 수입 및 지출 내역을 관리하세요</CardDescription>
            </div>
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              <Select value={filterType} onValueChange={(value: "all" | "수입" | "지출") => setFilterType(value)}>
                <SelectTrigger className="w-full md:w-[150px]">
                  <SelectValue placeholder="유형 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 유형</SelectItem>
                  <SelectItem value="수입">수입</SelectItem>
                  <SelectItem value="지출">지출</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={filterFrequency}
                onValueChange={(value: "all" | "monthly" | "quarterly" | "yearly") => setFilterFrequency(value)}
              >
                <SelectTrigger className="w-full md:w-[150px]">
                  <SelectValue placeholder="주기 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 주기</SelectItem>
                  <SelectItem value="monthly">매월</SelectItem>
                  <SelectItem value="quarterly">분기별</SelectItem>
                  <SelectItem value="yearly">매년</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={filterActive}
                onValueChange={(value: "all" | "active" | "inactive") => setFilterActive(value)}
              >
                <SelectTrigger className="w-full md:w-[150px]">
                  <SelectValue placeholder="상태 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 상태</SelectItem>
                  <SelectItem value="active">활성</SelectItem>
                  <SelectItem value="inactive">비활성</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>제목</TableHead>
                  <TableHead>유형</TableHead>
                  <TableHead>카테고리</TableHead>
                  <TableHead>주기</TableHead>
                  <TableHead className="text-right">금액</TableHead>
                  <TableHead>다음 결제일</TableHead>
                  <TableHead>상태</TableHead>
                  <TableHead className="w-[80px]">액션</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.map((transaction) => {
                  const daysRemaining = getDaysRemaining(transaction.nextDate)

                  return (
                    <TableRow key={transaction.id} className={!transaction.active ? "opacity-60" : ""}>
                      <TableCell className="font-medium">{transaction.title}</TableCell>
                      <TableCell>
                        <Badge variant={transaction.type === "수입" ? "default" : "secondary"}>
                          {transaction.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span role="img" aria-label={transaction.category}>
                            {transaction.categoryEmoji}
                          </span>
                          <span>{transaction.category}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getFrequencyText(transaction.frequency)}</TableCell>
                      <TableCell
                        className={`text-right font-medium ${
                          transaction.type === "수입" ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        {Math.abs(transaction.amount).toLocaleString()}원
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {transaction.nextDate}
                          {transaction.active && daysRemaining <= 7 && (
                            <Badge variant="outline" className="text-xs bg-red-50">
                              {daysRemaining <= 0 ? "오늘" : `${daysRemaining}일 후`}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={transaction.active}
                            onCheckedChange={() => toggleTransactionActive(transaction.id)}
                          />
                          <span className="text-xs">{transaction.active ? "활성" : "비활성"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditTransaction(transaction.id)}>
                              <Edit className="mr-2 h-4 w-4" />
                              수정
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="mr-2 h-4 w-4" />
                              다음 날짜 업데이트
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-red-600"
                              onClick={() => handleDeleteTransaction(transaction.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              삭제
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })}
                {filteredTransactions.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-4 text-muted-foreground">
                      검색 결과가 없습니다
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">총 {filteredTransactions.length}개 항목</div>
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              다가오는 결제: {filteredTransactions.filter((t) => t.active && getDaysRemaining(t.nextDate) <= 7).length}
              개
            </span>
          </div>
        </CardFooter>
      </Card>

      {/* 정기 거래 추가/수정 다이얼로그 */}
      <Dialog open={openNewTransaction} onOpenChange={setOpenNewTransaction}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingItemId ? "정기 거래 수정" : `정기 ${transactionType} 추가`}</DialogTitle>
            <DialogDescription>
              {editingItemId ? "정기 거래 정보를 수정하세요" : `정기적으로 발생하는 ${transactionType}을 등록하세요`}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">제목</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="정기 거래 제목"
                required
              />
            </div>

            {!editingItemId && (
              <div className="grid gap-2">
                <Label htmlFor="type">유형</Label>
                <Select value={transactionType} onValueChange={(value: "수입" | "지출") => setTransactionType(value)}>
                  <SelectTrigger id="type">
                    <SelectValue placeholder="유형 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="수입">수입</SelectItem>
                    <SelectItem value="지출">지출</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="grid gap-2">
              <Label htmlFor="category">카테고리</Label>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsCategoryDialogOpen(true)}
              >
                {selectedCategory ? (
                  <div className="flex items-center gap-2">
                    <span role="img" aria-label={selectedCategory.name}>
                      {selectedCategory.emoji}
                    </span>
                    <span>{selectedCategory.name}</span>
                  </div>
                ) : (
                  "카테고리 선택"
                )}
              </Button>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="amount">금액</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="금액을 입력하세요"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="frequency">주기</Label>
              <Select value={frequency} onValueChange={setFrequency}>
                <SelectTrigger id="frequency">
                  <SelectValue placeholder="주기 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">매월</SelectItem>
                  <SelectItem value="quarterly">분기별</SelectItem>
                  <SelectItem value="yearly">매년</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="date">시작일 / 다음 결제일</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP", { locale: ko }) : "날짜 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={date} onSelect={setDate} initialFocus locale={ko} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">설명</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="설명 입력"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="active">활성화</Label>
              <Switch id="active" checked={active} onCheckedChange={setActive} />
            </div>
          </div>

          <DialogFooter>
            {editingItemId && (
              <Button
                variant="destructive"
                onClick={() => {
                  if (editingItemId) handleDeleteTransaction(editingItemId)
                  setOpenNewTransaction(false)
                  setEditingItemId(null)
                }}
              >
                삭제
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button
                variant="outline"
                onClick={() => {
                  setOpenNewTransaction(false)
                  setEditingItemId(null)
                  resetForm()
                }}
              >
                취소
              </Button>
              <Button onClick={editingItemId ? handleSaveEdit : handleAddTransaction}>
                {editingItemId ? "저장" : "추가"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 카테고리 선택 다이얼로그 */}
      <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>카테고리 선택</DialogTitle>
            <DialogDescription>
              {transactionType === "지출" ? "지출 카테고리를 선택하세요" : "수입 카테고리를 선택하세요"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <Tabs defaultValue={transactionType === "지출" ? "expense" : "income"}>
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="expense">지출</TabsTrigger>
                <TabsTrigger value="income">수입</TabsTrigger>
              </TabsList>

              <TabsContent value="expense" className="mt-0">
                <div className="grid grid-cols-4 gap-3">
                  {expenseCategories.map((category) => (
                    <Button
                      key={category.id}
                      variant="outline"
                      className="h-auto flex flex-col py-3 px-2 items-center justify-center gap-1 hover:bg-accent"
                      onClick={() => handleCategorySelect(category)}
                    >
                      <span className="text-2xl" role="img" aria-label={category.name}>
                        {category.emoji}
                      </span>
                      <span className="text-xs font-normal text-center">{category.name}</span>
                    </Button>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="income" className="mt-0">
                <div className="grid grid-cols-4 gap-3">
                  {incomeCategories.map((category) => (
                    <Button
                      key={category.id}
                      variant="outline"
                      className="h-auto flex flex-col py-3 px-2 items-center justify-center gap-1 hover:bg-accent"
                      onClick={() => handleCategorySelect(category)}
                    >
                      <span className="text-2xl" role="img" aria-label={category.name}>
                        {category.emoji}
                      </span>
                      <span className="text-xs font-normal text-center">{category.name}</span>
                    </Button>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex items-center gap-2 w-full">
              <Label htmlFor="category-amount" className="text-sm whitespace-nowrap">
                금액:
              </Label>
              <Input
                id="category-amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="text-right font-medium"
              />
              <span className="text-sm whitespace-nowrap">원</span>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCategoryDialogOpen(false)}>
              취소
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

