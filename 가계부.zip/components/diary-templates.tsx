"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

// 템플릿 데이터
const templates = [
  {
    id: "default",
    name: "기본",
    bgColor: "#ffffff",
    textColor: "#000000",
    fontFamily: "'Noto Sans KR', sans-serif",
    description: "깔끔하고 심플한 기본 템플릿",
  },
  {
    id: "minimal",
    name: "미니멀",
    bgColor: "#f8f9fa",
    textColor: "#343a40",
    fontFamily: "'Noto Sans KR', sans-serif",
    description: "군더더기 없는 미니멀한 디자인",
  },
  {
    id: "vintage",
    name: "빈티지",
    bgColor: "#f8f3e6",
    textColor: "#5c4b3c",
    fontFamily: "'Nanum Myeongjo', serif",
    description: "클래식하고 따뜻한 느낌의 빈티지 스타일",
  },
  {
    id: "nature",
    name: "자연",
    bgColor: "#e8f5e9",
    textColor: "#2e7d32",
    fontFamily: "'Nanum Pen Script', cursive",
    description: "자연을 연상시키는 편안한 녹색 계열",
  },
  {
    id: "dreamy",
    name: "드림",
    bgColor: "#e3f2fd",
    textColor: "#1565c0",
    fontFamily: "'Gaegu', cursive",
    description: "꿈같은 느낌의 부드러운 파란색 계열",
  },
  {
    id: "love",
    name: "러브",
    bgColor: "#fce4ec",
    textColor: "#c2185b",
    fontFamily: "'Gamja Flower', cursive",
    description: "사랑스러운 분위기의 핑크색 계열",
  },
  {
    id: "dark",
    name: "다크",
    bgColor: "#212121",
    textColor: "#e0e0e0",
    fontFamily: "'Noto Sans KR', sans-serif",
    description: "어두운 배경의 모던한 다크 모드",
  },
  {
    id: "bright",
    name: "밝음",
    bgColor: "#fff9c4",
    textColor: "#f57f17",
    fontFamily: "'Jua', sans-serif",
    description: "밝고 활기찬 느낌의 노란색 계열",
  },
  {
    id: "music",
    name: "음악",
    bgColor: "#e8eaf6",
    textColor: "#3949ab",
    fontFamily: "'Poor Story', cursive",
    description: "음악적 영감을 주는 보라색 계열",
  },
  // 새로운 추천 색상 조합 추가
  {
    id: "clean",
    name: "클린",
    bgColor: "#FFFFFF",
    textColor: "#333333",
    fontFamily: "'Noto Sans KR', sans-serif",
    description: "깔끔하고 가독성이 우수한 조합",
  },
  {
    id: "modern",
    name: "모던",
    bgColor: "#2C3E50",
    textColor: "#FFFFFF",
    fontFamily: "'Noto Sans KR', sans-serif",
    description: "모던하고 세련된 느낌의 조합",
  },
  {
    id: "pastel",
    name: "파스텔",
    bgColor: "#A8E6CF",
    textColor: "#555555",
    fontFamily: "'Gaegu', cursive",
    description: "부드럽고 친근한 파스텔 톤 조합",
  },
  {
    id: "contrast",
    name: "고대비",
    bgColor: "#001F3F",
    textColor: "#FFDC00",
    fontFamily: "'Noto Sans KR', sans-serif",
    description: "강렬한 대비로 주목성을 높이는 조합",
  },
  {
    id: "nature-theme",
    name: "자연 테마",
    bgColor: "#556B2F",
    textColor: "#FFFFF0",
    fontFamily: "'Nanum Myeongjo', serif",
    description: "자연스럽고 안정적인 느낌의 조합",
  },
  {
    id: "lavender",
    name: "라벤더",
    bgColor: "#E6E6FA",
    textColor: "#4B0082",
    fontFamily: "'Gamja Flower', cursive",
    description: "부드러운 라벤더 색상의 조합",
  },
]

interface DiaryTemplatesProps {
  selectedTemplate: string
  onSelectTemplate: (templateId: string) => void
}

export default function DiaryTemplates({ selectedTemplate, onSelectTemplate }: DiaryTemplatesProps) {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-bold">일기장 템플릿 선택</h2>
        <p className="text-muted-foreground">다양한 템플릿 중에서 마음에 드는 스타일을 선택하세요.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {templates.map((template) => (
          <Card
            key={template.id}
            className={`cursor-pointer hover:shadow-md transition-shadow ${
              selectedTemplate === template.id ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => onSelectTemplate(template.id)}
          >
            <CardHeader
              style={{
                backgroundColor: template.bgColor,
                color: template.textColor,
                fontFamily: template.fontFamily,
              }}
            >
              <div className="flex justify-between items-start">
                <CardTitle>{template.name}</CardTitle>
                {selectedTemplate === template.id && (
                  <div className="bg-primary text-primary-foreground rounded-full p-1">
                    <Check className="h-4 w-4" />
                  </div>
                )}
              </div>
              <CardDescription style={{ color: `${template.textColor}99` }}>{template.description}</CardDescription>
            </CardHeader>
            <CardContent className="p-4">
              <div
                className="p-4 rounded border"
                style={{
                  backgroundColor: template.bgColor,
                  color: template.textColor,
                  fontFamily: template.fontFamily,
                  borderColor: `${template.textColor}33`,
                }}
              >
                <h3 className="font-medium mb-2">미리보기</h3>
                <p>오늘 하루를 기록합니다. 이 템플릿으로 나만의 일기를 작성해보세요.</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                variant={selectedTemplate === template.id ? "default" : "outline"}
                className="w-full"
                onClick={() => onSelectTemplate(template.id)}
              >
                {selectedTemplate === template.id ? "선택됨" : "선택하기"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

