"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, LogIn } from "lucide-react"

export default function LoginButton() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // 실제 구현에서는 인증 로직이 들어갈 것입니다
    setIsLoggedIn(true)
    setUsername("사용자")
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUsername("")
  }

  if (isLoggedIn) {
    return (
      <Button variant="outline" onClick={handleLogout}>
        <User className="mr-2 h-4 w-4" />
        {username} 님
      </Button>
    )
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          <LogIn className="mr-2 h-4 w-4" />
          로그인
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <Tabs defaultValue="login">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">로그인</TabsTrigger>
            <TabsTrigger value="register">회원가입</TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <form onSubmit={handleLogin}>
              <DialogHeader>
                <DialogTitle>로그인</DialogTitle>
                <DialogDescription>계정 정보를 입력하여 로그인하세요.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="email">이메일</Label>
                  <Input id="email" type="email" placeholder="example@example.com" required />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="password">비밀번호</Label>
                  <Input id="password" type="password" required />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">로그인</Button>
              </DialogFooter>
            </form>
          </TabsContent>

          <TabsContent value="register">
            <DialogHeader>
              <DialogTitle>회원가입</DialogTitle>
              <DialogDescription>새 계정을 만들어 서비스를 이용하세요.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">이름</Label>
                <Input id="name" placeholder="홍길동" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="register-email">이메일</Label>
                <Input id="register-email" type="email" placeholder="example@example.com" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="register-password">비밀번호</Label>
                <Input id="register-password" type="password" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="confirm-password">비밀번호 확인</Label>
                <Input id="confirm-password" type="password" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button">회원가입</Button>
            </DialogFooter>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

