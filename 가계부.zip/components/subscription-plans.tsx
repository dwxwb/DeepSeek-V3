"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Check, X, CreditCard, Building, CheckCircle2, Lock } from "lucide-react"

// 구독 플랜 데이터
const subscriptionPlans = [
  {
    id: "free",
    name: "무료",
    price: 0,
    billingPeriod: "월",
    description: "기본 재무 관리 기능",
    features: [
      { name: "기본 가계부 기능", included: true },
      { name: "월간 예산 설정", included: true },
      { name: "기본 보고서", included: true },
      { name: "최대 2개 계좌/카드 연동", included: true },
      { name: "광고 표시", included: true },
      { name: "OCR 영수증 스캔", included: false },
      { name: "AI 지출 인사이트", included: false },
      { name: "자동 저축 기능", included: false },
      { name: "무제한 계좌/카드 연동", included: false },
      { name: "고급 보고서 및 분석", included: false },
      { name: "우선 고객 지원", included: false },
    ],
    popular: false,
    buttonText: "현재 플랜",
    buttonVariant: "outline" as const,
  },
  {
    id: "premium",
    name: "프리미엄",
    price: 9900,
    billingPeriod: "월",
    description: "고급 재무 관리 및 AI 기능",
    features: [
      { name: "기본 가계부 기능", included: true },
      { name: "월간 예산 설정", included: true },
      { name: "기본 보고서", included: true },
      { name: "최대 2개 계좌/카드 연동", included: true },
      { name: "광고 제거", included: true },
      { name: "OCR 영수증 스캔", included: true },
      { name: "AI 지출 인사이트", included: true },
      { name: "자동 저축 기능", included: true },
      { name: "무제한 계좌/카드 연동", included: false },
      { name: "고급 보고서 및 분석", included: false },
      { name: "우선 고객 지원", included: false },
    ],
    popular: true,
    buttonText: "업그레이드",
    buttonVariant: "default" as const,
  },
  {
    id: "business",
    name: "비즈니스",
    price: 29900,
    billingPeriod: "월",
    description: "기업용 재무 관리 솔루션",
    features: [
      { name: "기본 가계부 기능", included: true },
      { name: "월간 예산 설정", included: true },
      { name: "기본 보고서", included: true },
      { name: "최대 2개 계좌/카드 연동", included: true },
      { name: "광고 제거", included: true },
      { name: "OCR 영수증 스캔", included: true },
      { name: "AI 지출 인사이트", included: true },
      { name: "자동 저축 기능", included: true },
      { name: "무제한 계좌/카드 연동", included: true },
      { name: "고급 보고서 및 분석", included: true },
      { name: "우선 고객 지원", included: true },
    ],
    popular: false,
    buttonText: "문의하기",
    buttonVariant: "outline" as const,
  },
]

export default function SubscriptionPlans() {
  const [activeTab, setActiveTab] = useState("monthly")
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [openPaymentDialog, setOpenPaymentDialog] = useState(false)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [paymentProcessing, setPaymentProcessing] = useState(false)

  // 구독 플랜 선택 처리
  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId)

    if (planId === "free") {
      // 무료 플랜은 결제 없이 바로 적용
      alert("무료 플랜이 적용되었습니다.")
    } else if (planId === "business") {
      // 비즈니스 플랜은 문의 페이지로 이동
      alert("비즈니스 플랜 문의 페이지로 이동합니다.")
    } else {
      // 프리미엄 플랜은 결제 다이얼로그 표시
      setOpenPaymentDialog(true)
    }
  }

  // 결제 처리
  const handlePayment = () => {
    setPaymentProcessing(true)

    // 실제 구현에서는 여기에 결제 API 호출 코드가 들어갈 것입니다.
    setTimeout(() => {
      setPaymentProcessing(false)
      setPaymentSuccess(true)

      // 결제 성공 후 다이얼로그 닫기
      setTimeout(() => {
        setOpenPaymentDialog(false)
        setPaymentSuccess(false)
      }, 2000)
    }, 2000)
  }

  // 연간 요금제 가격 계산 (20% 할인)
  const calculateAnnualPrice = (monthlyPrice: number) => {
    return Math.round(monthlyPrice * 12 * 0.8)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">구독 플랜</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-center mb-4">
          <TabsList>
            <TabsTrigger value="monthly">월간 요금제</TabsTrigger>
            <TabsTrigger value="annual">연간 요금제 (20% 할인)</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="monthly">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {subscriptionPlans.map((plan) => (
              <Card key={plan.id} className={`flex flex-col ${plan.popular ? "border-primary shadow-md" : ""}`}>
                {plan.popular && (
                  <div className="bg-primary text-primary-foreground text-center py-1 text-sm font-medium">
                    인기 플랜
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-2">
                    <span className="text-3xl font-bold">
                      {plan.price === 0 ? "무료" : `${plan.price.toLocaleString()}원`}
                    </span>
                    {plan.price > 0 && <span className="text-muted-foreground">/{plan.billingPeriod}</span>}
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        {feature.included ? (
                          <Check className="h-5 w-5 text-green-500 shrink-0" />
                        ) : (
                          <X className="h-5 w-5 text-muted-foreground shrink-0" />
                        )}
                        <span className={feature.included ? "" : "text-muted-foreground"}>{feature.name}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" variant={plan.buttonVariant} onClick={() => handleSelectPlan(plan.id)}>
                    {plan.buttonText}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="annual">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {subscriptionPlans.map((plan) => (
              <Card key={plan.id} className={`flex flex-col ${plan.popular ? "border-primary shadow-md" : ""}`}>
                {plan.popular && (
                  <div className="bg-primary text-primary-foreground text-center py-1 text-sm font-medium">
                    인기 플랜
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-2">
                    {plan.price === 0 ? (
                      <span className="text-3xl font-bold">무료</span>
                    ) : (
                      <>
                        <span className="text-3xl font-bold">
                          {calculateAnnualPrice(plan.price).toLocaleString()}원
                        </span>
                        <span className="text-muted-foreground">/년</span>
                        <div className="text-sm text-muted-foreground mt-1">
                          월 {Math.round(calculateAnnualPrice(plan.price) / 12).toLocaleString()}원
                        </div>
                        <Badge variant="outline" className="mt-2 bg-green-50 text-green-700 border-green-200">
                          20% 할인
                        </Badge>
                      </>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        {feature.included ? (
                          <Check className="h-5 w-5 text-green-500 shrink-0" />
                        ) : (
                          <X className="h-5 w-5 text-muted-foreground shrink-0" />
                        )}
                        <span className={feature.included ? "" : "text-muted-foreground"}>{feature.name}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" variant={plan.buttonVariant} onClick={() => handleSelectPlan(plan.id)}>
                    {plan.buttonText}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <div className="bg-muted p-4 rounded-md">
        <h3 className="font-medium mb-2">기업용 API 서비스</h3>
        <p className="text-sm text-muted-foreground mb-4">
          재무 분석 API를 귀사의 서비스에 통합하세요. 맞춤형 가격 책정 및 기능을 제공합니다.
        </p>
        <Button variant="outline">API 문의하기</Button>
      </div>

      {/* 결제 다이얼로그 */}
      <Dialog open={openPaymentDialog} onOpenChange={setOpenPaymentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>프리미엄 구독 결제</DialogTitle>
            <DialogDescription>
              {activeTab === "monthly"
                ? "월 9,900원으로 프리미엄 기능을 이용하세요."
                : "연 95,040원(월 7,920원)으로 프리미엄 기능을 이용하세요."}
            </DialogDescription>
          </DialogHeader>

          {!paymentSuccess ? (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">결제 수단 선택</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="justify-start">
                    <CreditCard className="mr-2 h-4 w-4" />
                    신용/체크카드
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Building className="mr-2 h-4 w-4" />
                    계좌이체
                  </Button>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-medium mb-2">결제 정보</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>구독 플랜</span>
                    <span className="font-medium">프리미엄 ({activeTab === "monthly" ? "월간" : "연간"})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>결제 금액</span>
                    <span className="font-medium">{activeTab === "monthly" ? "9,900원" : "95,040원"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>다음 결제일</span>
                    <span className="font-medium">
                      {activeTab === "monthly" ? "2024년 5월 15일" : "2025년 4월 15일"}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-muted p-3 rounded-md flex items-start gap-2 text-sm">
                <Lock className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div>
                  <p>모든 결제 정보는 안전하게 암호화되어 처리됩니다.</p>
                  <p>언제든지 구독을 취소할 수 있습니다.</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-8 flex flex-col items-center justify-center">
              <div className="bg-green-100 p-3 rounded-full mb-4">
                <CheckCircle2 className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-medium text-center mb-2">결제 완료!</h3>
              <p className="text-center text-muted-foreground">프리미엄 구독이 성공적으로 활성화되었습니다.</p>
            </div>
          )}

          <DialogFooter>
            {!paymentSuccess ? (
              <>
                <Button variant="outline" onClick={() => setOpenPaymentDialog(false)} disabled={paymentProcessing}>
                  취소
                </Button>
                <Button onClick={handlePayment} disabled={paymentProcessing}>
                  {paymentProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      처리 중...
                    </>
                  ) : (
                    "결제하기"
                  )}
                </Button>
              </>
            ) : (
              <Button onClick={() => setOpenPaymentDialog(false)}>확인</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

