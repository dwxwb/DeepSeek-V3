"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Dashboard from "./dashboard"
import Ledger from "./ledger"
import TransactionManager from "./transaction-manager"
import Reports from "./reports"
import Settings from "./settings"
import ExcelImport from "./excel-import"
import ItemManagement from "./item-management"
import Calculator from "./calculator"

export default function FinanceApp() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">가계부</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 md:grid-cols-8">
          <TabsTrigger value="dashboard">대시보드</TabsTrigger>
          <TabsTrigger value="ledger">장부</TabsTrigger>
          <TabsTrigger value="transactions">거래</TabsTrigger>
          <TabsTrigger value="reports">보고서</TabsTrigger>
          <TabsTrigger value="excel">엑셀</TabsTrigger>
          <TabsTrigger value="items">품목관리</TabsTrigger>
          <TabsTrigger value="calculator">계산기</TabsTrigger>
          <TabsTrigger value="settings">설정</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="mt-4">
          <Dashboard />
        </TabsContent>

        <TabsContent value="ledger" className="mt-4">
          <Ledger />
        </TabsContent>

        <TabsContent value="transactions" className="mt-4">
          <TransactionManager />
        </TabsContent>

        <TabsContent value="reports" className="mt-4">
          <Reports />
        </TabsContent>

        <TabsContent value="excel" className="mt-4">
          <ExcelImport />
        </TabsContent>

        <TabsContent value="items" className="mt-4">
          <ItemManagement />
        </TabsContent>

        <TabsContent value="calculator" className="mt-4">
          <Calculator />
        </TabsContent>

        <TabsContent value="settings" className="mt-4">
          <Settings />
        </TabsContent>
      </Tabs>
    </div>
  )
}

