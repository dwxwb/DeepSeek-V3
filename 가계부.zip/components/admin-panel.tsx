"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Search,
  Edit,
  Trash2,
  MoreHorizontal,
  Mail,
  MessageSquare,
  UserPlus,
  Download,
  RefreshCw,
  Lock,
  ShieldAlert,
  Users,
  FileText,
  BarChart4,
  Home,
  Phone,
  User,
} from "lucide-react"
import { getEmojiForCategoryName } from "@/lib/category-data"

// 가상의 고객 데이터
const initialCustomers = [
  {
    id: 1,
    name: "홍길동",
    email: "hong@example.com",
    phone: "010-1234-5678",
    address: "서울시 강남구 테헤란로 123",
    company: "(주)예시기업",
    status: "active",
    plan: "프리미엄",
    joinDate: "2023-01-15",
    lastLogin: "2024-03-28",
    transactions: 24,
    totalSpent: 1250000,
  },
  {
    id: 2,
    name: "김철수",
    email: "kim@example.com",
    phone: "010-2345-6789",
    address: "서울시 서초구 서초대로 456",
    company: "철수상사",
    status: "active",
    plan: "기본",
    joinDate: "2023-02-20",
    lastLogin: "2024-03-27",
    transactions: 18,
    totalSpent: 850000,
  },
  {
    id: 3,
    name: "이영희",
    email: "lee@example.com",
    phone: "010-3456-7890",
    address: "경기도 성남시 분당구 판교로 789",
    company: "영희컴퍼니",
    status: "inactive",
    plan: "프리미엄",
    joinDate: "2023-03-10",
    lastLogin: "2024-02-15",
    transactions: 32,
    totalSpent: 1680000,
  },
  {
    id: 4,
    name: "박민수",
    email: "park@example.com",
    phone: "010-4567-8901",
    address: "인천시 연수구 센트럴로 101",
    company: "민수기업",
    status: "active",
    plan: "기본",
    joinDate: "2023-04-05",
    lastLogin: "2024-03-26",
    transactions: 12,
    totalSpent: 520000,
  },
  {
    id: 5,
    name: "정다운",
    email: "jung@example.com",
    phone: "010-5678-9012",
    address: "대전시 유성구 대학로 234",
    company: "다운테크",
    status: "active",
    plan: "프리미엄",
    joinDate: "2023-05-12",
    lastLogin: "2024-03-28",
    transactions: 28,
    totalSpent: 1420000,
  },
  {
    id: 6,
    name: "최지수",
    email: "choi@example.com",
    phone: "010-6789-0123",
    address: "부산시 해운대구 해운대로 567",
    company: "지수컨설팅",
    status: "inactive",
    plan: "기본",
    joinDate: "2023-06-18",
    lastLogin: "2024-01-10",
    transactions: 8,
    totalSpent: 320000,
  },
  {
    id: 7,
    name: "강현우",
    email: "kang@example.com",
    phone: "010-7890-1234",
    address: "광주시 서구 상무대로 890",
    company: "현우물산",
    status: "active",
    plan: "프리미엄",
    joinDate: "2023-07-22",
    lastLogin: "2024-03-25",
    transactions: 22,
    totalSpent: 1150000,
  },
  {
    id: 8,
    name: "윤서연",
    email: "yoon@example.com",
    phone: "010-8901-2345",
    address: "대구시 동구 동대구로 123",
    company: "서연디자인",
    status: "active",
    plan: "기본",
    joinDate: "2023-08-30",
    lastLogin: "2024-03-27",
    transactions: 15,
    totalSpent: 680000,
  },
  {
    id: 9,
    name: "임재현",
    email: "lim@example.com",
    phone: "010-9012-3456",
    address: "울산시 남구 삼산로 456",
    company: "재현엔지니어링",
    status: "inactive",
    plan: "프리미엄",
    joinDate: "2023-09-14",
    lastLogin: "2024-02-28",
    transactions: 19,
    totalSpent: 950000,
  },
  {
    id: 10,
    name: "한미영",
    email: "han@example.com",
    phone: "010-0123-4567",
    address: "세종시 한누리대로 789",
    company: "미영푸드",
    status: "active",
    plan: "기본",
    joinDate: "2023-10-05",
    lastLogin: "2024-03-26",
    transactions: 14,
    totalSpent: 620000,
  },
]

// 가상의 관리자 계정
const adminCredentials = {
  username: "admin",
  password: "admin123",
}

// 가상의 메시지 템플릿
const messageTemplates = [
  {
    id: 1,
    title: "신규 기능 안내",
    type: "email",
    subject: "새로운 기능이 추가되었습니다!",
    content:
      "안녕하세요, {name}님!\n\n저희 서비스에 새로운 기능이 추가되었습니다. 지금 바로 확인해보세요.\n\n감사합니다.",
  },
  {
    id: 2,
    title: "결제 안내",
    type: "email",
    subject: "결제 안내 메일입니다",
    content: "안녕하세요, {name}님!\n\n{date}에 {amount}원이 결제될 예정입니다. 확인 부탁드립니다.\n\n감사합니다.",
  },
  {
    id: 3,
    title: "이벤트 안내",
    type: "sms",
    content: "[재무관리시스템] {name}님, 신규 이벤트가 시작되었습니다. 지금 확인해보세요!",
  },
  {
    id: 4,
    title: "비밀번호 재설정",
    type: "email",
    subject: "비밀번호 재설정 안내",
    content:
      "안녕하세요, {name}님!\n\n비밀번호 재설정을 요청하셨습니다. 아래 링크를 클릭하여 비밀번호를 재설정해주세요.\n\n{link}\n\n감사합니다.",
  },
]

export default function AdminPanel() {
  const [customers, setCustomers] = useState(initialCustomers)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterPlan, setFilterPlan] = useState("all")
  const [selectedCustomers, setSelectedCustomers] = useState<number[]>([])
  const [openAddCustomer, setOpenAddCustomer] = useState(false)
  const [openMessageDialog, setOpenMessageDialog] = useState(false)
  const [openCustomerDetail, setOpenCustomerDetail] = useState(false)
  const [selectedCustomerDetail, setSelectedCustomerDetail] = useState<any>(null)
  const [messageType, setMessageType] = useState<"email" | "sms">("email")
  const [messageSubject, setMessageSubject] = useState("")
  const [messageContent, setMessageContent] = useState("")
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [loginError, setLoginError] = useState("")
  const [activeTab, setActiveTab] = useState("customers")

  // 로그인 처리
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (username === adminCredentials.username && password === adminCredentials.password) {
      setIsLoggedIn(true)
      setLoginError("")
    } else {
      setLoginError("아이디 또는 비밀번호가 올바르지 않습니다.")
    }
  }

  // 로그아웃 처리
  const handleLogout = () => {
    setIsLoggedIn(false)
    setUsername("")
    setPassword("")
  }

  // 필터링된 고객 데이터 가져오기
  const getFilteredCustomers = () => {
    return customers.filter((customer) => {
      // 검색어 필터링
      const matchesSearch =
        searchTerm === "" ||
        customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone.includes(searchTerm)

      // 상태 필터링
      const matchesStatus = filterStatus === "all" || customer.status === filterStatus

      // 플랜 필터링
      const matchesPlan = filterPlan === "all" || customer.plan === filterPlan

      return matchesSearch && matchesStatus && matchesPlan
    })
  }

  // 고객 추가 처리
  const handleAddCustomer = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)

    const newCustomer = {
      id: customers.length + 1,
      name: formData.get("name") as string,
      email: formData.get("email") as string,
      phone: formData.get("phone") as string,
      address: formData.get("address") as string,
      company: formData.get("company") as string,
      status: "active",
      plan: formData.get("plan") as string,
      joinDate: new Date().toISOString().split("T")[0],
      lastLogin: new Date().toISOString().split("T")[0],
      transactions: 0,
      totalSpent: 0,
    }

    setCustomers([...customers, newCustomer])
    setOpenAddCustomer(false)
    e.currentTarget.reset()
  }

  // 고객 삭제 처리
  const handleDeleteCustomer = (id: number) => {
    setCustomers(customers.filter((customer) => customer.id !== id))
    setSelectedCustomers(selectedCustomers.filter((customerId) => customerId !== id))
  }

  // 선택된 고객 삭제 처리
  const handleDeleteSelectedCustomers = () => {
    setCustomers(customers.filter((customer) => !selectedCustomers.includes(customer.id)))
    setSelectedCustomers([])
  }

  // 모든 고객 선택/해제
  const toggleSelectAll = () => {
    if (selectedCustomers.length === getFilteredCustomers().length) {
      setSelectedCustomers([])
    } else {
      setSelectedCustomers(getFilteredCustomers().map((customer) => customer.id))
    }
  }

  // 고객 선택 처리
  const toggleCustomerSelection = (id: number) => {
    if (selectedCustomers.includes(id)) {
      setSelectedCustomers(selectedCustomers.filter((customerId) => customerId !== id))
    } else {
      setSelectedCustomers([...selectedCustomers, id])
    }
  }

  // 고객 상세 정보 보기
  const handleViewCustomerDetail = (customer: any) => {
    setSelectedCustomerDetail(customer)
    setOpenCustomerDetail(true)
  }

  // 메시지 템플릿 선택 처리
  const handleSelectTemplate = (templateIdOrCustom: string) => {
    if (templateIdOrCustom === "custom") {
      setSelectedTemplate(null)
      setMessageSubject("")
      setMessageContent("")
      return
    }

    const templateId = Number.parseInt(templateIdOrCustom)
    const template = messageTemplates.find((t) => t.id === templateId)
    if (template) {
      setSelectedTemplate(templateId)
      setMessageType(template.type as "email" | "sms")
      if (template.type === "email" && template.subject) {
        setMessageSubject(template.subject)
      }
      setMessageContent(template.content)
    }
  }

  // 메시지 전송 처리
  const handleSendMessage = () => {
    // 실제 구현에서는 여기에 이메일 또는 SMS 전송 API 호출 코드가 들어갈 것입니다.
    const selectedCustomerNames = selectedCustomers
      .map((id) => customers.find((c) => c.id === id)?.name)
      .filter(Boolean)
      .join(", ")

    alert(
      `${messageType === "email" ? "이메일" : "SMS"} 전송 완료!\n대상: ${selectedCustomers.length}명 (${selectedCustomerNames})\n${messageType === "email" ? `제목: ${messageSubject}\n` : ""}내용: ${messageContent}`,
    )

    setOpenMessageDialog(false)
    setMessageSubject("")
    setMessageContent("")
    setSelectedTemplate(null)
  }

  // 로그인 폼 렌더링
  if (!isLoggedIn) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5" />
              관리자 로그인
            </CardTitle>
            <CardDescription>관리자 계정으로 로그인하여 고객 정보를 관리하세요.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="username">아이디</Label>
                <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="password">비밀번호</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {loginError && <div className="text-sm text-red-500">{loginError}</div>}
              <Button type="submit" className="w-full">
                로그인
              </Button>
            </form>
          </CardContent>
          <CardFooter className="text-center text-sm text-muted-foreground">
            <div className="w-full">
              <p>테스트 계정: admin / admin123</p>
            </div>
          </CardFooter>
        </Card>
      </div>
    )
  }

  // 관리자 패널 렌더링
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Users className="h-6 w-6" />
          관리자 패널
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleLogout}>
            <Lock className="mr-2 h-4 w-4" />
            로그아웃
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="customers">회원 관리</TabsTrigger>
          <TabsTrigger value="messages">메시지 관리</TabsTrigger>
          <TabsTrigger value="stats">통계</TabsTrigger>
        </TabsList>

        <TabsContent value="customers">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle>회원 목록</CardTitle>
                  <CardDescription>모든 회원 정보를 관리하세요</CardDescription>
                </div>
                <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="검색..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full md:w-[150px]">
                      <SelectValue placeholder="상태 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체 상태</SelectItem>
                      <SelectItem value="active">활성</SelectItem>
                      <SelectItem value="inactive">비활성</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterPlan} onValueChange={setFilterPlan}>
                    <SelectTrigger className="w-full md:w-[150px]">
                      <SelectValue placeholder="플랜 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체 플랜</SelectItem>
                      <SelectItem value="기본">기본</SelectItem>
                      <SelectItem value="프리미엄">프리미엄</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button onClick={() => setOpenAddCustomer(true)}>
                    <UserPlus className="mr-2 h-4 w-4" />
                    회원 추가
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {selectedCustomers.length > 0 && (
                  <div className="bg-muted p-2 rounded-md flex justify-between items-center">
                    <span className="text-sm">{selectedCustomers.length}명의 회원이 선택됨</span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => setOpenMessageDialog(true)}>
                        <Mail className="mr-2 h-4 w-4" />
                        메시지 전송
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600"
                        onClick={handleDeleteSelectedCustomers}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        선택 삭제
                      </Button>
                    </div>
                  </div>
                )}

                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[40px]">
                          <Checkbox
                            checked={
                              getFilteredCustomers().length > 0 &&
                              selectedCustomers.length === getFilteredCustomers().length
                            }
                            onCheckedChange={toggleSelectAll}
                          />
                        </TableHead>
                        <TableHead>이름</TableHead>
                        <TableHead>이메일</TableHead>
                        <TableHead>전화번호</TableHead>
                        <TableHead>회사</TableHead>
                        <TableHead>플랜</TableHead>
                        <TableHead>상태</TableHead>
                        <TableHead>가입일</TableHead>
                        <TableHead>최근 로그인</TableHead>
                        <TableHead className="w-[80px]">액션</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getFilteredCustomers().map((customer) => (
                        <TableRow key={customer.id}>
                          <TableCell>
                            <Checkbox
                              checked={selectedCustomers.includes(customer.id)}
                              onCheckedChange={() => toggleCustomerSelection(customer.id)}
                            />
                          </TableCell>
                          <TableCell className="font-medium">{customer.name}</TableCell>
                          <TableCell>{customer.email}</TableCell>
                          <TableCell>{customer.phone}</TableCell>
                          <TableCell>{customer.company}</TableCell>
                          <TableCell>
                            <Badge variant={customer.plan === "프리미엄" ? "default" : "outline"}>
                              {customer.plan}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={customer.status === "active" ? "success" : "secondary"}>
                              {customer.status === "active" ? "활성" : "비활성"}
                            </Badge>
                          </TableCell>
                          <TableCell>{customer.joinDate}</TableCell>
                          <TableCell>{customer.lastLogin}</TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewCustomerDetail(customer)}>
                                  <FileText className="mr-2 h-4 w-4" />
                                  상세 정보
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  수정
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => {
                                    setSelectedCustomers([customer.id])
                                    setOpenMessageDialog(true)
                                  }}
                                >
                                  <Mail className="mr-2 h-4 w-4" />
                                  메시지 전송
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  className="text-red-600"
                                  onClick={() => handleDeleteCustomer(customer.id)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  삭제
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                      {getFilteredCustomers().length === 0 && (
                        <TableRow>
                          <TableCell colSpan={10} className="text-center py-4 text-muted-foreground">
                            검색 결과가 없습니다
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">총 {getFilteredCustomers().length}명의 회원</div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  내보내기
                </Button>
                <Button variant="outline" size="sm">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  새로고침
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="messages">
          <Card>
            <CardHeader>
              <CardTitle>메시지 관리</CardTitle>
              <CardDescription>회원에게 이메일 또는 SMS 메시지를 전송하세요</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label>메시지 유형</Label>
                    <div className="flex gap-4">
                      <div className="flex items-center gap-2">
                        <Button
                          variant={messageType === "email" ? "default" : "outline"}
                          onClick={() => setMessageType("email")}
                          className="gap-2"
                        >
                          <Mail className="h-4 w-4" />
                          이메일
                        </Button>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant={messageType === "sms" ? "default" : "outline"}
                          onClick={() => setMessageType("sms")}
                          className="gap-2"
                        >
                          <MessageSquare className="h-4 w-4" />
                          SMS
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label>메시지 템플릿</Label>
                    <Select value={selectedTemplate?.toString() || "custom"} onValueChange={handleSelectTemplate}>
                      <SelectTrigger>
                        <SelectValue placeholder="템플릿 선택 (선택사항)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="custom">직접 입력</SelectItem>
                        {messageTemplates
                          .filter((template) => template.type === messageType)
                          .map((template) => (
                            <SelectItem key={template.id} value={template.id.toString()}>
                              {template.title}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label>수신자</Label>
                    <div className="p-2 border rounded-md bg-muted">
                      {selectedCustomers.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {selectedCustomers.map((id) => {
                            const customer = customers.find((c) => c.id === id)
                            return customer ? (
                              <Badge key={id} variant="secondary" className="gap-1">
                                {customer.name}
                                <button className="ml-1 text-xs" onClick={() => toggleCustomerSelection(id)}>
                                  ✕
                                </button>
                              </Badge>
                            ) : null
                          })}
                        </div>
                      ) : (
                        <div className="text-sm text-muted-foreground">
                          선택된 회원이 없습니다. 회원 목록 탭에서 회원을 선택하세요.
                        </div>
                      )}
                    </div>
                    <div className="flex justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedCustomers(customers.map((c) => c.id))}
                      >
                        전체 회원 선택
                      </Button>
                    </div>
                  </div>

                  {messageType === "email" && (
                    <div className="grid gap-2">
                      <Label htmlFor="subject">제목</Label>
                      <Input
                        id="subject"
                        value={messageSubject}
                        onChange={(e) => setMessageSubject(e.target.value)}
                        placeholder="이메일 제목을 입력하세요"
                      />
                    </div>
                  )}

                  <div className="grid gap-2">
                    <Label htmlFor="content">내용</Label>
                    <Textarea
                      id="content"
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      placeholder="메시지 내용을 입력하세요"
                      rows={6}
                    />
                    <p className="text-xs text-muted-foreground">
                      다음 변수를 사용할 수 있습니다: {"{name}"} - 회원 이름, {"{email}"} - 이메일, {"{date}"} - 오늘
                      날짜
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">미리보기</Button>
              <Button
                onClick={handleSendMessage}
                disabled={
                  selectedCustomers.length === 0 || !messageContent || (messageType === "email" && !messageSubject)
                }
              >
                {messageType === "email" ? (
                  <Mail className="mr-2 h-4 w-4" />
                ) : (
                  <MessageSquare className="mr-2 h-4 w-4" />
                )}
                {messageType === "email" ? "이메일 전송" : "SMS 전송"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>회원 통계</CardTitle>
              <CardDescription>회원 활동 및 사용 통계를 확인하세요</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-lg font-medium">총 회원 수</h3>
                  <p className="text-3xl font-bold">{customers.length}명</p>
                  <p className="text-sm text-muted-foreground">
                    활성 회원: {customers.filter((c) => c.status === "active").length}명
                  </p>
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-lg font-medium">총 거래 수</h3>
                  <p className="text-3xl font-bold">{customers.reduce((sum, c) => sum + c.transactions, 0)}건</p>
                  <p className="text-sm text-muted-foreground">
                    회원당 평균: {(customers.reduce((sum, c) => sum + c.transactions, 0) / customers.length).toFixed(1)}
                    건
                  </p>
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-lg font-medium">총 매출</h3>
                  <p className="text-3xl font-bold">
                    {customers.reduce((sum, c) => sum + c.totalSpent, 0).toLocaleString()}원
                  </p>
                  <p className="text-sm text-muted-foreground">
                    회원당 평균:{" "}
                    {(customers.reduce((sum, c) => sum + c.totalSpent, 0) / customers.length).toLocaleString()}원
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">최근 가입 회원</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>이름</TableHead>
                      <TableHead>이메일</TableHead>
                      <TableHead>전화번호</TableHead>
                      <TableHead>가입일</TableHead>
                      <TableHead>플랜</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {customers
                      .sort((a, b) => new Date(b.joinDate).getTime() - new Date(a.joinDate).getTime())
                      .slice(0, 5)
                      .map((customer) => (
                        <TableRow key={customer.id}>
                          <TableCell className="font-medium">{customer.name}</TableCell>
                          <TableCell>{customer.email}</TableCell>
                          <TableCell>{customer.phone}</TableCell>
                          <TableCell>{customer.joinDate}</TableCell>
                          <TableCell>
                            <Badge variant={customer.plan === "프리미엄" ? "default" : "outline"}>
                              {customer.plan}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline">
                <BarChart4 className="mr-2 h-4 w-4" />
                상세 분석 보기
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 회원 추가 다이얼로그 */}
      <Dialog open={openAddCustomer} onOpenChange={setOpenAddCustomer}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>새 회원 추가</DialogTitle>
            <DialogDescription>새로운 회원 정보를 입력하세요.</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleAddCustomer}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">이름</Label>
                <Input id="name" name="name" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="email">이메일</Label>
                <Input id="email" name="email" type="email" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="phone">전화번호</Label>
                <Input id="phone" name="phone" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="address">주소</Label>
                <Input id="address" name="address" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="company">회사</Label>
                <Input id="company" name="company" required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="plan">플랜</Label>
                <Select name="plan" defaultValue="기본">
                  <SelectTrigger id="plan">
                    <SelectValue placeholder="플랜 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="기본">기본</SelectItem>
                    <SelectItem value="프리미엄">프리미엄</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button type="submit">저장</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* 메시지 전송 다이얼로그 */}
      <Dialog open={openMessageDialog} onOpenChange={setOpenMessageDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>메시지 전송</DialogTitle>
            <DialogDescription>
              {selectedCustomers.length}명의 회원에게 {messageType === "email" ? "이메일" : "SMS"}을 전송합니다.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>메시지 유형</Label>
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <Button
                    variant={messageType === "email" ? "default" : "outline"}
                    onClick={() => setMessageType("email")}
                    className="gap-2"
                  >
                    <Mail className="h-4 w-4" />
                    이메일
                  </Button>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant={messageType === "sms" ? "default" : "outline"}
                    onClick={() => setMessageType("sms")}
                    className="gap-2"
                  >
                    <MessageSquare className="h-4 w-4" />
                    SMS
                  </Button>
                </div>
              </div>
            </div>

            {messageType === "email" && (
              <div className="grid gap-2">
                <Label htmlFor="dialog-subject">제목</Label>
                <Input
                  id="dialog-subject"
                  value={messageSubject}
                  onChange={(e) => setMessageSubject(e.target.value)}
                  placeholder="이메일 제목을 입력하세요"
                />
              </div>
            )}

            <div className="grid gap-2">
              <Label htmlFor="dialog-content">내용</Label>
              <Textarea
                id="dialog-content"
                value={messageContent}
                onChange={(e) => setMessageContent(e.target.value)}
                placeholder="메시지 내용을 입력하세요"
                rows={6}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={handleSendMessage}
              disabled={!messageContent || (messageType === "email" && !messageSubject)}
            >
              {messageType === "email" ? "이메일 전송" : "SMS 전송"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 회원 상세 정보 다이얼로그 */}
      <Dialog open={openCustomerDetail} onOpenChange={setOpenCustomerDetail}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>회원 상세 정보</DialogTitle>
            <DialogDescription>{selectedCustomerDetail?.name}님의 상세 정보</DialogDescription>
          </DialogHeader>

          {selectedCustomerDetail && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-2">기본 정보</h3>
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <User className="h-4 w-4 mt-1 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{selectedCustomerDetail.name}</p>
                          <p className="text-sm text-muted-foreground">{selectedCustomerDetail.company}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Mail className="h-4 w-4 mt-1 text-muted-foreground" />
                        <div>
                          <p>{selectedCustomerDetail.email}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Phone className="h-4 w-4 mt-1 text-muted-foreground" />
                        <div>
                          <p>{selectedCustomerDetail.phone}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Home className="h-4 w-4 mt-1 text-muted-foreground" />
                        <div>
                          <p>{selectedCustomerDetail.address}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">계정 정보</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">가입일</span>
                        <span>{selectedCustomerDetail.joinDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">최근 로그인</span>
                        <span>{selectedCustomerDetail.lastLogin}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">상태</span>
                        <Badge variant={selectedCustomerDetail.status === "active" ? "success" : "secondary"}>
                          {selectedCustomerDetail.status === "active" ? "활성" : "비활성"}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">플랜</span>
                        <Badge variant={selectedCustomerDetail.plan === "프리미엄" ? "default" : "outline"}>
                          {selectedCustomerDetail.plan}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-2">활동 정보</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">총 거래 수</span>
                        <span className="font-medium">{selectedCustomerDetail.transactions}건</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">총 지출액</span>
                        <span className="font-medium">{selectedCustomerDetail.totalSpent.toLocaleString()}원</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">최근 카테고리</h3>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <span role="img" aria-label="식비">
                          {getEmojiForCategoryName("식비")}
                        </span>{" "}
                        식비
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <span role="img" aria-label="교통비">
                          {getEmojiForCategoryName("교통비")}
                        </span>{" "}
                        교통비
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <span role="img" aria-label="쇼핑">
                          {getEmojiForCategoryName("쇼핑")}
                        </span>{" "}
                        쇼핑
                      </Badge>
                    </div>
                  </div>

                  <div className="bg-muted p-4 rounded-lg">
                    <h3 className="text-lg font-medium mb-2">메모</h3>
                    <p className="text-sm text-muted-foreground">
                      회원 메모가 없습니다. 메모를 추가하려면 수정 버튼을 클릭하세요.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedCustomers([selectedCustomerDetail.id])
                    setOpenMessageDialog(true)
                    setOpenCustomerDetail(false)
                  }}
                >
                  <Mail className="mr-2 h-4 w-4" />
                  메시지 전송
                </Button>
                <Button>
                  <Edit className="mr-2 h-4 w-4" />
                  수정
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

