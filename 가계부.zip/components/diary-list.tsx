"use client"

import { useState } from "react"
import { format, parseISO } from "date-fns"
import { ko } from "date-fns/locale"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Calendar } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"
import { Search, Plus, CalendarIcon } from "lucide-react"

// 가상의 일기 데이터
const diaryEntries = [
  {
    id: 1,
    date: "2024-04-15",
    title: "봄날의 산책",
    emotion: "happy",
    section: "daily",
    preview: "오늘은 날씨가 정말 좋아서 공원에 산책을 다녀왔다. 벚꽃이 만개해서 정말 아름다웠다.",
  },
  {
    id: 2,
    date: "2024-04-14",
    title: "새로운 프로젝트",
    emotion: "excited",
    section: "work",
    preview: "오늘부터 새로운 프로젝트를 시작했다. 팀원들과 함께 아이디어를 나누는 시간이 즐거웠다.",
  },
  {
    id: 3,
    date: "2024-04-10",
    title: "감사한 하루",
    emotion: "calm",
    section: "gratitude",
    preview: "오늘 하루도 무사히 마무리할 수 있어 감사하다. 특히 가족들과 함께한 저녁 식사가 행복했다.",
  },
  {
    id: 4,
    date: "2024-04-05",
    title: "여행 계획",
    emotion: "happy",
    section: "travel",
    preview: "다음 달에 있을 여행 계획을 세웠다. 오랜만의 여행이라 기대가 크다.",
  },
  {
    id: 5,
    date: "2024-04-01",
    title: "4월의 시작",
    emotion: "calm",
    section: "reflection",
    preview: "새로운 달이 시작되었다. 지난 달을 돌아보고 이번 달의 목표를 세워보았다.",
  },
]

// 감정 이모티콘 매핑
const emotionEmojis: Record<string, string> = {
  happy: "😊",
  sad: "😢",
  angry: "😠",
  excited: "😆",
  tired: "😫",
  calm: "😌",
  worried: "😟",
  surprised: "😲",
  love: "😍",
  confused: "😕",
}

// 섹션 라벨 매핑
const sectionLabels: Record<string, string> = {
  daily: "일상 기록",
  gratitude: "감사 일기",
  dream: "꿈 일기",
  goal: "목표 일기",
  travel: "여행 일기",
  food: "식사 일기",
  study: "학습 일기",
  work: "업무 일기",
  health: "건강 일기",
  reflection: "성찰 일기",
}

export default function DiaryList() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [searchTerm, setSearchTerm] = useState("")

  // 필터링된 일기 목록
  const filteredDiaries = diaryEntries.filter((diary) => {
    const matchesSearch =
      diary.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      diary.preview.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesDate = selectedDate ? diary.date === format(selectedDate, "yyyy-MM-dd") : true

    return matchesSearch && matchesDate
  })

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>일기 목록</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="일기 검색..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            className="rounded-md border"
            locale={ko}
          />

          <div className="flex justify-between items-center">
            <div className="text-sm text-muted-foreground">
              {selectedDate ? format(selectedDate, "yyyy년 MM월 dd일", { locale: ko }) : "모든 날짜"}
            </div>
            <Button variant="outline" size="sm" onClick={() => setSelectedDate(undefined)}>
              <CalendarIcon className="h-4 w-4 mr-2" />
              전체 보기
            </Button>
          </div>

          <div className="space-y-2">
            {filteredDiaries.length > 0 ? (
              filteredDiaries.map((diary) => (
                <div key={diary.id} className="p-3 border rounded-md cursor-pointer hover:bg-muted/50">
                  <div className="flex justify-between items-start mb-1">
                    <div className="font-medium">{diary.title}</div>
                    <div className="text-2xl" title={diary.emotion}>
                      {emotionEmojis[diary.emotion] || "😊"}
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground mb-2">
                    {format(parseISO(diary.date), "yyyy년 MM월 dd일", { locale: ko })}
                  </div>
                  <Badge variant="outline" className="mb-2">
                    {sectionLabels[diary.section] || diary.section}
                  </Badge>
                  <div className="text-sm line-clamp-2">{diary.preview}</div>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                {searchTerm ? "검색 결과가 없습니다." : "해당 날짜에 일기가 없습니다."}
              </div>
            )}
          </div>

          <Button className="w-full">
            <Plus className="h-4 w-4 mr-2" />새 일기 작성
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

