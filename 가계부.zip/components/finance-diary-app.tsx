"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Dashboard from "@/components/dashboard"
import Ledger from "@/components/ledger"
import TransactionManager from "@/components/transaction-manager"
import Reports from "@/components/reports"
import Settings from "@/components/settings"
import CalendarView from "@/components/calendar-view"
import RecurringTransactions from "@/components/recurring-transactions"
import CategoryMenu from "@/components/category-menu"
import OCRScanner from "@/components/ocr-scanner"
import AccountSync from "@/components/account-sync"
import AIInsights from "@/components/ai-insights"
import DiaryApp from "@/components/diary-app"
import ThemeSwitcher from "@/components/theme-switcher"
import AdBanner from "@/components/ad-banner"
import LoginButton from "@/components/login-button"
import { Button } from "@/components/ui/button"
import { Calendar, Grid3X3, LayoutDashboard, BookOpen } from "lucide-react"

export default function FinanceDiaryApp() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [showDiary, setShowDiary] = useState(false)

  // 일기장 모드와 메인 앱 모드 전환
  const toggleDiaryMode = () => {
    setShowDiary(!showDiary)
  }

  return (
    <div className="space-y-4">
      {/* 상단 헤더 - 광고 배너와 로그인 버튼 */}
      <div className="flex flex-col gap-2">
        <AdBanner />
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">자동 전산 프로그램</h1>
          <div className="flex items-center gap-2">
            <LoginButton />
            <ThemeSwitcher />
          </div>
        </div>
      </div>

      {showDiary ? (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">일기장</h2>
            <Button variant="outline" onClick={toggleDiaryMode}>
              <LayoutDashboard className="mr-2 h-4 w-4" />
              메인으로 돌아가기
            </Button>
          </div>
          <DiaryApp />
        </div>
      ) : (
        <>
          {/* 메인 앱 모드 */}
          <div className="flex gap-2 mb-4">
            <Button
              variant={activeTab === "dashboard" ? "default" : "outline"}
              onClick={() => setActiveTab("dashboard")}
              className="flex-1"
            >
              <LayoutDashboard className="mr-2 h-4 w-4" />
              대시보드
            </Button>
            <Button
              variant={activeTab === "calendar" ? "default" : "outline"}
              onClick={() => setActiveTab("calendar")}
              className="flex-1"
            >
              <Calendar className="mr-2 h-4 w-4" />
              캘린더
            </Button>
            <Button variant="outline" onClick={toggleDiaryMode} className="flex-1">
              <BookOpen className="mr-2 h-4 w-4" />
              일기장
            </Button>
            <Button
              variant={activeTab === "menu" ? "default" : "outline"}
              onClick={() => setActiveTab("menu")}
              className="flex-1"
            >
              <Grid3X3 className="mr-2 h-4 w-4" />
              전체 메뉴
            </Button>
          </div>

          {activeTab === "dashboard" && <Dashboard />}
          {activeTab === "calendar" && <CalendarView />}
          {activeTab === "menu" && (
            <Tabs value="ledger" className="w-full">
              <TabsList className="grid w-full grid-cols-12">
                <TabsTrigger value="ledger">가계부</TabsTrigger>
                <TabsTrigger value="transactions">매입/매출</TabsTrigger>
                <TabsTrigger value="recurring">정기 거래</TabsTrigger>
                <TabsTrigger value="category">카테고리</TabsTrigger>
                <TabsTrigger value="ocr">영수증 스캔</TabsTrigger>
                <TabsTrigger value="account-sync">계좌 연동</TabsTrigger>
                <TabsTrigger value="ai-insights">AI 인사이트</TabsTrigger>
                <TabsTrigger value="reports">보고서</TabsTrigger>
                <TabsTrigger value="settings">설정</TabsTrigger>
              </TabsList>

              <TabsContent value="ledger">
                <Ledger />
              </TabsContent>

              <TabsContent value="transactions">
                <TransactionManager />
              </TabsContent>

              <TabsContent value="recurring">
                <RecurringTransactions />
              </TabsContent>

              <TabsContent value="category">
                <CategoryMenu />
              </TabsContent>

              <TabsContent value="ocr">
                <OCRScanner />
              </TabsContent>

              <TabsContent value="account-sync">
                <AccountSync />
              </TabsContent>

              <TabsContent value="ai-insights">
                <AIInsights />
              </TabsContent>

              <TabsContent value="reports">
                <Reports />
              </TabsContent>

              <TabsContent value="settings">
                <Settings />
              </TabsContent>
            </Tabs>
          )}
        </>
      )}
    </div>
  )
}

