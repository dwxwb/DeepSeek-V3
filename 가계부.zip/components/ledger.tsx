"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  CalendarIcon,
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameDay,
  addMonths,
  subMonths,
  parseISO,
  isToday,
} from "date-fns"
import { ko } from "date-fns/locale"
import type { Category } from "@/lib/category-data"
import CategorySelector from "./category-selector"

// 가상의 가계부 데이터
const ledgerData = [
  {
    id: 1,
    date: "2024-03-28",
    category: "식비",
    categoryEmoji: "🍽️",
    description: "점심 식사",
    amount: -12000,
    paymentMethod: "신용카드",
    memo: "",
  },
  {
    id: 2,
    date: "2024-03-27",
    category: "교통",
    categoryEmoji: "🚌",
    description: "지하철 요금",
    amount: -1500,
    paymentMethod: "교통카드",
    memo: "출근",
  },
  {
    id: 3,
    date: "2024-03-26",
    category: "쇼핑",
    categoryEmoji: "🛒",
    description: "생필품 구매",
    amount: -35000,
    paymentMethod: "체크카드",
    memo: "샴푸, 치약 등",
  },
  {
    id: 4,
    date: "2024-03-25",
    category: "급여",
    categoryEmoji: "💰",
    description: "3월 급여",
    amount: 2500000,
    paymentMethod: "계좌이체",
    memo: "",
  },
  {
    id: 5,
    date: "2024-03-24",
    category: "통신",
    categoryEmoji: "📱",
    description: "휴대폰 요금",
    amount: -55000,
    paymentMethod: "자동이체",
    memo: "",
  },
]

export default function Ledger() {
  const [activeTab, setActiveTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState(0)
  const [paymentMethod, setPaymentMethod] = useState("신용카드")
  const [memo, setMemo] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null)
  const [editingItemId, setEditingItemId] = useState<number | null>(null)
  const [ledgerItems, setLedgerItems] = useState(ledgerData)
  const [calendarDate, setCalendarDate] = useState<Date>(new Date())
  const [viewMode, setViewMode] = useState<"list" | "calendar">("list")

  // 필터링된 데이터
  const filteredData = ledgerItems.filter((item) => {
    // 탭 필터링
    if (activeTab === "income" && item.amount <= 0) return false
    if (activeTab === "expense" && item.amount >= 0) return false

    // 검색어 필터링
    return (
      item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.memo.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  // 캘린더 관련 함수
  const monthStart = startOfMonth(calendarDate)
  const monthEnd = endOfMonth(calendarDate)
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd })

  // 날짜별 거래 데이터 그룹화
  const getTransactionsForDate = (day: Date) => {
    return ledgerItems.filter((item) => {
      const itemDate = parseISO(item.date)
      return isSameDay(itemDate, day)
    })
  }

  // 날짜별 총 금액 계산
  const getTotalForDate = (day: Date, type: "income" | "expense" | "all") => {
    const dayTransactions = getTransactionsForDate(day)

    if (type === "all") {
      return dayTransactions.reduce((sum, item) => sum + item.amount, 0)
    } else if (type === "income") {
      return dayTransactions.filter((item) => item.amount > 0).reduce((sum, item) => sum + item.amount, 0)
    } else {
      return dayTransactions.filter((item) => item.amount < 0).reduce((sum, item) => sum + item.amount, 0)
    }
  }

  // 월별 총 금액 계산
  const getTotalForMonth = (month: Date, type: "income" | "expense" | "all") => {
    const monthItems = ledgerItems.filter((item) => {
      const itemDate = parseISO(item.date)
      return itemDate.getMonth() === month.getMonth() && itemDate.getFullYear() === month.getFullYear()
    })

    if (type === "all") {
      return monthItems.reduce((sum, item) => sum + item.amount, 0)
    } else if (type === "income") {
      return monthItems.filter((item) => item.amount > 0).reduce((sum, item) => sum + item.amount, 0)
    } else {
      return monthItems.filter((item) => item.amount < 0).reduce((sum, item) => sum + item.amount, 0)
    }
  }

  // 이전 달로 이동
  const goToPreviousMonth = () => {
    setCalendarDate(subMonths(calendarDate, 1))
  }

  // 다음 달로 이동
  const goToNextMonth = () => {
    setCalendarDate(addMonths(calendarDate, 1))
  }

  // 오늘로 이동
  const goToToday = () => {
    setCalendarDate(new Date())
  }

  // 카테고리 선택 처리
  const handleCategorySelect = (category: Category, categoryAmount?: number) => {
    setSelectedCategory(category)
    if (categoryAmount !== undefined) {
      setAmount(categoryAmount)
    }
    setIsCategoryDialogOpen(false)
  }

  // 항목 추가
  const handleAddItem = () => {
    if (!selectedCategory || !description || !selectedDate) {
      alert("필수 항목을 모두 입력해주세요.")
      return
    }

    const newItem = {
      id: Date.now(),
      date: format(selectedDate, "yyyy-MM-dd"),
      category: selectedCategory.name,
      categoryEmoji: selectedCategory.emoji,
      description,
      amount: activeTab === "expense" ? -Math.abs(amount) : Math.abs(amount),
      paymentMethod,
      memo,
    }

    setLedgerItems([newItem, ...ledgerItems])
    resetForm()
    setIsAddDialogOpen(false)
  }

  // 항목 수정
  const handleEditItem = (id: number) => {
    const item = ledgerItems.find((item) => item.id === id)
    if (!item) return

    setEditingItemId(id)
    setSelectedDate(new Date(item.date))
    setDescription(item.description)
    setAmount(Math.abs(item.amount))
    setPaymentMethod(item.paymentMethod)
    setMemo(item.memo)
    setActiveTab(item.amount >= 0 ? "income" : "expense")
    setIsEditDialogOpen(true)
  }

  // 수정 저장
  const handleSaveEdit = () => {
    if (!selectedCategory || !description || !selectedDate) {
      alert("필수 항목을 모두 입력해주세요.")
      return
    }

    const updatedItems = ledgerItems.map((item) => {
      if (item.id === editingItemId) {
        return {
          ...item,
          date: format(selectedDate, "yyyy-MM-dd"),
          category: selectedCategory.name,
          categoryEmoji: selectedCategory.emoji,
          description,
          amount: activeTab === "expense" ? -Math.abs(amount) : Math.abs(amount),
          paymentMethod,
          memo,
        }
      }
      return item
    })

    setLedgerItems(updatedItems)
    resetForm()
    setIsEditDialogOpen(false)
    setEditingItemId(null)
  }

  // 항목 삭제
  const handleDeleteItem = (id: number) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      setLedgerItems(ledgerItems.filter((item) => item.id !== id))
    }
  }

  // 폼 초기화
  const resetForm = () => {
    setSelectedDate(new Date())
    setSelectedCategory(null)
    setDescription("")
    setAmount(0)
    setPaymentMethod("신용카드")
    setMemo("")
  }

  // 새 항목 추가 다이얼로그 열기
  const openAddDialog = (type: "income" | "expense") => {
    setActiveTab(type)
    resetForm()
    setIsAddDialogOpen(true)
  }

  return (
    <div className="space-y-4">
      {/* 상단 캘린더 메뉴 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>가계부 캘린더</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" onClick={goToToday}>
                오늘
              </Button>
              <div className="flex">
                <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={goToNextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          <CardDescription>{format(calendarDate, "yyyy년 MM월", { locale: ko })}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 grid grid-cols-3 gap-4">
            <div className="flex flex-col p-3 border rounded-md">
              <div className="text-lg font-bold">수입</div>
              <div className="text-2xl font-bold text-green-600">
                {getTotalForMonth(calendarDate, "income").toLocaleString()}원
              </div>
            </div>
            <div className="flex flex-col p-3 border rounded-md">
              <div className="text-lg font-bold">지출</div>
              <div className="text-2xl font-bold text-red-600">
                {Math.abs(getTotalForMonth(calendarDate, "expense")).toLocaleString()}원
              </div>
            </div>
            <div className="flex flex-col p-3 border rounded-md">
              <div className="text-lg font-bold">잔액</div>
              <div
                className={`text-2xl font-bold ${getTotalForMonth(calendarDate, "all") >= 0 ? "text-green-600" : "text-red-600"}`}
              >
                {getTotalForMonth(calendarDate, "all").toLocaleString()}원
              </div>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {["일", "월", "화", "수", "목", "금", "토"].map((day) => (
              <div key={day} className="text-center font-medium py-2">
                {day}
              </div>
            ))}

            {daysInMonth.map((day, i) => {
              const dayTransactions = getTransactionsForDate(day)
              const incomeTotal = getTotalForDate(day, "income")
              const expenseTotal = getTotalForDate(day, "expense")
              const hasTransactions = dayTransactions.length > 0

              // 첫 번째 날의 요일에 맞게 빈 셀 추가
              const startOffset = i === 0 ? day.getDay() : 0
              const offsetCells = i === 0 ? Array(startOffset).fill(null) : []

              return (
                <>
                  {i === 0 &&
                    offsetCells.map((_, index) => (
                      <div key={`offset-${index}`} className="p-1 border rounded-md bg-muted/20"></div>
                    ))}
                  <div
                    key={day.toString()}
                    className={`p-1 border rounded-md min-h-[100px] cursor-pointer hover:bg-muted/20 ${
                      isToday(day) ? "border-primary" : ""
                    }`}
                  >
                    <div
                      className={`text-right font-medium p-1 ${
                        day.getDay() === 0 ? "text-red-500" : day.getDay() === 6 ? "text-blue-500" : ""
                      }`}
                    >
                      {format(day, "d")}
                    </div>

                    {hasTransactions && (
                      <div className="space-y-1 p-1">
                        {incomeTotal > 0 && (
                          <div className="text-xs text-green-600">수입: {incomeTotal.toLocaleString()}원</div>
                        )}
                        {expenseTotal < 0 && (
                          <div className="text-xs text-red-600">지출: {Math.abs(expenseTotal).toLocaleString()}원</div>
                        )}
                        <div className="text-xs">{dayTransactions.length}건의 거래</div>
                      </div>
                    )}
                  </div>
                </>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* 기존 가계부 카드 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>가계부</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => openAddDialog("expense")}>
                <Plus className="h-4 w-4 mr-1" /> 지출 추가
              </Button>
              <Button onClick={() => openAddDialog("income")}>
                <Plus className="h-4 w-4 mr-1" /> 수입 추가
              </Button>
            </div>
          </div>
          <CardDescription>일상 지출과 수입을 기록하고 관리하세요</CardDescription>
          <div className="flex justify-between items-center mt-2">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="검색..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2 ml-2">
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ArrowUpDown className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="all">전체</TabsTrigger>
              <TabsTrigger value="expense">지출</TabsTrigger>
              <TabsTrigger value="income">수입</TabsTrigger>
            </TabsList>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>날짜</TableHead>
                  <TableHead>카테고리</TableHead>
                  <TableHead>내용</TableHead>
                  <TableHead>결제수단</TableHead>
                  <TableHead className="text-right">금액</TableHead>
                  <TableHead className="text-right">관리</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      데이터가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.date}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span role="img" aria-label={item.category}>
                            {item.categoryEmoji}
                          </span>
                          <span>{item.category}</span>
                        </div>
                      </TableCell>
                      <TableCell>{item.description}</TableCell>
                      <TableCell>{item.paymentMethod}</TableCell>
                      <TableCell
                        className={`text-right font-medium ${item.amount < 0 ? "text-red-600" : "text-green-600"}`}
                      >
                        {item.amount.toLocaleString()}원
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" onClick={() => handleEditItem(item.id)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteItem(item.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">총 {filteredData.length}개 항목</div>
          <div className="flex gap-4">
            <div>
              <span className="text-sm text-muted-foreground mr-1">총 수입:</span>
              <span className="font-medium text-green-600">
                {filteredData
                  .filter((item) => item.amount > 0)
                  .reduce((sum, item) => sum + item.amount, 0)
                  .toLocaleString()}
                원
              </span>
            </div>
            <div>
              <span className="text-sm text-muted-foreground mr-1">총 지출:</span>
              <span className="font-medium text-red-600">
                {filteredData
                  .filter((item) => item.amount < 0)
                  .reduce((sum, item) => sum + item.amount, 0)
                  .toLocaleString()}
                원
              </span>
            </div>
          </div>
        </CardFooter>
      </Card>

      {/* 새 항목 추가 다이얼로그 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{activeTab === "expense" ? "지출 추가" : "수입 추가"}</DialogTitle>
            <DialogDescription>
              {activeTab === "expense" ? "새로운 지출 내역을 추가하세요" : "새로운 수입 내역을 추가하세요"}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="date">날짜</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP", { locale: ko }) : "날짜 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} locale={ko} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="category">카테고리</Label>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsCategoryDialogOpen(true)}
              >
                {selectedCategory ? (
                  <div className="flex items-center gap-2">
                    <span role="img" aria-label={selectedCategory.name}>
                      {selectedCategory.emoji}
                    </span>
                    <span>{selectedCategory.name}</span>
                  </div>
                ) : (
                  "카테고리 선택"
                )}
              </Button>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">내용</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="내용을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="amount">금액</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="금액을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="payment-method">결제 수단</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger id="payment-method">
                  <SelectValue placeholder="결제 수단 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="현금">현금</SelectItem>
                  <SelectItem value="신용카드">신용카드</SelectItem>
                  <SelectItem value="체크카드">체크카드</SelectItem>
                  <SelectItem value="계좌이체">계좌이체</SelectItem>
                  <SelectItem value="자동이체">자동이체</SelectItem>
                  <SelectItem value="교통카드">교통카드</SelectItem>
                  <SelectItem value="기타">기타</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="memo">메모</Label>
              <Input
                id="memo"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                placeholder="메모를 입력하세요 (선택사항)"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              취소
            </Button>
            <Button onClick={handleAddItem}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 항목 수정 다이얼로그 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>항목 수정</DialogTitle>
            <DialogDescription>가계부 항목 정보를 수정하세요</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-date">날짜</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP", { locale: ko }) : "날짜 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} locale={ko} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-category">카테고리</Label>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsCategoryDialogOpen(true)}
              >
                {selectedCategory ? (
                  <div className="flex items-center gap-2">
                    <span role="img" aria-label={selectedCategory.name}>
                      {selectedCategory.emoji}
                    </span>
                    <span>{selectedCategory.name}</span>
                  </div>
                ) : (
                  "카테고리 선택"
                )}
              </Button>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-description">내용</Label>
              <Input
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="내용을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-amount">금액</Label>
              <Input
                id="edit-amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="금액을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-payment-method">결제 수단</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger id="edit-payment-method">
                  <SelectValue placeholder="결제 수단 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="현금">현금</SelectItem>
                  <SelectItem value="신용카드">신용카드</SelectItem>
                  <SelectItem value="체크카드">체크카드</SelectItem>
                  <SelectItem value="계좌이체">계좌이체</SelectItem>
                  <SelectItem value="자동이체">자동이체</SelectItem>
                  <SelectItem value="교통카드">교통카드</SelectItem>
                  <SelectItem value="기타">기타</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-memo">메모</Label>
              <Input
                id="edit-memo"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                placeholder="메모를 입력하세요 (선택사항)"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="destructive"
              onClick={() => {
                if (editingItemId) handleDeleteItem(editingItemId)
                setIsEditDialogOpen(false)
              }}
            >
              삭제
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                취소
              </Button>
              <Button onClick={handleSaveEdit}>저장</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 카테고리 선택 다이얼로그 */}
      <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>카테고리 선택</DialogTitle>
            <DialogDescription>
              {activeTab === "expense" ? "지출 카테고리를 선택하세요" : "수입 카테고리를 선택하세요"}
            </DialogDescription>
          </DialogHeader>

          <CategorySelector
            onSelectCategory={handleCategorySelect}
            initialAmount={amount}
            title={activeTab === "expense" ? "지출 카테고리" : "수입 카테고리"}
            description={activeTab === "expense" ? "지출 카테고리를 선택하세요" : "수입 카테고리를 선택하세요"}
          />

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCategoryDialogOpen(false)}>
              취소
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

