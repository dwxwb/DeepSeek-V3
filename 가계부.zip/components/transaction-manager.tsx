"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  CalendarIcon,
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  Edit,
  Trash2,
  FileText,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameDay,
  addMonths,
  subMonths,
  parseISO,
  isToday,
} from "date-fns"
import { ko } from "date-fns/locale"
import type { Category } from "@/lib/category-data"
import CategorySelector from "./category-selector"

// 가상의 매입/매출 데이터
const transactionData = [
  {
    id: 1,
    date: "2024-03-28",
    type: "매출",
    category: "판매",
    categoryEmoji: "🛒",
    customer: "홍길동",
    description: "제품 판매",
    amount: 150000,
    taxRate: 10,
    taxAmount: 15000,
    totalAmount: 165000,
    paymentMethod: "신용카드",
    memo: "정기 고객",
  },
  {
    id: 2,
    date: "2024-03-27",
    type: "매입",
    category: "소모품",
    categoryEmoji: "🖊️",
    customer: "문구점",
    description: "사무용품 구매",
    amount: 45000,
    taxRate: 10,
    taxAmount: 4500,
    totalAmount: 49500,
    paymentMethod: "체크카드",
    memo: "종이, 펜 등",
  },
  {
    id: 3,
    date: "2024-03-26",
    type: "매출",
    category: "서비스",
    categoryEmoji: "🔧",
    customer: "김철수",
    description: "서비스 제공",
    amount: 200000,
    taxRate: 10,
    taxAmount: 20000,
    totalAmount: 220000,
    paymentMethod: "계좌이체",
    memo: "",
  },
  {
    id: 4,
    date: "2024-03-25",
    type: "매입",
    category: "식비",
    categoryEmoji: "🍽️",
    customer: "식당",
    description: "직원 식대",
    amount: 85000,
    taxRate: 10,
    taxAmount: 8500,
    totalAmount: 93500,
    paymentMethod: "법인카드",
    memo: "회식",
  },
  {
    id: 5,
    date: "2024-03-24",
    type: "매출",
    category: "판매",
    categoryEmoji: "🛒",
    customer: "이영희",
    description: "제품 판매",
    amount: 120000,
    taxRate: 10,
    taxAmount: 12000,
    totalAmount: 132000,
    paymentMethod: "현금",
    memo: "",
  },
]

export default function TransactionManager() {
  const [activeTab, setActiveTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [transactionType, setTransactionType] = useState<"매입" | "매출">("매출")
  const [customer, setCustomer] = useState("")
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState(0)
  const [taxRate, setTaxRate] = useState(10)
  const [paymentMethod, setPaymentMethod] = useState("신용카드")
  const [memo, setMemo] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null)
  const [editingItemId, setEditingItemId] = useState<number | null>(null)
  const [transactions, setTransactions] = useState(transactionData)
  const [calendarDate, setCalendarDate] = useState<Date>(new Date())

  // 필터링된 데이터
  const filteredData = transactions.filter((item) => {
    // 탭 필터링
    if (activeTab === "sales" && item.type !== "매출") return false
    if (activeTab === "purchase" && item.type !== "매입") return false

    // 검색어 필터링
    return (
      item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.memo.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  // 캘린더 관련 함수
  const monthStart = startOfMonth(calendarDate)
  const monthEnd = endOfMonth(calendarDate)
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd })

  // 날짜별 거래 데이터 그룹화
  const getTransactionsForDate = (day: Date) => {
    return transactions.filter((item) => {
      const itemDate = parseISO(item.date)
      return isSameDay(itemDate, day)
    })
  }

  // 날짜별 매출/매입 금액 계산
  const getTotalForDate = (day: Date, type: "매출" | "매입" | "all") => {
    const dayTransactions = getTransactionsForDate(day)

    if (type === "all") {
      return dayTransactions.reduce((sum, item) => sum + item.totalAmount, 0)
    } else if (type === "매출") {
      return dayTransactions.filter((item) => item.type === "매출").reduce((sum, item) => sum + item.totalAmount, 0)
    } else {
      return dayTransactions.filter((item) => item.type === "매입").reduce((sum, item) => sum + item.totalAmount, 0)
    }
  }

  // 월별 매출/매입 금액 계산
  const getTotalForMonth = (month: Date, type: "매출" | "매입" | "all") => {
    const monthItems = transactions.filter((item) => {
      const itemDate = parseISO(item.date)
      return itemDate.getMonth() === month.getMonth() && itemDate.getFullYear() === month.getFullYear()
    })

    if (type === "all") {
      return monthItems.reduce((sum, item) => sum + item.totalAmount, 0)
    } else if (type === "매출") {
      return monthItems.filter((item) => item.type === "매출").reduce((sum, item) => sum + item.totalAmount, 0)
    } else {
      return monthItems.filter((item) => item.type === "매입").reduce((sum, item) => sum + item.totalAmount, 0)
    }
  }

  // 이전 달로 이동
  const goToPreviousMonth = () => {
    setCalendarDate(subMonths(calendarDate, 1))
  }

  // 다음 달로 이동
  const goToNextMonth = () => {
    setCalendarDate(addMonths(calendarDate, 1))
  }

  // 오늘로 이동
  const goToToday = () => {
    setCalendarDate(new Date())
  }

  // 세금 계산
  const calculateTax = (baseAmount: number, rate: number) => {
    return Math.round(baseAmount * (rate / 100))
  }

  // 카테고리 선택 처리
  const handleCategorySelect = (category: Category, categoryAmount?: number) => {
    setSelectedCategory(category)
    if (categoryAmount !== undefined) {
      setAmount(categoryAmount)
    }
    setIsCategoryDialogOpen(false)
  }

  // 항목 추가
  const handleAddItem = () => {
    if (!selectedCategory || !description || !customer || !selectedDate) {
      alert("필수 항목을 모두 입력해주세요.")
      return
    }

    const taxAmount = calculateTax(amount, taxRate)
    const totalAmount = amount + taxAmount

    const newItem = {
      id: Date.now(),
      date: format(selectedDate, "yyyy-MM-dd"),
      type: transactionType,
      category: selectedCategory.name,
      categoryEmoji: selectedCategory.emoji,
      customer,
      description,
      amount,
      taxRate,
      taxAmount,
      totalAmount,
      paymentMethod,
      memo,
    }

    setTransactions([newItem, ...transactions])
    resetForm()
    setIsAddDialogOpen(false)
  }

  // 항목 수정
  const handleEditItem = (id: number) => {
    const item = transactions.find((item) => item.id === id)
    if (!item) return

    setEditingItemId(id)
    setSelectedDate(new Date(item.date))
    setTransactionType(item.type as "매입" | "매출")
    setCustomer(item.customer)
    setDescription(item.description)
    setAmount(item.amount)
    setTaxRate(item.taxRate)
    setPaymentMethod(item.paymentMethod)
    setMemo(item.memo)
    setIsEditDialogOpen(true)
  }

  // 수정 저장
  const handleSaveEdit = () => {
    if (!selectedCategory || !description || !customer || !selectedDate) {
      alert("필수 항목을 모두 입력해주세요.")
      return
    }

    const taxAmount = calculateTax(amount, taxRate)
    const totalAmount = amount + taxAmount

    const updatedItems = transactions.map((item) => {
      if (item.id === editingItemId) {
        return {
          ...item,
          date: format(selectedDate, "yyyy-MM-dd"),
          type: transactionType,
          category: selectedCategory.name,
          categoryEmoji: selectedCategory.emoji,
          customer,
          description,
          amount,
          taxRate,
          taxAmount,
          totalAmount,
          paymentMethod,
          memo,
        }
      }
      return item
    })

    setTransactions(updatedItems)
    resetForm()
    setIsEditDialogOpen(false)
    setEditingItemId(null)
  }

  // 항목 삭제
  const handleDeleteItem = (id: number) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      setTransactions(transactions.filter((item) => item.id !== id))
    }
  }

  // 폼 초기화
  const resetForm = () => {
    setSelectedDate(new Date())
    setSelectedCategory(null)
    setCustomer("")
    setDescription("")
    setAmount(0)
    setTaxRate(10)
    setPaymentMethod("신용카드")
    setMemo("")
  }

  // 새 항목 추가 다이얼로그 열기
  const openAddDialog = (type: "매입" | "매출") => {
    setTransactionType(type)
    resetForm()
    setIsAddDialogOpen(true)
  }

  return (
    <div className="space-y-4">
      {/* 상단 캘린더 메뉴 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>매입/매출 캘린더</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" onClick={goToToday}>
                오늘
              </Button>
              <div className="flex">
                <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={goToNextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          <CardDescription>{format(calendarDate, "yyyy년 MM월", { locale: ko })}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 grid grid-cols-3 gap-4">
            <div className="flex flex-col p-3 border rounded-md">
              <div className="text-lg font-bold">매출</div>
              <div className="text-2xl font-bold text-red-600">
                {getTotalForMonth(calendarDate, "매출").toLocaleString()}원
              </div>
            </div>
            <div className="flex flex-col p-3 border rounded-md">
              <div className="text-lg font-bold">매입</div>
              <div className="text-2xl font-bold text-blue-600">
                {getTotalForMonth(calendarDate, "매입").toLocaleString()}원
              </div>
            </div>
            <div className="flex flex-col p-3 border rounded-md">
              <div className="text-lg font-bold">순이익</div>
              <div
                className={`text-2xl font-bold ${
                  getTotalForMonth(calendarDate, "매출") - getTotalForMonth(calendarDate, "매입") >= 0
                    ? "text-green-600"
                    : "text-red-600"
                }`}
              >
                {(getTotalForMonth(calendarDate, "매출") - getTotalForMonth(calendarDate, "매입")).toLocaleString()}원
              </div>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {["일", "월", "화", "수", "목", "금", "토"].map((day) => (
              <div key={day} className="text-center font-medium py-2">
                {day}
              </div>
            ))}

            {daysInMonth.map((day, i) => {
              const dayTransactions = getTransactionsForDate(day)
              const salesTotal = getTotalForDate(day, "매출")
              const purchaseTotal = getTotalForDate(day, "매입")
              const hasTransactions = dayTransactions.length > 0

              // 첫 번째 날의 요일에 맞게 빈 셀 추가
              const startOffset = i === 0 ? day.getDay() : 0
              const offsetCells = i === 0 ? Array(startOffset).fill(null) : []

              return (
                <>
                  {i === 0 &&
                    offsetCells.map((_, index) => (
                      <div key={`offset-${index}`} className="p-1 border rounded-md bg-muted/20"></div>
                    ))}
                  <div
                    key={day.toString()}
                    className={`p-1 border rounded-md min-h-[100px] cursor-pointer hover:bg-muted/20 ${
                      isToday(day) ? "border-primary" : ""
                    }`}
                  >
                    <div
                      className={`text-right font-medium p-1 ${
                        day.getDay() === 0 ? "text-red-500" : day.getDay() === 6 ? "text-blue-500" : ""
                      }`}
                    >
                      {format(day, "d")}
                    </div>

                    {hasTransactions && (
                      <div className="space-y-1 p-1">
                        {salesTotal > 0 && (
                          <div className="text-xs text-red-600">매출: {salesTotal.toLocaleString()}원</div>
                        )}
                        {purchaseTotal > 0 && (
                          <div className="text-xs text-blue-600">매입: {purchaseTotal.toLocaleString()}원</div>
                        )}
                        <div className="text-xs">{dayTransactions.length}건의 거래</div>
                      </div>
                    )}
                  </div>
                </>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* 기존 매입/매출 카드 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>매입/매출 관리</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => openAddDialog("매입")}>
                <Plus className="h-4 w-4 mr-1" /> 매입 추가
              </Button>
              <Button onClick={() => openAddDialog("매출")}>
                <Plus className="h-4 w-4 mr-1" /> 매출 추가
              </Button>
            </div>
          </div>
          <CardDescription>사업 매입과 매출을 기록하고 관리하세요</CardDescription>
          <div className="flex justify-between items-center mt-2">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="검색..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2 ml-2">
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ArrowUpDown className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <FileText className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="all">전체</TabsTrigger>
              <TabsTrigger value="sales">매출</TabsTrigger>
              <TabsTrigger value="purchase">매입</TabsTrigger>
            </TabsList>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>날짜</TableHead>
                  <TableHead>구분</TableHead>
                  <TableHead>카테고리</TableHead>
                  <TableHead>거래처</TableHead>
                  <TableHead>내용</TableHead>
                  <TableHead className="text-right">공급가액</TableHead>
                  <TableHead className="text-right">세액</TableHead>
                  <TableHead className="text-right">합계</TableHead>
                  <TableHead className="text-right">관리</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                      데이터가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.date}</TableCell>
                      <TableCell>
                        <Badge variant={item.type === "매출" ? "default" : "secondary"}>{item.type}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span role="img" aria-label={item.category}>
                            {item.categoryEmoji}
                          </span>
                          <span>{item.category}</span>
                        </div>
                      </TableCell>
                      <TableCell>{item.customer}</TableCell>
                      <TableCell>{item.description}</TableCell>
                      <TableCell className="text-right font-medium">{item.amount.toLocaleString()}원</TableCell>
                      <TableCell className="text-right">{item.taxAmount.toLocaleString()}원</TableCell>
                      <TableCell className="text-right font-medium">{item.totalAmount.toLocaleString()}원</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" onClick={() => handleEditItem(item.id)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteItem(item.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">총 {filteredData.length}개 항목</div>
          <div className="flex gap-4">
            <div>
              <span className="text-sm text-muted-foreground mr-1">총 매출:</span>
              <span className="font-medium text-green-600">
                {filteredData
                  .filter((item) => item.type === "매출")
                  .reduce((sum, item) => sum + item.totalAmount, 0)
                  .toLocaleString()}
                원
              </span>
            </div>
            <div>
              <span className="text-sm text-muted-foreground mr-1">총 매입:</span>
              <span className="font-medium text-red-600">
                {filteredData
                  .filter((item) => item.type === "매입")
                  .reduce((sum, item) => sum + item.totalAmount, 0)
                  .toLocaleString()}
                원
              </span>
            </div>
          </div>
        </CardFooter>
      </Card>

      {/* 새 항목 추가 다이얼로그 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{transactionType} 추가</DialogTitle>
            <DialogDescription>새로운 {transactionType} 내역을 추가하세요</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="date">날짜</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP", { locale: ko }) : "날짜 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} locale={ko} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="category">카테고리</Label>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsCategoryDialogOpen(true)}
              >
                {selectedCategory ? (
                  <div className="flex items-center gap-2">
                    <span role="img" aria-label={selectedCategory.name}>
                      {selectedCategory.emoji}
                    </span>
                    <span>{selectedCategory.name}</span>
                  </div>
                ) : (
                  "카테고리 선택"
                )}
              </Button>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="customer">거래처</Label>
              <Input
                id="customer"
                value={customer}
                onChange={(e) => setCustomer(e.target.value)}
                placeholder="거래처를 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">내용</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="내용을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="amount">공급가액</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="공급가액을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="tax-rate">세율 (%)</Label>
              <Input
                id="tax-rate"
                type="number"
                value={taxRate}
                onChange={(e) => setTaxRate(Number(e.target.value))}
                placeholder="세율을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label>세액</Label>
              <div className="p-2 bg-muted rounded-md text-right font-medium">
                {calculateTax(amount, taxRate).toLocaleString()}원
              </div>
            </div>

            <div className="grid gap-2">
              <Label>합계</Label>
              <div className="p-2 bg-muted rounded-md text-right font-medium">
                {(amount + calculateTax(amount, taxRate)).toLocaleString()}원
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="payment-method">결제 수단</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger id="payment-method">
                  <SelectValue placeholder="결제 수단 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="현금">현금</SelectItem>
                  <SelectItem value="신용카드">신용카드</SelectItem>
                  <SelectItem value="체크카드">체크카드</SelectItem>
                  <SelectItem value="계좌이체">계좌이체</SelectItem>
                  <SelectItem value="법인카드">법인카드</SelectItem>
                  <SelectItem value="어음">어음</SelectItem>
                  <SelectItem value="기타">기타</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="memo">메모</Label>
              <Input
                id="memo"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                placeholder="메모를 입력하세요 (선택사항)"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              취소
            </Button>
            <Button onClick={handleAddItem}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 항목 수정 다이얼로그 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>항목 수정</DialogTitle>
            <DialogDescription>매입/매출 항목 정보를 수정하세요</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-date">날짜</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP", { locale: ko }) : "날짜 선택"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} locale={ko} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-type">구분</Label>
              <Select value={transactionType} onValueChange={(value) => setTransactionType(value as "매입" | "매출")}>
                <SelectTrigger id="edit-type">
                  <SelectValue placeholder="구분 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="매출">매출</SelectItem>
                  <SelectItem value="매입">매입</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-category">카테고리</Label>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsCategoryDialogOpen(true)}
              >
                {selectedCategory ? (
                  <div className="flex items-center gap-2">
                    <span role="img" aria-label={selectedCategory.name}>
                      {selectedCategory.emoji}
                    </span>
                    <span>{selectedCategory.name}</span>
                  </div>
                ) : (
                  "카테고리 선택"
                )}
              </Button>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-customer">거래처</Label>
              <Input
                id="edit-customer"
                value={customer}
                onChange={(e) => setCustomer(e.target.value)}
                placeholder="거래처를 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-description">내용</Label>
              <Input
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="내용을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-amount">공급가액</Label>
              <Input
                id="edit-amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="공급가액을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-tax-rate">세율 (%)</Label>
              <Input
                id="edit-tax-rate"
                type="number"
                value={taxRate}
                onChange={(e) => setTaxRate(Number(e.target.value))}
                placeholder="세율을 입력하세요"
              />
            </div>

            <div className="grid gap-2">
              <Label>세액</Label>
              <div className="p-2 bg-muted rounded-md text-right font-medium">
                {calculateTax(amount, taxRate).toLocaleString()}원
              </div>
            </div>

            <div className="grid gap-2">
              <Label>합계</Label>
              <div className="p-2 bg-muted rounded-md text-right font-medium">
                {(amount + calculateTax(amount, taxRate)).toLocaleString()}원
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-payment-method">결제 수단</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger id="edit-payment-method">
                  <SelectValue placeholder="결제 수단 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="현금">현금</SelectItem>
                  <SelectItem value="신용카드">신용카드</SelectItem>
                  <SelectItem value="체크카드">체크카드</SelectItem>
                  <SelectItem value="계좌이체">계좌이체</SelectItem>
                  <SelectItem value="법인카드">법인카드</SelectItem>
                  <SelectItem value="어음">어음</SelectItem>
                  <SelectItem value="기타">기타</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-memo">메모</Label>
              <Input
                id="edit-memo"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                placeholder="메모를 입력하세요 (선택사항)"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="destructive"
              onClick={() => {
                if (editingItemId) handleDeleteItem(editingItemId)
                setIsEditDialogOpen(false)
              }}
            >
              삭제
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                취소
              </Button>
              <Button onClick={handleSaveEdit}>저장</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 카테고리 선택 다이얼로그 */}
      <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>카테고리 선택</DialogTitle>
            <DialogDescription>
              {transactionType === "매입" ? "매입 카테고리를 선택하세요" : "매출 카테고리를 선택하세요"}
            </DialogDescription>
          </DialogHeader>

          <CategorySelector
            onSelectCategory={handleCategorySelect}
            initialAmount={amount}
            title={transactionType === "매입" ? "매입 카테고리" : "매출 카테고리"}
            description={transactionType === "매입" ? "매입 카테고리를 선택하세요" : "매출 카테고리를 선택하세요"}
          />

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCategoryDialogOpen(false)}>
              취소
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

