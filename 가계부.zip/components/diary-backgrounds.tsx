"use client"

import { Card, CardContent } from "@/components/ui/card"

// 배경 이미지 목록
const backgroundImages = [
  { value: "none", label: "없음", url: "" },
  {
    value: "nature",
    label: "자연",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%281%29.jpg-WiRRI9UlNWv99roT0HaNU3tm0f4Kep.jpeg",
  },
  { value: "sky", label: "하늘", url: "/placeholder.svg?height=400&width=600&text=하늘" },
  { value: "ocean", label: "바다", url: "/placeholder.svg?height=400&width=600&text=바다" },
  { value: "mountain", label: "산", url: "/placeholder.svg?height=400&width=600&text=산" },
  { value: "forest", label: "숲", url: "/placeholder.svg?height=400&width=600&text=숲" },
  { value: "city", label: "도시", url: "/placeholder.svg?height=400&width=600&text=도시" },
  { value: "abstract", label: "추상", url: "/placeholder.svg?height=400&width=600&text=추상" },
]

interface DiaryBackgroundsProps {
  onSelectBackground: (url: string) => void
  selectedBackground: string
}

export default function DiaryBackgrounds({ onSelectBackground, selectedBackground }: DiaryBackgroundsProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-2 gap-4">
          {backgroundImages.map((bg) => (
            <div
              key={bg.value}
              className={`p-2 border rounded-md cursor-pointer hover:bg-muted/50 ${
                selectedBackground === bg.url ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => onSelectBackground(bg.url)}
            >
              {bg.url ? (
                <div className="aspect-video relative overflow-hidden rounded-md">
                  <img src={bg.url || "/placeholder.svg"} alt={bg.label} className="w-full h-full object-cover" />
                  <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-1 text-xs text-center">
                    {bg.label}
                  </div>
                </div>
              ) : (
                <div className="aspect-video flex items-center justify-center bg-muted rounded-md">
                  <span>{bg.label}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

