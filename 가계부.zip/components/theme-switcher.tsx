"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu"
import { Palette, Sun, Moon, Monitor, Coffee, Zap, Sparkles, Leaf, Sunset, Cloud, Waves } from "lucide-react"

// 테마 타입 정의
type Theme =
  | "light"
  | "dark"
  | "system"
  | "sepia"
  | "high-contrast"
  | "auto"
  | "nature"
  | "ocean"
  | "sunset"
  | "pastel"
  | "minimal"

export default function ThemeSwitcher() {
  const [theme, setTheme] = useState<Theme>("system")
  const [mounted, setMounted] = useState(false)

  // 테마 변경 함수
  const setThemeAndUpdateDOM = (newTheme: Theme) => {
    // 기본 테마 클래스 제거
    document.documentElement.classList.remove(
      "light",
      "dark",
      "sepia",
      "high-contrast",
      "auto",
      "nature",
      "ocean",
      "sunset",
      "pastel",
      "minimal",
    )

    // 시스템 테마 처리
    if (newTheme === "system" || newTheme === "auto") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
      document.documentElement.classList.add(systemTheme)

      if (newTheme === "auto") {
        // 자동 모드는 시간에 따라 테마 변경 (6시~18시: 라이트, 18시~6시: 다크)
        const currentHour = new Date().getHours()
        const isDayTime = currentHour >= 6 && currentHour < 18
        document.documentElement.classList.add(isDayTime ? "light" : "dark")
      }
    }
    // 일반 테마 처리
    else {
      document.documentElement.classList.add(newTheme)
    }

    // 테마별 CSS 변수 설정
    switch (newTheme) {
      case "sepia":
        document.documentElement.style.setProperty("--background", "#f4f0e5")
        document.documentElement.style.setProperty("--foreground", "#5f4b32")
        document.documentElement.style.setProperty("--card", "#f8f5ee")
        document.documentElement.style.setProperty("--card-foreground", "#5f4b32")
        document.documentElement.style.setProperty("--primary", "#8c7851")
        document.documentElement.style.setProperty("--primary-foreground", "#f8f5ee")
        break
      case "high-contrast":
        document.documentElement.style.setProperty("--background", "#ffffff")
        document.documentElement.style.setProperty("--foreground", "#000000")
        document.documentElement.style.setProperty("--card", "#ffffff")
        document.documentElement.style.setProperty("--card-foreground", "#000000")
        document.documentElement.style.setProperty("--primary", "#000000")
        document.documentElement.style.setProperty("--primary-foreground", "#ffffff")
        break
      case "nature":
        document.documentElement.style.setProperty("--background", "#f0f4e8")
        document.documentElement.style.setProperty("--foreground", "#2c3e2d")
        document.documentElement.style.setProperty("--card", "#ffffff")
        document.documentElement.style.setProperty("--card-foreground", "#2c3e2d")
        document.documentElement.style.setProperty("--primary", "#4b7f52")
        document.documentElement.style.setProperty("--primary-foreground", "#ffffff")
        break
      case "ocean":
        document.documentElement.style.setProperty("--background", "#e8f4f8")
        document.documentElement.style.setProperty("--foreground", "#1a3a4a")
        document.documentElement.style.setProperty("--card", "#ffffff")
        document.documentElement.style.setProperty("--card-foreground", "#1a3a4a")
        document.documentElement.style.setProperty("--primary", "#2a7da1")
        document.documentElement.style.setProperty("--primary-foreground", "#ffffff")
        break
      case "sunset":
        document.documentElement.style.setProperty("--background", "#fdf2e9")
        document.documentElement.style.setProperty("--foreground", "#5e3023")
        document.documentElement.style.setProperty("--card", "#ffffff")
        document.documentElement.style.setProperty("--card-foreground", "#5e3023")
        document.documentElement.style.setProperty("--primary", "#e67e22")
        document.documentElement.style.setProperty("--primary-foreground", "#ffffff")
        break
      case "pastel":
        document.documentElement.style.setProperty("--background", "#f8f9fa")
        document.documentElement.style.setProperty("--foreground", "#495057")
        document.documentElement.style.setProperty("--card", "#ffffff")
        document.documentElement.style.setProperty("--card-foreground", "#495057")
        document.documentElement.style.setProperty("--primary", "#a5b4fc")
        document.documentElement.style.setProperty("--primary-foreground", "#ffffff")
        break
      case "minimal":
        document.documentElement.style.setProperty("--background", "#fafafa")
        document.documentElement.style.setProperty("--foreground", "#333333")
        document.documentElement.style.setProperty("--card", "#ffffff")
        document.documentElement.style.setProperty("--card-foreground", "#333333")
        document.documentElement.style.setProperty("--primary", "#666666")
        document.documentElement.style.setProperty("--primary-foreground", "#ffffff")
        break
      default:
        document.documentElement.style.removeProperty("--background")
        document.documentElement.style.removeProperty("--foreground")
        document.documentElement.style.removeProperty("--card")
        document.documentElement.style.removeProperty("--card-foreground")
        document.documentElement.style.removeProperty("--primary")
        document.documentElement.style.removeProperty("--primary-foreground")
    }

    // 테마 상태 업데이트 및 로컬 스토리지에 저장
    setTheme(newTheme)
    localStorage.setItem("theme", newTheme)
  }

  // 초기 테마 설정
  useEffect(() => {
    setMounted(true)
    const savedTheme = localStorage.getItem("theme") as Theme | null

    if (savedTheme) {
      setThemeAndUpdateDOM(savedTheme)
    }
  }, [])

  // 마운트 전에는 렌더링하지 않음 (SSR 문제 방지)
  if (!mounted) return null

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon">
          <Palette className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>테마 설정</DropdownMenuLabel>
        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("light")}>
          <Sun className="mr-2 h-4 w-4" />
          <span>라이트 모드</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("dark")}>
          <Moon className="mr-2 h-4 w-4" />
          <span>다크 모드</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("sepia")}>
          <Coffee className="mr-2 h-4 w-4" />
          <span>세피아 모드</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("high-contrast")}>
          <Zap className="mr-2 h-4 w-4" />
          <span>고대비 모드</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("system")}>
          <Monitor className="mr-2 h-4 w-4" />
          <span>시스템 모드</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("auto")}>
          <Sun className="mr-2 h-4 w-4" />
          <span>자동 모드 (시간 기반)</span>
        </DropdownMenuItem>

        <DropdownMenuSeparator />
        <DropdownMenuLabel>추가 테마</DropdownMenuLabel>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("nature")}>
          <Leaf className="mr-2 h-4 w-4" />
          <span>자연 테마</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("ocean")}>
          <Waves className="mr-2 h-4 w-4" />
          <span>오션 테마</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("sunset")}>
          <Sunset className="mr-2 h-4 w-4" />
          <span>선셋 테마</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("pastel")}>
          <Sparkles className="mr-2 h-4 w-4" />
          <span>파스텔 테마</span>
        </DropdownMenuItem>

        <DropdownMenuItem onClick={() => setThemeAndUpdateDOM("minimal")}>
          <Cloud className="mr-2 h-4 w-4" />
          <span>미니멀 테마</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

