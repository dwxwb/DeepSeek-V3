"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { FileUp, Check, X, ArrowRight } from "lucide-react"
import * as XLSX from "xlsx"

export default function ExcelImport() {
  const [previewData, setPreviewData] = useState<any[]>([])
  const [headers, setHeaders] = useState<string[]>([])
  const [fileName, setFileName] = useState<string>("")
  const [importType, setImportType] = useState<string>("ledger")
  const [mappings, setMappings] = useState<Record<string, string>>({})
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setFileName(file.name)

    const reader = new FileReader()
    reader.onload = (evt) => {
      const bstr = evt.target?.result
      const wb = XLSX.read(bstr, { type: "binary" })
      const wsname = wb.SheetNames[0]
      const ws = wb.Sheets[wsname]
      const data = XLSX.utils.sheet_to_json(ws, { header: 1 })

      if (data.length > 0) {
        const headers = data[0] as string[]
        setHeaders(headers)

        // 초기 매핑 설정
        const initialMappings: Record<string, string> = {}
        headers.forEach((header) => {
          // 기본 매핑 추정
          if (header.includes("날짜") || header.includes("date")) {
            initialMappings[header] = "date"
          } else if (header.includes("금액") || header.includes("amount")) {
            initialMappings[header] = "amount"
          } else if (header.includes("내용") || header.includes("설명") || header.includes("description")) {
            initialMappings[header] = "description"
          } else if (header.includes("카테고리") || header.includes("category")) {
            initialMappings[header] = "category"
          } else {
            initialMappings[header] = ""
          }
        })
        setMappings(initialMappings)

        // 미리보기 데이터 설정 (첫 10행)
        setPreviewData(data.slice(1, 11) as any[])
      }
    }
    reader.readAsBinaryString(file)
  }

  const handleMappingChange = (header: string, value: string) => {
    setMappings({
      ...mappings,
      [header]: value,
    })
  }

  const getRequiredFields = () => {
    switch (importType) {
      case "ledger":
        return ["date", "amount", "description", "category"]
      case "purchase":
        return ["date", "amount", "description", "vendor", "category"]
      case "sales":
        return ["date", "amount", "description", "customer", "category"]
      default:
        return []
    }
  }

  const isMappingComplete = () => {
    const requiredFields = getRequiredFields()
    const mappedFields = Object.values(mappings)
    return requiredFields.every((field) => mappedFields.includes(field))
  }

  const handleImport = () => {
    // 실제 구현에서는 여기서 매핑된 데이터를 처리하는 로직이 들어갈 것입니다.
    alert("데이터 가져오기 성공! " + previewData.length + "개의 항목이 가져와졌습니다.")

    // 폼 초기화
    setPreviewData([])
    setHeaders([])
    setFileName("")
    setMappings({})
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">엑셀 데이터 가져오기</h2>

      <Card>
        <CardHeader>
          <CardTitle>데이터 가져오기</CardTitle>
          <CardDescription>엑셀 파일에서 데이터를 가져옵니다</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="import-type">가져오기 유형</Label>
            <Select value={importType} onValueChange={setImportType}>
              <SelectTrigger>
                <SelectValue placeholder="가져오기 유형 선택" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ledger">가계부</SelectItem>
                <SelectItem value="purchase">매입 내역</SelectItem>
                <SelectItem value="sales">매출 내역</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="file-upload">엑셀 파일 선택</Label>
            <div className="flex gap-2">
              <Input ref={fileInputRef} id="file-upload" type="file" accept=".xlsx,.xls" onChange={handleFileUpload} />
              <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                <FileUp className="mr-2 h-4 w-4" />
                파일 선택
              </Button>
            </div>
            {fileName && <p className="text-sm text-muted-foreground">선택된 파일: {fileName}</p>}
          </div>
        </CardContent>
      </Card>

      {headers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>데이터 매핑</CardTitle>
            <CardDescription>엑셀 열을 데이터 필드에 매핑하세요</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-4">
                {headers.map((header, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className="w-1/3">
                      <Label>{header}</Label>
                    </div>
                    <div className="w-1/3">
                      <ArrowRight className="h-4 w-4" />
                    </div>
                    <div className="w-1/3">
                      <Select value={mappings[header]} onValueChange={(value) => handleMappingChange(header, value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="필드 선택" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">매핑 안함</SelectItem>
                          <SelectItem value="date">날짜</SelectItem>
                          <SelectItem value="description">내용</SelectItem>
                          <SelectItem value="amount">금액</SelectItem>
                          <SelectItem value="category">카테고리</SelectItem>
                          {importType === "purchase" && <SelectItem value="vendor">거래처</SelectItem>}
                          {importType === "sales" && <SelectItem value="customer">거래처</SelectItem>}
                          <SelectItem value="type">유형 (수입/지출)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-muted p-4 rounded-md">
                <h3 className="font-medium mb-2">매핑 상태</h3>
                <div className="space-y-2">
                  {getRequiredFields().map((field) => (
                    <div key={field} className="flex items-center gap-2">
                      {Object.values(mappings).includes(field) ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <X className="h-4 w-4 text-red-500" />
                      )}
                      <span className="capitalize">{field}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {previewData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>데이터 미리보기</CardTitle>
            <CardDescription>가져올 데이터의 처음 10행을 미리 확인하세요</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {headers.map((header, index) => (
                      <TableHead key={index}>{header}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {previewData.map((row, rowIndex) => (
                    <TableRow key={rowIndex}>
                      {headers.map((header, colIndex) => (
                        <TableCell key={colIndex}>{row[colIndex]}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleImport} disabled={!isMappingComplete()}>
              데이터 가져오기
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}

