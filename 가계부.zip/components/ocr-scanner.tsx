"use client"

import type React from "react"
import { useEffect } from "react"
import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Camera, Upload, RefreshCw, Check, X, AlertTriangle } from "lucide-react"
import { getEmojiForCategoryName } from "@/lib/category-data"

// 가상의 OCR 처리 함수
const processOCR = async (file: File): Promise<any> => {
  // 실제 구현에서는 여기에 OCR API 호출 코드가 들어갈 것입니다.
  // 예: Tesseract.js, Google Cloud Vision API, Azure Computer Vision 등

  // 테스트를 위한 가상의 응답 데이터
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        data: {
          merchant: "스타벅스",
          date: "2024-03-15",
          time: "14:30",
          total: 5800,
          items: [
            { name: "아메리카노", price: 4500 },
            { name: "베이커리", price: 1300 },
          ],
          category: "식비",
          paymentMethod: "신용카드",
        },
      })
    }, 2000)
  })
}

export default function OCRScanner() {
  const [activeTab, setActiveTab] = useState("upload") // Default to upload tab
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState<any>(null)
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  const [isConfirmed, setIsConfirmed] = useState(false)
  const [isCameraAvailable, setIsCameraAvailable] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // 브라우저 환경 확인
  const isBrowser = typeof window !== "undefined"

  // 카메라 지원 여부 확인
  useEffect(() => {
    if (!isBrowser) return

    const checkCameraAvailability = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setCameraError("이 브라우저는 카메라 접근을 지원하지 않습니다.")
          return
        }

        // Just check if camera is available, don't keep the stream
        const stream = await navigator.mediaDevices.getUserMedia({ video: true })
        stream.getTracks().forEach((track) => track.stop())
        setIsCameraAvailable(true)
      } catch (error) {
        console.error("카메라 확인 중 오류:", error)
        setCameraError("카메라에 접근할 수 없습니다. 권한을 확인해주세요.")
      }
    }

    checkCameraAvailability()
  }, [isBrowser])

  // 파일 업로드 처리
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // 이미지 미리보기 설정
    const reader = new FileReader()
    reader.onload = (e) => {
      setPreviewImage(e.target?.result as string)
    }
    reader.readAsDataURL(file)

    // OCR 처리 시작
    setIsScanning(true)
    setScanResult(null)
    setIsConfirmed(false)

    try {
      const result = await processOCR(file)
      setScanResult(result.data)
    } catch (error) {
      console.error("OCR 처리 중 오류 발생:", error)
      alert("영수증 스캔 중 오류가 발생했습니다. 다시 시도해주세요.")
    } finally {
      setIsScanning(false)
    }
  }

  // 카메라 시작
  const startCamera = async () => {
    if (!isBrowser || !isCameraAvailable) return

    try {
      // 이미 실행 중인 스트림이 있으면 중지
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }

      // 새 스트림 시작
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      streamRef.current = stream

      // videoRef가 유효한지 확인 후 srcObject 설정
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      } else {
        console.warn("비디오 요소가 아직 준비되지 않았습니다.")
        // 스트림 정리
        stream.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }
    } catch (error) {
      console.error("카메라 접근 오류:", error)
      setCameraError("카메라에 접근할 수 없습니다. 권한을 확인해주세요.")
      setIsCameraAvailable(false)
    }
  }

  // 카메라 중지
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
  }

  // 탭 변경 시 처리
  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setScanResult(null)
    setPreviewImage(null)
    setIsConfirmed(false)

    // 카메라 탭으로 변경 시 카메라 시작
    if (value === "camera" && isCameraAvailable) {
      // 다음 렌더링 사이클에서 카메라 시작
      setTimeout(() => {
        startCamera()
      }, 300)
    } else {
      // 다른 탭으로 변경 시 카메라 중지
      stopCamera()
    }
  }

  // 사진 촬영
  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (context && video.videoWidth && video.videoHeight) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      context.drawImage(video, 0, 0, canvas.width, canvas.height)

      // 캡처한 이미지를 데이터 URL로 변환
      const imageDataUrl = canvas.toDataURL("image/jpeg")
      setPreviewImage(imageDataUrl)

      // 캡처한 이미지를 Blob으로 변환하여 OCR 처리
      canvas.toBlob(async (blob) => {
        if (blob) {
          setIsScanning(true)
          try {
            const file = new File([blob], "captured-receipt.jpg", { type: "image/jpeg" })
            const result = await processOCR(file)
            setScanResult(result.data)
          } catch (error) {
            console.error("OCR 처리 중 오류 발생:", error)
            alert("영수증 스캔 중 오류가 발생했습니다. 다시 시도해주세요.")
          } finally {
            setIsScanning(false)
          }
        }
      }, "image/jpeg")
    }
  }

  // 결과 확인 및 저장
  const confirmResult = () => {
    // 실제 구현에서는 여기에 데이터베이스에 저장하는 코드가 들어갈 것입니다.
    setIsConfirmed(true)
    alert("영수증 정보가 성공적으로 저장되었습니다!")

    // 초기화
    setTimeout(() => {
      setScanResult(null)
      setPreviewImage(null)
      setIsConfirmed(false)
      if (activeTab === "camera" && isCameraAvailable) {
        startCamera()
      }
    }, 2000)
  }

  // 컴포넌트 마운트/언마운트 시 카메라 처리
  useEffect(() => {
    // 컴포넌트가 마운트되고 카메라 탭이 활성화되어 있으면 카메라 시작
    if (activeTab === "camera" && isCameraAvailable) {
      const timer = setTimeout(() => {
        startCamera()
      }, 500)

      return () => {
        clearTimeout(timer)
        stopCamera()
      }
    }

    // 컴포넌트 언마운트 시 카메라 중지
    return () => {
      stopCamera()
    }
  }, [activeTab, isCameraAvailable])

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">영수증 스캔</h2>

      <Tabs value={activeTab} onValueChange={handleTabChange}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="camera" disabled={!isCameraAvailable}>
            카메라 {!isCameraAvailable && "(사용 불가)"}
          </TabsTrigger>
          <TabsTrigger value="upload">파일 업로드</TabsTrigger>
        </TabsList>

        <TabsContent value="camera">
          <Card>
            <CardHeader>
              <CardTitle>카메라로 영수증 촬영</CardTitle>
              <CardDescription>영수증을 카메라에 비춰주세요</CardDescription>
            </CardHeader>
            <CardContent>
              {cameraError ? (
                <div className="flex flex-col items-center justify-center p-8 bg-muted rounded-md">
                  <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
                  <p className="text-center text-muted-foreground mb-2">{cameraError}</p>
                  <p className="text-center text-sm text-muted-foreground">파일 업로드 탭을 이용해주세요.</p>
                </div>
              ) : !previewImage ? (
                <div className="relative aspect-video bg-muted rounded-md overflow-hidden">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                    onLoadedMetadata={() => console.log("비디오 메타데이터 로드됨")}
                  />
                  <canvas ref={canvasRef} className="hidden" />
                </div>
              ) : (
                <div className="relative aspect-video bg-muted rounded-md overflow-hidden">
                  <img
                    src={previewImage || "/placeholder.svg"}
                    alt="촬영된 영수증"
                    className="w-full h-full object-contain"
                  />
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              {!previewImage ? (
                <Button onClick={captureImage} disabled={isScanning || !isCameraAvailable || cameraError !== null}>
                  <Camera className="mr-2 h-4 w-4" />
                  촬영하기
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setPreviewImage(null)
                      setScanResult(null)
                      startCamera()
                    }}
                    disabled={isScanning}
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    다시 촬영
                  </Button>
                  {scanResult && !isConfirmed && (
                    <Button onClick={confirmResult} disabled={isScanning}>
                      <Check className="mr-2 h-4 w-4" />
                      확인 및 저장
                    </Button>
                  )}
                </div>
              )}
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle>영수증 이미지 업로드</CardTitle>
              <CardDescription>영수증 이미지 파일을 업로드하세요</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="receipt-image">영수증 이미지</Label>
                  <div className="flex gap-2">
                    <Input
                      ref={fileInputRef}
                      id="receipt-image"
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      disabled={isScanning}
                    />
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={isScanning}>
                      <Upload className="mr-2 h-4 w-4" />
                      파일 선택
                    </Button>
                  </div>
                </div>

                {previewImage && (
                  <div className="relative aspect-video bg-muted rounded-md overflow-hidden">
                    <img
                      src={previewImage || "/placeholder.svg"}
                      alt="업로드된 영수증"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              {previewImage && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setPreviewImage(null)
                      setScanResult(null)
                      if (fileInputRef.current) {
                        fileInputRef.current.value = ""
                      }
                    }}
                    disabled={isScanning}
                  >
                    <X className="mr-2 h-4 w-4" />
                    취소
                  </Button>
                  {scanResult && !isConfirmed && (
                    <Button onClick={confirmResult} disabled={isScanning}>
                      <Check className="mr-2 h-4 w-4" />
                      확인 및 저장
                    </Button>
                  )}
                </div>
              )}
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      {isScanning && (
        <div className="flex flex-col items-center justify-center p-8 bg-muted rounded-md">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
          <p className="text-center text-muted-foreground">영수증을 분석 중입니다...</p>
        </div>
      )}

      {scanResult && !isConfirmed && (
        <Card>
          <CardHeader>
            <CardTitle>인식 결과</CardTitle>
            <CardDescription>인식된 영수증 정보를 확인하고 필요한 경우 수정하세요</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="merchant">상호명</Label>
                  <Input id="merchant" defaultValue={scanResult.merchant} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="date">날짜</Label>
                  <Input id="date" defaultValue={scanResult.date} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="time">시간</Label>
                  <Input id="time" defaultValue={scanResult.time} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="total">총액</Label>
                  <Input id="total" defaultValue={scanResult.total} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="category">카테고리</Label>
                  <div className="flex items-center gap-2">
                    <span role="img" aria-label={scanResult.category}>
                      {getEmojiForCategoryName(scanResult.category)}
                    </span>
                    <Input id="category" defaultValue={scanResult.category} />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="payment-method">결제 수단</Label>
                  <Input id="payment-method" defaultValue={scanResult.paymentMethod} />
                </div>
              </div>

              <div className="space-y-2">
                <Label>항목</Label>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>품목</TableHead>
                      <TableHead className="text-right">금액</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {scanResult.items.map((item: any, index: number) => (
                      <TableRow key={index}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell className="text-right">{item.price.toLocaleString()}원</TableCell>
                      </TableRow>
                    ))}
                    <TableRow>
                      <TableCell className="font-bold">합계</TableCell>
                      <TableCell className="text-right font-bold">{scanResult.total.toLocaleString()}원</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={confirmResult}>
              <Check className="mr-2 h-4 w-4" />
              확인 및 저장
            </Button>
          </CardFooter>
        </Card>
      )}

      {isConfirmed && (
        <div className="bg-green-50 p-4 rounded-md flex items-center gap-2 text-green-600">
          <Check className="h-5 w-5" />
          <p>영수증 정보가 성공적으로 저장되었습니다!</p>
        </div>
      )}
    </div>
  )
}

