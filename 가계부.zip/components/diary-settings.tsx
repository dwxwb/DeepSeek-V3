"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Palette, Type, Save, RotateCcw } from "lucide-react"

interface DiarySettingsProps {
  textColor: string
  bgColor: string
  onChangeTextColor: (color: string) => void
  onChangeBgColor: (color: string) => void
}

// 미리 정의된 색상 팔레트
const colorPalette = [
  { name: "검정", value: "#000000" },
  { name: "짙은 회색", value: "#333333" },
  { name: "회색", value: "#555555" },
  { name: "흰색", value: "#FFFFFF" },
  { name: "밝은 회색", value: "#ECF0F1" },
  { name: "짙은 보라색", value: "#4B0082" },
  { name: "밝은 노랑", value: "#FFDC00" },
  { name: "아이보리", value: "#FFFFF0" },
  { name: "빨강", value: "#e74c3c" },
  { name: "파랑", value: "#3498db" },
]

// 배경색 팔레트
const bgColorPalette = [
  { name: "흰색", value: "#FFFFFF" },
  { name: "밝은 회색", value: "#F0F0F0" },
  { name: "짙은 남색", value: "#2C3E50" },
  { name: "검은색", value: "#000000" },
  { name: "연한 민트색", value: "#A8E6CF" },
  { name: "라벤더색", value: "#E6E6FA" },
  { name: "짙은 파랑", value: "#001F3F" },
  { name: "올리브 그린", value: "#556B2F" },
  { name: "크림색", value: "#FFFFF0" },
  { name: "연한 파랑", value: "#E3F2FD" },
]

export default function DiarySettings({ textColor, bgColor, onChangeTextColor, onChangeBgColor }: DiarySettingsProps) {
  const [localTextColor, setLocalTextColor] = useState(textColor)
  const [localBgColor, setLocalBgColor] = useState(bgColor)
  const [previewText, setPreviewText] = useState("안녕하세요! 이것은 텍스트 색상과 배경색 미리보기입니다.")

  // 부모 컴포넌트의 색상 값이 변경되면 로컬 상태 업데이트
  useEffect(() => {
    setLocalTextColor(textColor)
    setLocalBgColor(bgColor)
  }, [textColor, bgColor])

  // 변경 사항 적용
  const applyChanges = () => {
    onChangeTextColor(localTextColor)
    onChangeBgColor(localBgColor)
  }

  // 기본값으로 초기화
  const resetToDefaults = () => {
    setLocalTextColor("#000000")
    setLocalBgColor("#ffffff")
    onChangeTextColor("#000000")
    onChangeBgColor("#ffffff")
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">일기장 설정</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={resetToDefaults}>
            <RotateCcw className="mr-2 h-4 w-4" />
            기본값으로 초기화
          </Button>
          <Button onClick={applyChanges}>
            <Save className="mr-2 h-4 w-4" />
            변경사항 저장
          </Button>
        </div>
      </div>

      <Tabs defaultValue="colors">
        <TabsList className="mb-4">
          <TabsTrigger value="colors">
            <Palette className="mr-2 h-4 w-4" />
            색상 설정
          </TabsTrigger>
          <TabsTrigger value="preview">
            <Type className="mr-2 h-4 w-4" />
            미리보기
          </TabsTrigger>
        </TabsList>

        <TabsContent value="colors">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>텍스트 색상</CardTitle>
                <CardDescription>일기장 텍스트 색상을 선택하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="textColor">직접 색상 선택</Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="textColor"
                      type="color"
                      value={localTextColor}
                      onChange={(e) => setLocalTextColor(e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input
                      type="text"
                      value={localTextColor}
                      onChange={(e) => setLocalTextColor(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <Label>색상 팔레트</Label>
                  <div className="grid grid-cols-5 gap-2 mt-1">
                    {colorPalette.map((color) => (
                      <button
                        key={color.value}
                        className={`w-full h-10 rounded-md border ${
                          localTextColor === color.value ? "ring-2 ring-primary" : ""
                        }`}
                        style={{ backgroundColor: color.value }}
                        onClick={() => setLocalTextColor(color.value)}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>배경 색상</CardTitle>
                <CardDescription>일기장 배경 색상을 선택하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="bgColor">직접 색상 선택</Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="bgColor"
                      type="color"
                      value={localBgColor}
                      onChange={(e) => setLocalBgColor(e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input
                      type="text"
                      value={localBgColor}
                      onChange={(e) => setLocalBgColor(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <Label>색상 팔레트</Label>
                  <div className="grid grid-cols-5 gap-2 mt-1">
                    {bgColorPalette.map((color) => (
                      <button
                        key={color.value}
                        className={`w-full h-10 rounded-md border ${
                          localBgColor === color.value ? "ring-2 ring-primary" : ""
                        }`}
                        style={{ backgroundColor: color.value }}
                        onClick={() => setLocalBgColor(color.value)}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-medium mb-2">추천 색상 조합</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setLocalBgColor("#FFFFFF")
                  setLocalTextColor("#333333")
                }}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">밝은 배경과 어두운 글자</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 rounded-md bg-white border">
                    <p className="text-[#333333]">깔끔하고 가독성이 우수한 조합입니다.</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setLocalBgColor("#2C3E50")
                  setLocalTextColor("#FFFFFF")
                }}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">어두운 배경과 밝은 글자</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 rounded-md bg-[#2C3E50]">
                    <p className="text-white">모던하고 세련된 느낌을 줍니다.</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setLocalBgColor("#A8E6CF")
                  setLocalTextColor("#555555")
                }}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">파스텔 톤 조합</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 rounded-md bg-[#A8E6CF]">
                    <p className="text-[#555555]">부드럽고 친근한 분위기를 조성합니다.</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setLocalBgColor("#001F3F")
                  setLocalTextColor("#FFDC00")
                }}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">대비 색상 활용</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 rounded-md bg-[#001F3F]">
                    <p className="text-[#FFDC00]">강렬한 대비로 주목성을 높입니다.</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  setLocalBgColor("#556B2F")
                  setLocalTextColor("#FFFFF0")
                }}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">자연을 연상시키는 색상</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 rounded-md bg-[#556B2F]">
                    <p className="text-[#FFFFF0]">자연스럽고 안정적인 느낌을 줍니다.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>미리보기</CardTitle>
              <CardDescription>선택한 색상으로 일기장이 어떻게 보이는지 확인하세요</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="previewText">미리보기 텍스트</Label>
                  <Input
                    id="previewText"
                    value={previewText}
                    onChange={(e) => setPreviewText(e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div className="border rounded-md p-6 mt-4">
                  <div
                    className="p-6 rounded-md"
                    style={{
                      backgroundColor: localBgColor,
                      color: localTextColor,
                    }}
                  >
                    <h3 className="text-xl font-bold mb-4">일기장 미리보기</h3>
                    <p className="mb-2">
                      {new Date().toLocaleDateString("ko-KR", { year: "numeric", month: "long", day: "numeric" })}
                    </p>
                    <p className="whitespace-pre-line">{previewText}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

