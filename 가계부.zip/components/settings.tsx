"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { User, Building, Shield, Database, Upload } from "lucide-react"

export default function Settings() {
  const [darkMode, setDarkMode] = useState(false)
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [autoBackup, setAutoBackup] = useState(true)

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">설정</h2>

      <Tabs defaultValue="profile">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">프로필</TabsTrigger>
          <TabsTrigger value="company">회사 정보</TabsTrigger>
          <TabsTrigger value="preferences">환경 설정</TabsTrigger>
          <TabsTrigger value="data">데이터 관리</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>프로필 정보</CardTitle>
              <CardDescription>개인 정보를 관리하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="h-10 w-10 text-gray-500" />
                </div>
                <Button variant="outline">프로필 사진 변경</Button>
              </div>

              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">이름</Label>
                  <Input id="name" defaultValue="홍길동" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">이메일</Label>
                  <Input id="email" type="email" defaultValue="hong@example.com" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="phone">전화번호</Label>
                  <Input id="phone" defaultValue="010-1234-5678" />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>저장</Button>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>비밀번호 변경</CardTitle>
              <CardDescription>계정 보안을 위해 주기적으로 비밀번호를 변경하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="current-password">현재 비밀번호</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="new-password">새 비밀번호</Label>
                <Input id="new-password" type="password" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="confirm-password">비밀번호 확인</Label>
                <Input id="confirm-password" type="password" />
              </div>
            </CardContent>
            <CardFooter>
              <Button>비밀번호 변경</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="company">
          <Card>
            <CardHeader>
              <CardTitle>회사 정보</CardTitle>
              <CardDescription>회사 정보를 관리하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-md bg-gray-200 flex items-center justify-center">
                  <Building className="h-10 w-10 text-gray-500" />
                </div>
                <Button variant="outline">회사 로고 변경</Button>
              </div>

              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="company-name">회사명</Label>
                  <Input id="company-name" defaultValue="(주)예시기업" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="business-number">사업자등록번호</Label>
                  <Input id="business-number" defaultValue="123-45-67890" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="representative">대표자명</Label>
                  <Input id="representative" defaultValue="홍길동" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="company-address">회사 주소</Label>
                  <Input id="company-address" defaultValue="서울특별시 강남구 테헤란로 123" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="company-phone">회사 전화번호</Label>
                  <Input id="company-phone" defaultValue="02-123-4567" />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>저장</Button>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>세금 정보</CardTitle>
              <CardDescription>세금 관련 정보를 관리하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="tax-type">과세 유형</Label>
                <Select defaultValue="general">
                  <SelectTrigger>
                    <SelectValue placeholder="과세 유형 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">일반과세자</SelectItem>
                    <SelectItem value="simplified">간이과세자</SelectItem>
                    <SelectItem value="exempt">면세사업자</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="tax-rate">부가가치세율</Label>
                <Select defaultValue="10">
                  <SelectTrigger>
                    <SelectValue placeholder="세율 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10%</SelectItem>
                    <SelectItem value="0">0% (면세)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter>
              <Button>저장</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="preferences">
          <Card>
            <CardHeader>
              <CardTitle>화면 설정</CardTitle>
              <CardDescription>화면 표시 방식을 설정하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode">다크 모드</Label>
                  <p className="text-sm text-muted-foreground">어두운 테마로 화면을 표시합니다</p>
                </div>
                <Switch id="dark-mode" checked={darkMode} onCheckedChange={setDarkMode} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="language">언어</Label>
                  <p className="text-sm text-muted-foreground">시스템 언어를 선택하세요</p>
                </div>
                <Select defaultValue="ko">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="언어 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ko">한국어</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ja">日本語</SelectItem>
                    <SelectItem value="zh">中文</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="currency">기본 통화</Label>
                  <p className="text-sm text-muted-foreground">금액 표시에 사용할 기본 통화를 선택하세요</p>
                </div>
                <Select defaultValue="krw">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="통화 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="krw">KRW (₩)</SelectItem>
                    <SelectItem value="usd">USD ($)</SelectItem>
                    <SelectItem value="eur">EUR (€)</SelectItem>
                    <SelectItem value="jpy">JPY (¥)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>알림 설정</CardTitle>
              <CardDescription>알림 수신 방식을 설정하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="email-notifications">이메일 알림</Label>
                  <p className="text-sm text-muted-foreground">중요 알림을 이메일로 받습니다</p>
                </div>
                <Switch id="email-notifications" checked={emailNotifications} onCheckedChange={setEmailNotifications} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="due-date">마감일 알림</Label>
                  <p className="text-sm text-muted-foreground">세금 신고 및 납부 마감일을 알려줍니다</p>
                </div>
                <Select defaultValue="7">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="알림 시점 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1일 전</SelectItem>
                    <SelectItem value="3">3일 전</SelectItem>
                    <SelectItem value="7">7일 전</SelectItem>
                    <SelectItem value="14">14일 전</SelectItem>
                    <SelectItem value="30">30일 전</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data">
          <Card>
            <CardHeader>
              <CardTitle>데이터 백업</CardTitle>
              <CardDescription>데이터 백업 및 복원 설정</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-backup">자동 백업</Label>
                  <p className="text-sm text-muted-foreground">데이터를 자동으로 백업합니다</p>
                </div>
                <Switch id="auto-backup" checked={autoBackup} onCheckedChange={setAutoBackup} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="backup-frequency">백업 주기</Label>
                  <p className="text-sm text-muted-foreground">자동 백업 주기를 설정하세요</p>
                </div>
                <Select defaultValue="daily">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="백업 주기 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">매일</SelectItem>
                    <SelectItem value="weekly">매주</SelectItem>
                    <SelectItem value="monthly">매월</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-2 mt-4">
                <Button>
                  <Database className="mr-2 h-4 w-4" />
                  지금 백업하기
                </Button>
                <Button variant="outline">
                  <Upload className="mr-2 h-4 w-4" />
                  백업 파일에서 복원
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>데이터 초기화</CardTitle>
              <CardDescription>데이터 초기화 및 삭제 옵션</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border border-red-200 bg-red-50 rounded-md">
                <h3 className="text-lg font-medium text-red-800 flex items-center">
                  <Shield className="mr-2 h-5 w-5" />
                  주의
                </h3>
                <p className="text-sm text-red-600 mt-1">
                  데이터 초기화는 되돌릴 수 없습니다. 진행하기 전에 반드시 백업을 수행하세요.
                </p>
              </div>
              <div className="flex flex-col gap-2">
                <Button variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
                  거래 내역 초기화
                </Button>
                <Button variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
                  보고서 데이터 초기화
                </Button>
                <Button variant="destructive">모든 데이터 초기화</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

