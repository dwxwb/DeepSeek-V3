"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Calculator } from "lucide-react"
import DiaryApp from "./diary-app"
import FinanceApp from "./finance-app"

export default function AppSelector() {
  const [selectedApp, setSelectedApp] = useState<"none" | "finance" | "diary">("none")

  if (selectedApp === "finance") {
    return (
      <div className="container mx-auto p-4">
        <Button variant="outline" onClick={() => setSelectedApp("none")} className="mb-4">
          ← 돌아가기
        </Button>
        <FinanceApp />
      </div>
    )
  }

  if (selectedApp === "diary") {
    return (
      <div className="container mx-auto p-4">
        <Button variant="outline" onClick={() => setSelectedApp("none")} className="mb-4">
          ← 돌아가기
        </Button>
        <DiaryApp />
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4 min-h-screen flex items-center justify-center">
      <div className="w-full max-w-4xl">
        <h1 className="text-3xl font-bold text-center mb-8">자동 전산 프로그램</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setSelectedApp("finance")}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calculator className="mr-2 h-5 w-5" />
                가계부
              </CardTitle>
              <CardDescription>매입 매출 관리 및 엑셀 정리</CardDescription>
            </CardHeader>
            <CardContent>
              <p>수입과 지출을 관리하고, 엑셀로 데이터를 정리하세요.</p>
            </CardContent>
            <CardFooter>
              <Button className="w-full">가계부 시작하기</Button>
            </CardFooter>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setSelectedApp("diary")}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="mr-2 h-5 w-5" />
                일기장
              </CardTitle>
              <CardDescription>일상 기록 및 감정 관리</CardDescription>
            </CardHeader>
            <CardContent>
              <p>하루의 일상과 감정을 기록하고 관리하세요.</p>
            </CardContent>
            <CardFooter>
              <Button className="w-full">일기장 시작하기</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

