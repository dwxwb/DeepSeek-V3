// 카테고리 데이터 및 이모티콘 관리

export type Category = {
  id: string
  name: string
  emoji: string
  color?: string
}

// 지출 카테고리
export const expenseCategories: Category[] = [
  { id: "food", name: "식비", emoji: "🍽️" },
  { id: "beverage", name: "음료", emoji: "🥤" },
  { id: "transportation", name: "교통", emoji: "🚌" },
  { id: "household", name: "생활", emoji: "🧴" },
  { id: "communication", name: "통신", emoji: "📱" },
  { id: "entertainment", name: "오락", emoji: "🎮" },
  { id: "health", name: "건강", emoji: "💊" },
  { id: "beauty", name: "미용", emoji: "💄" },
  { id: "clothing", name: "의류", emoji: "👕" },
  { id: "education", name: "교육", emoji: "📚" },
  { id: "housing", name: "주거", emoji: "🏠" },
  { id: "subscription", name: "구독", emoji: "📺" },
  { id: "gift", name: "선물", emoji: "🎁" },
  { id: "travel", name: "여행", emoji: "✈️" },
  { id: "consumables", name: "소모품", emoji: "🖊️" },
  { id: "vegetables", name: "채소", emoji: "🥦" },
  { id: "fruits", name: "과일", emoji: "🍐" },
  { id: "meat", name: "고기", emoji: "🍗" },
  { id: "snacks", name: "과자", emoji: "🍬" },
  { id: "electronics", name: "전자제품", emoji: "🔌" },
  { id: "baby", name: "아기", emoji: "👶" },
  { id: "pet", name: "애완동물", emoji: "🐶" },
  { id: "donation", name: "기부", emoji: "❤️" },
  { id: "etc", name: "기타", emoji: "📌" },
]

// 수입 카테고리
export const incomeCategories: Category[] = [
  { id: "salary", name: "급여", emoji: "💰" },
  { id: "bonus", name: "보너스", emoji: "🎉" },
  { id: "interest", name: "이자", emoji: "💹" },
  { id: "investment", name: "투자", emoji: "📈" },
  { id: "side-job", name: "부업", emoji: "🛠️" },
  { id: "allowance", name: "용돈", emoji: "💸" },
  { id: "gift", name: "선물", emoji: "🎁" },
  { id: "refund", name: "환불", emoji: "↩️" },
  { id: "etc", name: "기타", emoji: "📌" },
]

// 카테고리 이름으로 이모티콘 가져오기
export function getEmojiForCategoryName(categoryName: string): string {
  // 지출 카테고리에서 검색
  const expenseCategory = expenseCategories.find((cat) => cat.name === categoryName)
  if (expenseCategory) return expenseCategory.emoji

  // 수입 카테고리에서 검색
  const incomeCategory = incomeCategories.find((cat) => cat.name === categoryName)
  if (incomeCategory) return incomeCategory.emoji

  // 기본 이모티콘
  return "📋"
}

// 카테고리 ID로 이모티콘 가져오기
export function getEmojiForCategoryId(categoryId: string): string {
  // 지출 카테고리에서 검색
  const expenseCategory = expenseCategories.find((cat) => cat.id === categoryId)
  if (expenseCategory) return expenseCategory.emoji

  // 수입 카테고리에서 검색
  const incomeCategory = incomeCategories.find((cat) => cat.id === categoryId)
  if (incomeCategory) return incomeCategory.emoji

  // 기본 이모티콘
  return "📋"
}

// 모든 카테고리 가져오기
export function getAllCategories(): Category[] {
  return [...expenseCategories, ...incomeCategories]
}

